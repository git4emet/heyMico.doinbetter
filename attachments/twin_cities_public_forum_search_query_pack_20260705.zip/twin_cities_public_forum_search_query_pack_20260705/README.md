# Twin Cities Public Forum Search Query Pack

Open first:

```text
TWIN_CITIES_PUBLIC_FORUM_SEARCH_PLAN.md
```

Then use:

```text
queries.csv
venue_scoring_sheet.csv
MODERATOR_APPROVAL_MESSAGE.md
PUBLIC_POST_COPY.md
```

State boundary:
- This is a query and posting-ethics pack.
- It does not search the web by itself.
- It does not contact anyone.
- It keeps care relationships outside the outreach graph.
