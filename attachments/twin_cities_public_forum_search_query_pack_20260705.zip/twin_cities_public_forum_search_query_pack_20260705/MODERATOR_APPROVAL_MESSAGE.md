# Moderator Approval Message

Hi — is it okay to post a free community event-help pilot here?

I’m looking for one local organizer with a messy event flyer/text thread to clean into a better invite, bring-list, and RSVP tracker.

No selling in the first test. Just trying to help with one real community event.

Thanks.
