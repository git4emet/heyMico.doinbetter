# Public Post Copy

Free community event invite cleanup pilot

Got a messy event flyer, group text, potluck, fundraiser, volunteer day, family event, small show, or community thing?

I’m testing a simple helper that turns messy event info into:

• a cleaner invite
• a bring-list
• an RSVP / reply tracker
• a simple share page

No app to learn for the first one.

Send the messy version. I’ll clean up one real event for free.
