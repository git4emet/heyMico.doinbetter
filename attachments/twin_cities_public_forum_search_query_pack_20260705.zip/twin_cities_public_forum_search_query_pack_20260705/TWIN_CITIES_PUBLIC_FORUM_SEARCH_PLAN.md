# Twin Cities Public Forum Search Query Pack

## Boundary

Do not search for or use Dr. Zoe as a route.

```text
Dr. Zoe:
  care relationship
  outside outreach graph

Search target:
  public community action spaces
  public event calendars
  public bulletin boards
  local forums where event/help posts already belong
```

## Goal

Find public or semi-public Twin Cities / St. Paul forums where it is appropriate to post a free community event-invite cleanup pilot.

## Core offer

```text
Got a messy event invite?
I’ll clean it into:
  cleaner invite
  bring-list
  RSVP / reply tracker
  simple share page
```

## Master Boolean query

Use this as the big starting query:

```text
("St Paul" OR "Saint Paul" OR "Twin Cities" OR Minnesota)
("submit event" OR "community calendar" OR "community bulletin board" OR "volunteer opportunity" OR "mutual aid" OR "fundraiser" OR "potluck" OR "community event")
("submit" OR "post" OR "add event" OR "calendar" OR "forum" OR "group")
```

## Platform-specific queries

```text
site:reddit.com/r/TwinCities event volunteer community
site:reddit.com/r/saintpaul event community volunteer
site:facebook.com/groups "St Paul" "community" "events"
site:facebook.com/groups "Twin Cities" "mutual aid"
site:meetup.com "Saint Paul" "community" "organizer"
site:eventbrite.com "Twin Cities" "volunteer"
site:eventbrite.com "Saint Paul" "community" "fundraiser"
site:nextdoor.com "St Paul" "event" "community"
```

## How to score each result

For each possible venue, record:

```text
Venue name:
URL:
Locality:
  St Paul / Twin Cities / Minnesota / too broad

Posting type:
  direct post / mod approval / submit event / contact form / no posting

Allows community resources:
  yes / maybe / no

Audience:
  organizers / volunteers / neighbors / event hosts / unclear

Fit:
  event help / volunteer help / family/community support / no fit

Spam risk:
  low / medium / high

Post decision:
  post / ask moderator / skip
```

Only post where:

```text
local audience
+
event/help coordination fit
+
posting allowed or moderator approval available
+
low or medium spam risk
```

## Moderator approval message

```text
Hi — is it okay to post a free community event-help pilot here?

I’m looking for one local organizer with a messy event flyer/text thread to clean into a better invite, bring-list, and RSVP tracker.

No selling in the first test. Just trying to help with one real community event.
```

## Public post copy

```text
Free community event invite cleanup pilot

Got a messy event flyer, group text, potluck, fundraiser, volunteer day, family event, small show, or community thing?

I’m testing a simple helper that turns messy event info into:

• a cleaner invite
• a bring-list
• an RSVP / reply tracker
• a simple share page

No app to learn for the first one.

Send the messy version. I’ll clean up one real event for free.
```

## What not to do

```text
Do not mention private care relationships.
Do not ask Dr. Zoe for names.
Do not DM people from medical/community-adjacent private contexts.
Do not pitch the whole system.
Do not use jargon.
Do not post where self-promotion is banned.
```

## First success signal

```text
One public organizer sends one messy event.
```
