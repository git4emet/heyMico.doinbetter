# Spring Connector Cycle — INGEST → NORMALIZE → GATE

**Mode:** `read_parse_gate_only`  
**Season:** `Spring / Ingestion / Init.0`  
**Mercury factor:** `P = 0.25`  
**Guardian state:** mutation locked  
**Status:** Specified / seeded

## ShiftEvent

```text
ShiftEvent:
  spring_connector_ingest_normalize_gate_20260703

Instruction:
  Begin Spring for next cluster connector actions.
```

## Allowed

```text
read
search
list
parse
stage
receipt
```

## Forbidden

```text
send
write
modify
create external records
publish
deploy
share
```

## What began

The organism has shifted from Winter stabilization into Spring ingestion.

This is not an action phase. It is a **seed phase**.

```text
INGEST:
  seed connector action cards

NORMALIZE:
  define SourceCard templates and normalization rules

GATE:
  apply Guardian rules before any connector read or promotion
```

## Connector action seeds

The queue is stored at:

```text
ledgers/spring_connector_action_seeds.jsonl
indexes/spring_connector_action_queue.csv
```

Every connector seed requires a user-named target before any read/search/list action.

## No-trespass boundary

No connector action was performed by this package.

The package prepares the safe Spring state only.
