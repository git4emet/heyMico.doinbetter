# Builder Addendum — Yellow Brick / Loopa / Wonka Layer

Add this as a fun navigation and feedback layer.

Do not start over.
Always rebuild from what we had PLUS THIS.

## UI mapping

- Yellow Brick Road = guided breadcrumb path through party setup
- Rainbow Channels = color-coded Party Vacuum lanes
- Pot of Gold = success state / launch receipt
- Loopa = repeatable micro-loop helper
- Oompa = chorus/status voice
- Wonka = Cat Labs / PartyChain factory room

## Suggested app pieces

1. `YellowPathGuide`
   Shows next step: Create party → Pick people → Preview invite → Draft Gmail → Send → Watch replies.

2. `LoopaWorker`
   Small repeatable automations:
   - check missing bring-list items
   - suggest one follow-up
   - detect duplicate contacts
   - route reply to RSVP / need / help

3. `WonkaFactoryMode`
   Visual transformation room:
   - input fragments
   - graphics bank
   - party glyphs
   - output surface/card/receipt

4. `OompaChorus`
   Friendly microcopy:
   - “One more step”
   - “Draft ready”
   - “Watermelon still missing”
   - “Reply landed”

Keep it funny, tappable, and cousin-safe.
