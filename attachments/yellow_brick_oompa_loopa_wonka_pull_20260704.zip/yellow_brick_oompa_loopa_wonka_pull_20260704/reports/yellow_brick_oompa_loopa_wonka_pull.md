# Yellow Brick / Oompa / Loopa / Wonka Pull

**State:** Executed  
**Current-file text sources with hits:** 32  
**Context snippets pulled:** 247  
**Zip hits pulled:** 51

## Clean read

```text
yellow brick road
  → guided trail / breadcrumb path

pot of gold at rainbow end
  → reward endpoint / visible success state

Oompa
  → chorus / worker-voice / consequence song

Loopa
  → Oompa without M
  → loop operator / repeated micro-action / ring pass

Wonka
  → factory / stage / imagination engine
```

## PartyChain binding

```text
follow path
→ colored channel
→ loop worker
→ factory transform
→ reward state
→ receipt
```

## Highest-hit current sources

- `skillsetindex_UPDATED_v6(1).txt` — total 297 | oompa 32 | loopa 1 | wonka 264
- `conversationsdeepseekbig-sculpted-for-tracing-like-a-brainmap.json` — total 260 | oompa 54 | loopa 6 | wonka 200
- `conversations-deepseek-another-big-sculpted.json` — total 260 | oompa 54 | loopa 6 | wonka 200
- `conversationsDDX.json` — total 102 | oompa 2 | loopa 1 | wonka 99
- `conversations (copy 1).json` — total 102 | oompa 2 | loopa 1 | wonka 99
- `conversations1130.json` — total 102 | oompa 2 | loopa 1 | wonka 99
- `mobius_mobile_hud.html` — total 86 | oompa 28 | loopa 2 | wonka 56
- `deepBuddyOfflineBuilder.txt` — total 50 | oompa 20 | loopa 1 | wonka 29
- `Semantic CompressionSMIL.txt` — total 47 | oompa 0 | loopa 0 | wonka 47
- `conversations-june27-tiny-account-deepseek-sculpted.json` — total 39 | oompa 8 | loopa 12 | wonka 19
- `credlogs.txt` — total 24 | oompa 0 | loopa 16 | wonka 8
- `Farm.md` — total 19 | oompa 2 | loopa 6 | wonka 11


## Build use

Use this as a light/fun navigation layer:

- Yellow path = onboarding trail
- Rainbow = color-channel routes
- Loopa = repeatable helper micro-loop
- Wonka = transformation room / Cat Labs factory
- Oompa = chorus line / progress feedback / playful status narrator

## Boundary

This is a corpus pull and design-grammar extraction. It is not a new source truth claim.
