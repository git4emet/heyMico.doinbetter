# Yellow Brick / Loopa / Wonka Pull Receipt

```text
State:
  Executed

Current text sources with hits:
  32

Context snippets:
  247

Zip hits:
  51

Status:
  Extracted
```
