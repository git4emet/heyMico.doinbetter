from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class EvidenceState(str, Enum):
    CANON = "CANON"
    STRONG_SOURCECARD = "STRONG_SOURCECARD"
    BREADCRUMB_ONLY_PENDING_EXACT_MEMBER = "BREADCRUMB_ONLY_PENDING_EXACT_MEMBER"
    REFERENCE_SUMMARY_PENDING_EXACT_MEMBER = "REFERENCE_SUMMARY_PENDING_EXACT_MEMBER"
    BRICKROAD_PENDING_REUPLOAD_OR_DEEPER_NESTED_EXTRACTION = (
        "BRICKROAD_PENDING_REUPLOAD_OR_DEEPER_NESTED_EXTRACTION"
    )


class SubjectType(str, Enum):
    PERSON = "person"
    COHORT = "cohort"
    PROJECT = "project"


class RequestState(str, Enum):
    DISCOVERED = "DISCOVERED"
    SOURCE_LOCKED = "SOURCE_LOCKED"
    CONSENT_PENDING = "CONSENT_PENDING"
    ROUTABLE = "ROUTABLE"
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    COMPLETE = "COMPLETE"
    RETIRED = "RETIRED"


@dataclass(slots=True)
class SourceRef:
    source_title: str
    source_route: str
    exact_phrase: str
    nearby_context: str = ""
    source_kind: str = "chat_export"


@dataclass(slots=True)
class HelpRequest:
    request_id: str
    person_id: str
    display_name: str
    aliases: list[str]
    location: str | None
    request_summary: str
    requested_services: list[str]
    evidence_state: EvidenceState
    request_state: RequestState
    direct_request: bool
    consent_to_contact: bool | None
    consent_to_publish: bool | None
    subject_type: SubjectType = SubjectType.PERSON
    source_refs: list[SourceRef] = field(default_factory=list)
    uncertainty_notes: list[str] = field(default_factory=list)
    private_contact_ref: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["evidence_state"] = self.evidence_state.value
        data["request_state"] = self.request_state.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "HelpRequest":
        refs = [SourceRef(**item) for item in data.get("source_refs", [])]
        return cls(
            request_id=data["request_id"],
            subject_type=SubjectType(data.get("subject_type", "person")),
            person_id=data["person_id"],
            display_name=data["display_name"],
            aliases=list(data.get("aliases", [])),
            location=data.get("location"),
            request_summary=data["request_summary"],
            requested_services=list(data.get("requested_services", [])),
            evidence_state=EvidenceState(data["evidence_state"]),
            request_state=RequestState(data["request_state"]),
            direct_request=bool(data.get("direct_request", False)),
            consent_to_contact=data.get("consent_to_contact"),
            consent_to_publish=data.get("consent_to_publish"),
            source_refs=refs,
            uncertainty_notes=list(data.get("uncertainty_notes", [])),
            private_contact_ref=data.get("private_contact_ref"),
            metadata=dict(data.get("metadata", {})),
        )
