from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable


REQUEST_PATTERNS = (
    re.compile(r"\b(?:wants|wanted|needs|needed|asked for|would like)\b.{0,180}", re.I),
    re.compile(r"\bhelp (?:me|him|her|them)\b.{0,180}", re.I),
    re.compile(r"\ba buddy to\b.{0,180}", re.I),
)

NAME_PATTERN = re.compile(
    r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})\b"
)


@dataclass(frozen=True, slots=True)
class CandidateHit:
    exact_phrase: str
    nearby_context: str
    candidate_names: tuple[str, ...]


def iter_candidate_hits(text: str, context_window: int = 260) -> Iterable[CandidateHit]:
    """
    Yield candidate request phrases.

    This is intentionally recall-oriented. A human or higher-level resolver must
    decide whether each hit is a real request, a quote, a model suggestion, or noise.
    """
    for pattern in REQUEST_PATTERNS:
        for match in pattern.finditer(text):
            start = max(0, match.start() - context_window)
            end = min(len(text), match.end() + context_window)
            context = text[start:end]
            names = tuple(dict.fromkeys(NAME_PATTERN.findall(context)))
            yield CandidateHit(
                exact_phrase=match.group(0).strip(),
                nearby_context=context.strip(),
                candidate_names=names,
            )
