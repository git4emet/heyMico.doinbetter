from __future__ import annotations

from dataclasses import dataclass

from .models import HelpRequest


SERVICE_ROUTES = {
    # Memoir studio
    "story_capture": "services.memoir_studio",
    "memoir_ghostwriting": "services.memoir_studio",
    "onscreen_editing": "services.memoir_studio",
    "chapter_export": "services.memoir_studio",

    # theShelter
    "shared_solution_map": "services.the_shelter",
    "resource_navigation": "services.the_shelter",
    "caseworker_collaboration": "services.the_shelter",
    "consented_referral": "services.the_shelter",

    # Prison instruction
    "craft_instruction": "services.prison_instruction",
    "instructional_system": "services.prison_instruction",
    "letter_drafting": "services.prison_correspondence",
    "career_path_guidance": "services.guidance",

    # Repack and delivery
    "tedstage_repack": "services.tedstage_repack",
    "tablet_module": "services.tedstage_repack",
    "printable_workbook": "services.tedstage_repack",
}


@dataclass(frozen=True, slots=True)
class RouteDecision:
    request_id: str
    services: tuple[str, ...]
    unresolved: tuple[str, ...]


def resolve_services(record: HelpRequest) -> RouteDecision:
    resolved: list[str] = []
    unresolved: list[str] = []

    for requested in record.requested_services:
        target = SERVICE_ROUTES.get(requested)
        if target is None:
            unresolved.append(requested)
        else:
            resolved.append(target)

    return RouteDecision(
        request_id=record.request_id,
        services=tuple(dict.fromkeys(resolved)),
        unresolved=tuple(dict.fromkeys(unresolved)),
    )
