from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from .models import HelpRequest


class HelpRequestRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def load(self) -> list[HelpRequest]:
        if not self.path.exists():
            return []
        records: list[HelpRequest] = []
        for line_no, line in enumerate(
            self.path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if not line.strip():
                continue
            try:
                records.append(HelpRequest.from_dict(json.loads(line)))
            except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
                raise ValueError(f"Invalid registry row {line_no}: {exc}") from exc
        return records

    def write_all(self, records: Iterable[HelpRequest]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = "\n".join(
            json.dumps(record.to_dict(), ensure_ascii=False, sort_keys=True)
            for record in records
        )
        self.path.write_text(payload + ("\n" if payload else ""), encoding="utf-8")

    def append(self, record: HelpRequest) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(
                json.dumps(record.to_dict(), ensure_ascii=False, sort_keys=True) + "\n"
            )

    def by_person(self, person_id: str) -> list[HelpRequest]:
        return [record for record in self.load() if record.person_id == person_id]

    def routable(self) -> list[HelpRequest]:
        return [
            record
            for record in self.load()
            if record.direct_request
            and record.evidence_state.value in {"CANON", "STRONG_SOURCECARD"}
        ]
