from __future__ import annotations

from dataclasses import dataclass

from .models import EvidenceState, HelpRequest, RequestState


@dataclass(frozen=True, slots=True)
class GuardVerdict:
    decision: str  # allow | ask | block
    reasons: tuple[str, ...]


def evaluate_request(record: HelpRequest, action: str) -> GuardVerdict:
    """Evaluate a bounded action without assuming consent from a mere mention."""
    reasons: list[str] = []

    if not record.direct_request:
        reasons.append("No direct request is preserved.")

    if record.evidence_state not in {
        EvidenceState.CANON,
        EvidenceState.STRONG_SOURCECARD,
    }:
        reasons.append("Exact source-member recovery is incomplete.")

    if action == "contact" and record.consent_to_contact is not True:
        reasons.append("Consent to contact is not recorded.")

    if action == "publish" and record.consent_to_publish is not True:
        reasons.append("Consent to publish is not recorded.")

    if record.request_state in {RequestState.PAUSED, RequestState.RETIRED}:
        reasons.append(f"Request state is {record.request_state.value}.")

    if reasons:
        decision = "ask" if record.direct_request else "block"
        return GuardVerdict(decision=decision, reasons=tuple(reasons))

    return GuardVerdict(decision="allow", reasons=())
