# theShelter — solution-space specification

## Purpose

Help an unhoused person and one or more authorized caseworkers work on the same bounded problem space without flattening the person into a case file.

## Core surfaces

1. **My situation** — member-controlled description.
2. **What matters now** — needs, priorities, risks, and goals.
3. **People helping** — role-scoped collaborators.
4. **Resource map** — verified services, eligibility, status, and next action.
5. **Shared plan** — proposed actions with owner, due date, and dependency.
6. **Receipts** — referrals, submissions, appointments, outcomes, and returns.
7. **Private drawer** — documents and notes never projected publicly.

## Resource lifecycle

```text
discovered
→ verified
→ matched
→ member approved
→ referred
→ accepted | waitlisted | declined
→ follow-up
→ closed or returned
```

## Hard boundaries

- The member controls sharing.
- Caseworkers see only their authorized lane.
- Resource status is date-stamped.
- The public surface shows aggregate resources, never private case data.
- The system supports existing casework; it does not pretend to replace professional judgment.
