# Recovery rules

## Source law

```text
Breadcrumb is not trash.
Breadcrumb means:
preserve
→ route
→ mark exact-member recovery status
```

## People law

```text
person mention
≠ help request
≠ consent to contact
≠ consent to publish
```

A valid record separates:

- person identity
- exact request
- source route
- evidence state
- consent state
- service route
- public/private boundary
- uncertainty

## Promotion ladder

```text
DISCOVERED
→ SOURCE_LOCKED
→ CONSENT_PENDING
→ ROUTABLE
→ ACTIVE
→ COMPLETE
```

Source evidence classes:

```text
CANON
STRONG_SOURCECARD
BREADCRUMB_ONLY_PENDING_EXACT_MEMBER
REFERENCE_SUMMARY_PENDING_EXACT_MEMBER
BRICKROAD_PENDING_REUPLOAD_OR_DEEPER_NESTED_EXTRACTION
```

## Archive mining pass

1. Parse the outer ChatGPT export envelope.
2. Preserve conversation ID, timestamps, roles, attachments, and branches.
3. Search user-authored messages for request verbs.
4. Resolve names only from nearby evidence.
5. Separate quoted/model text from user-authored facts.
6. Create candidate records.
7. Require human review before contact or publication.
