# Prison instruction system

## Learning packet anatomy

```text
WHY
→ WHAT YOU NEED
→ SAFETY / FACILITY CHECK
→ STEP CARDS
→ TRY IT
→ TROUBLESHOOT
→ REFLECT
→ TEACH THE NEXT PERSON
```

## Craft lesson requirements

- use common, inexpensive, facility-approved materials
- provide substitutions
- separate prohibited tools from safe alternatives
- use short numbered steps
- include line drawings or high-contrast diagrams
- support low literacy and cognitive load
- work in print and on low-bandwidth tablets
- include authorship, attribution, and source receipts
- include a facilitator version and a learner version

## Instructing-system capabilities

- lesson template compiler
- reading-level adaptation
- visual-sequence generator
- materials constraint checker
- facility rule overlay
- self-check questions
- peer-teaching mode
- portfolio page
- TEDStage repack exporter
