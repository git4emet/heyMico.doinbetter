# TEDStage repacks

TEDStage is the presentation-and-instruction transform for turning lived experience, crafts, technical knowledge, and correspondence into bounded learning artifacts.

## Planned delivery targets

| Target | Current status | Role |
|---|---|---|
| Prison Professors | Planned | Possible curriculum/distribution target |
| Edovo | Planned | Possible correctional-tablet delivery target |

These names indicate intended packaging targets only. They do not indicate partnership, endorsement, acceptance, or platform access.

## Repack pipeline

```text
source testimony / lesson / craft
→ source-voice separation
→ rights and privacy check
→ talk spine
→ lesson spine
→ print/tablet variants
→ accessibility pass
→ facility-constraint pass
→ author approval
→ platform-specific review package
```

## Standard outputs

- 6–12 minute talk script
- one-page talk map
- learner workbook
- facilitator guide
- 5–10 minute micro-lessons
- captions and transcript
- audio-only script
- source/rights manifest
- review receipt
