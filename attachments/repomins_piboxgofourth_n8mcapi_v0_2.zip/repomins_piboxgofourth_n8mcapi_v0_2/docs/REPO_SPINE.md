# Full repository spine

```text
SOURCE
→ SENSE
→ SIEVE
→ FOLD
→ PERSON
→ REQUEST
→ CONSENT
→ SERVICE
→ GUARD
→ WITNESS
→ RETURN
```

## Planned packages

```text
src/repomins/
├── adapters/
│   ├── chatgpt_export.py
│   ├── gmail.py
│   ├── drive.py
│   ├── dropbox.py
│   ├── mcp.py
│   └── n8n.py
├── memberize/
├── normalize/
├── identity/
├── requests/
├── consent/
├── services/
│   ├── memoir_listener/
│   ├── prison_correspondence/
│   ├── community_intake/
│   └── guidance/
├── guardian/
├── tofar/
├── hud/
└── api/
```

## Required later passes

- exhaustive early-ChatGPT export scan
- alias resolution across repeated misspellings
- private contact lead verification
- audio/story-card ingestion for Jason's memoir lane
- Shawn/Jeremy correspondence memberization
- service-seat UI and receipts
- MCP and n8n runtime tests
