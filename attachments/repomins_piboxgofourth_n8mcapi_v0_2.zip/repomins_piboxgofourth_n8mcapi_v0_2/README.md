# repOminS PiB0XGOFourth n8mcAPi

**Release:** v0.2 service-lane correction  
**Normalized package name:** `repomins_piboxgofourth_n8mcapi`

This repository binds four distinct service organs into one consent-gated recovery and delivery spine:

```text
MEMOIR STUDIO
+ theShelter SOLUTION SPACE
+ PRISON INSTRUCTION SYSTEM
+ TEDStage REPACK PIPELINE
```

## Corrected service map

### 1. Boxer memoir studio

The boxer request is not merely “story cards.” It is a **Buddy-assisted ghostwriting and live onscreen editing workflow**:

```text
speak / type / upload
→ preserve source voice
→ outline
→ ghost-draft
→ compare with source
→ edit together onscreen
→ approve section
→ version and receipt
→ export memoir chapter
```

The named recovery record currently points to **Jason Litzau**. Contact, recording, publication, and attribution remain separately consented.

### 2. theShelter

`theShelter` is a **solution space for unhoused people and their caseworkers**, populated with the resources they can actually use.

```text
person + caseworker
→ shared situation map
→ needs and goals
→ resource graph
→ eligibility / availability check
→ proposed next steps
→ consented referral
→ progress and return path
```

It is not a public profile directory and it is not a case-management replacement. It is a collaborative planning, resource-navigation, and handoff surface.

### 3. Shawn, Jeremy, and Lifers

This lane provides **craft instructions and instructing systems** suitable for correctional settings:

- printable and tablet-safe craft lessons
- low-cost and facility-compliant materials
- plain-language steps
- visual sequence cards
- facilitator notes
- learner check-ins
- portfolio and reflection pages
- authorship and source-voice preservation

Individual correspondence remains private unless separately approved.

### 4. TEDStage repacks

**Prison Professors** and **Edovo** are recorded as planned external packaging/distribution targets for prison-safe TEDStage repacks—not as confirmed partners or authorities.

A TEDStage repack can produce:

- short talk script
- lesson plan
- printable workbook
- facilitator guide
- tablet module
- captions/transcript
- audio script
- source and rights manifest
- accessibility and facility-compliance checklist

## Governing invariants

1. A mention is not a request.
2. A request is not publication consent.
3. Ghostwriting must preserve the speaker's authorship and approval.
4. Caseworker collaboration must be role- and consent-scoped.
5. Prison materials must be safe, lawful, accessible, and facility-aware.
6. External platforms are delivery adapters; they do not own the learners, source voice, or canon.
7. Every transformation retains provenance and a return path.

## Tests

```bash
python -m unittest discover -s tests -v
```

## Optional API

```bash
pip install -r requirements-optional.txt
PYTHONPATH=src uvicorn api.app:app --reload --port 8091
```
