# Private data boundary

This folder is intentionally empty.

Do not commit:

- phone numbers
- prison identifiers
- home addresses
- private email addresses
- medical details
- unpublished memoir recordings
- consent documents containing signatures

Use opaque references such as `private://person/request` in the public registry.
