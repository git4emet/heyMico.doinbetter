from __future__ import annotations

from pathlib import Path

try:
    from fastapi import FastAPI, HTTPException
except ImportError as exc:  # pragma: no cover
    raise RuntimeError(
        "FastAPI is optional. Install with: pip install fastapi uvicorn"
    ) from exc

from repomins.guard import evaluate_request
from repomins.registry import HelpRequestRegistry
from repomins.service_router import resolve_services

app = FastAPI(
    title="repOminS PiB0XGOFourth n8mcAPi",
    version="0.1.0",
)

REGISTRY = HelpRequestRegistry(
    Path(__file__).resolve().parents[1] / "data" / "seed" / "help_requests.jsonl"
)


@app.get("/health")
def health() -> dict:
    return {"ok": True, "service": "help-request-registry"}


@app.get("/v1/help-requests")
def list_help_requests() -> list[dict]:
    return [record.to_dict() for record in REGISTRY.load()]


@app.get("/v1/help-requests/{request_id}")
def get_help_request(request_id: str) -> dict:
    for record in REGISTRY.load():
        if record.request_id == request_id:
            return {
                "record": record.to_dict(),
                "route": resolve_services(record).__dict__,
            }
    raise HTTPException(status_code=404, detail="Help request not found")


@app.get("/v1/help-requests/{request_id}/guard/{action}")
def guard_request(request_id: str, action: str) -> dict:
    for record in REGISTRY.load():
        if record.request_id == request_id:
            verdict = evaluate_request(record, action)
            return {
                "decision": verdict.decision,
                "reasons": list(verdict.reasons),
            }
    raise HTTPException(status_code=404, detail="Help request not found")
