import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from repomins.guard import evaluate_request
from repomins.models import EvidenceState, HelpRequest, RequestState, SourceRef
from repomins.registry import HelpRequestRegistry
from repomins.service_router import resolve_services


class RegistryTests(unittest.TestCase):
    def make_record(self) -> HelpRequest:
        return HelpRequest(
            request_id="HR-9999",
            person_id="person.test",
            display_name="Test Person",
            aliases=[],
            location=None,
            request_summary="Asked for help.",
            requested_services=["memoir_ghostwriting", "onscreen_editing"],
            evidence_state=EvidenceState.STRONG_SOURCECARD,
            request_state=RequestState.CONSENT_PENDING,
            direct_request=True,
            consent_to_contact=None,
            consent_to_publish=None,
            source_refs=[
                SourceRef(
                    source_title="test.txt",
                    source_route="local::test.txt",
                    exact_phrase="Please help me.",
                )
            ],
        )

    def test_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "registry.jsonl"
            registry = HelpRequestRegistry(path)
            registry.write_all([self.make_record()])
            loaded = registry.load()
            self.assertEqual(loaded[0].request_id, "HR-9999")

    def test_contact_requires_consent(self):
        verdict = evaluate_request(self.make_record(), "contact")
        self.assertEqual(verdict.decision, "ask")
        self.assertIn("Consent to contact is not recorded.", verdict.reasons)

    def test_service_route(self):
        route = resolve_services(self.make_record())
        self.assertEqual(route.services, ("services.memoir_studio",))


if __name__ == "__main__":
    unittest.main()
