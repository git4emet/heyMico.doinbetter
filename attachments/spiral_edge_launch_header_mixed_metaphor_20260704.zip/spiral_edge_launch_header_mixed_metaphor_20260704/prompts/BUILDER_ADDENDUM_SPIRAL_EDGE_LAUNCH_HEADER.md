# Builder Addendum — Spiral Edge Launch Header

Add the Spiral Edge Launch Header module to PartyChain / Buddy.

Do not start over. Always rebuild from what we had PLUS THIS.

## Implementation target

Create an internal event object:

```text
SpiralEdgeLaunchHeader
```

It should include:
- source anchor
- triadic overlay fields
- heptadic gate results
- duplicate check result
- retrieved source card IDs
- SSE channel name
- coordinate point
- ledger event ID

## Usage

Use it when PartyChain needs to launch a clean stream update after:
- contact selection
- invite draft creation
- reply tunnel submission
- DeepSeek thread ecosystem import
- graphics asset route assignment
- duplicate asset/thread/person collapse

## Boundary

Physics/metaphor terms stay UI/design grammar.
The app implements event routing, duplicate resolution, retrieval, SSE, and ledger receipts.
