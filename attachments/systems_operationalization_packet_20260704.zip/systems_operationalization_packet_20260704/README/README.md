# Systems Operationalization Packet

This turns the hard-to-explain system into buildable parts.

## Open first

1. `runbooks/OPERATIONAL_RUNBOOK.md`
2. `prompts/BUILDER_PROMPT_OPERATIONALIZE_SYSTEMS.md`
3. `database/systems_operationalization_schema.sql`
4. `seeds/skill_registry_seed.json`

## Core shape

```text
CatLabs.studio
→ Dollhouse
→ Buddy Panel
→ Gideon Guidance
→ Magic Mirror
→ Deep Space Comms Security Profile
→ Spiral Edge Launch Header
→ Telemetry Receipt
```

## What this is

A build packet:
- tables
- skills
- workflows
- API contracts
- runbook
- source report

## What this is not

It does not connect to NASA.
It does not perform live connector actions.
It does not claim verified external facts.
