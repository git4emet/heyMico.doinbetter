# Runbook — Operationalizing the Hard Part

## Goal

Turn the hard-to-explain system into buttons, tables, receipts, and events.

## The one-line architecture

```text
CatLabs.studio
→ Dollhouse rooms
→ Buddy Panel
→ Gideon next-action guidance
→ Magic Mirror reflection
→ Deep Space Comms command envelope
→ Launch Header SSE/RAG event
→ Telemetry receipt
```

## First implementation pass

1. Import `database/systems_operationalization_schema.sql`.
2. Seed `seeds/skill_registry_seed.json`.
3. Create routes from `api/systems_api_contract.md`.
4. Add a Dollhouse screen with rooms:
   - Front Room
   - Mirror Room
   - Forge Room
   - Archive Room
   - Security Room
   - Geometry Room
5. Add Buddy Panel inside the Dollhouse.
6. Add Gideon as a socket first:
   - reads state
   - asks missing question
   - recommends next skill
   - writes receipt
7. Add Magic Mirror:
   - preview
   - normalize
   - compare
   - duplicate_check
   - route
   - receipt
8. Add Deep Space Comms security profile:
   - command envelope
   - idempotency key
   - replay guard
   - confirmation state
   - hash-linked telemetry receipt
9. Add Launch Header:
   - coordinate point
   - retrieved source cards
   - SSE channel
   - ledger/telemetry receipt

## Boundary

Deep Space Comms is a security design profile.
It is not a claim of NASA infrastructure.

Franklin/Magic Circle material is source-card geometry inspiration.
Historical/social claims stay held unless independently verified.
