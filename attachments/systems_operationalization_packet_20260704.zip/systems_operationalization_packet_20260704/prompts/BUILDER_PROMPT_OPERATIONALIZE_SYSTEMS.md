# Builder Prompt — Operationalize CatLabs / Dollhouse / Gideon / Magic Mirror

Continue the existing PartyChain / Buddy / CatLabs system.

Do not start over.

```text
Always rebuild from what we had PLUS THIS.
```

## Implement this exact shape

```text
CatLabs.studio
→ Dollhouse
→ Buddy Panel
→ Gideon Guidance
→ Magic Mirror
→ Deep Space Comms Security Profile
→ Spiral Edge Launch Header
→ Telemetry Receipt
```

## The hard idea made concrete

Gideon is not required to have all source files yet.
Create the socket now.

Gideon does four jobs:
1. read current state,
2. ask the missing question,
3. recommend the next skill,
4. write a guidance receipt.

Magic Mirror does five jobs:
1. preview,
2. normalize,
3. compare,
4. duplicate-check,
5. route/brake/hold/return with receipt.

Deep Space Comms means:
1. command envelope,
2. authentication/authorization state,
3. explicit confirmation state,
4. idempotency key,
5. replay guard,
6. hash-linked telemetry receipt,
7. degraded/offline mode,
8. Guardian brake.

Launch Header means:
1. coordinate point,
2. source anchor,
3. retrieved source cards,
4. duplicate-collapse result,
5. SSE channel,
6. receipt ID.

## Files to use

- `database/systems_operationalization_schema.sql`
- `seeds/skill_registry_seed.json`
- `seeds/operational_object_map.json`
- `workflows/systems_workflows.json`
- `api/systems_api_contract.md`
- `runbooks/OPERATIONAL_RUNBOOK.md`

## Product rule

Make it clickable:
- Open Dollhouse
- Open Buddy Panel
- Ask Gideon
- Reflect in Mirror
- Create Command Envelope
- Emit Launch Header
- Show Receipt
