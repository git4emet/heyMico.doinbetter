-- Systems Operationalization Schema
-- CatLabs / Dollhouse / Magic Mirror / Gideon / Buddy Panel / Deep Space Comms Profile / Franklin Geometry

CREATE TABLE IF NOT EXISTS source_card (
  id TEXT PRIMARY KEY,
  source_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  source_kind TEXT NOT NULL,          -- paste / zip / image / email / code / notebook / manual
  source_state TEXT NOT NULL,         -- extracted / specified / unresolved / verified
  path_hint TEXT,
  sha256 TEXT,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS interface_surface (
  id TEXT PRIMARY KEY,
  surface_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  surface_kind TEXT NOT NULL,         -- catlabs / dollhouse / mirror / buddy_panel / partychain
  route_path TEXT NOT NULL,
  state TEXT NOT NULL,                -- specified / implemented / active / held
  config_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dollhouse_room (
  id TEXT PRIMARY KEY,
  room_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  room_role TEXT NOT NULL,            -- intake / mirror / forge / archive / security / party / geometry
  surface_key TEXT NOT NULL,
  entry_skill_key TEXT,
  visual_refs_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS buddy_panel_module (
  id TEXT PRIMARY KEY,
  module_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  panel_zone TEXT NOT NULL,           -- center / left / right / top / bottom / mirror / edge
  watches_json TEXT NOT NULL,         -- skill states, guardian state, receipts, launch headers
  actions_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS skill_registry (
  id TEXT PRIMARY KEY,
  skill_key TEXT UNIQUE NOT NULL,
  provider TEXT NOT NULL,             -- local / google / gmail / people / security / rag / sse
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  requires_auth INTEGER NOT NULL DEFAULT 0,
  requires_user_confirmation INTEGER NOT NULL DEFAULT 1,
  allowed_states_json TEXT NOT NULL,
  input_schema_json TEXT NOT NULL,
  output_schema_json TEXT NOT NULL,
  route_path TEXT,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS magic_mirror_reflection (
  id TEXT PRIMARY KEY,
  source_object_type TEXT NOT NULL,
  source_object_id TEXT NOT NULL,
  mirror_mode TEXT NOT NULL,          -- preview / normalize / compare / duplicate_check / route / receipt
  before_json TEXT NOT NULL,
  reflected_json TEXT NOT NULL,
  guardian_state TEXT NOT NULL,       -- held / routed / braked / returned
  route_recommendation_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS gideon_guidance_event (
  id TEXT PRIMARY KEY,
  panel_module_key TEXT NOT NULL,
  context_anchor TEXT NOT NULL,
  observed_state_json TEXT NOT NULL,
  question TEXT,
  recommended_skill_key TEXT,
  recommended_action TEXT,
  route_state TEXT NOT NULL,          -- specified / held / executed / returned
  receipt_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS security_profile (
  id TEXT PRIMARY KEY,
  profile_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  profile_kind TEXT NOT NULL,         -- deep_space_comms
  controls_json TEXT NOT NULL,
  boundary_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS command_envelope (
  id TEXT PRIMARY KEY,
  command_key TEXT NOT NULL,
  requested_by TEXT,
  target_skill_key TEXT NOT NULL,
  auth_state TEXT NOT NULL,           -- local / oauth_needed / authorized / rejected
  confirmation_state TEXT NOT NULL,   -- pending / confirmed / braked / returned
  idempotency_key TEXT NOT NULL,
  replay_window_json TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telemetry_receipt (
  id TEXT PRIMARY KEY,
  command_envelope_id TEXT,
  event_type TEXT NOT NULL,
  source TEXT NOT NULL,
  hash_prev TEXT,
  hash_self TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS launch_header_event (
  id TEXT PRIMARY KEY,
  header_key TEXT UNIQUE NOT NULL,
  source_anchor TEXT NOT NULL,
  coordinate_json TEXT NOT NULL,
  triadic_overlay_json TEXT NOT NULL,
  heptadic_gate_json TEXT NOT NULL,
  duplicate_check_json TEXT NOT NULL,
  rag_query_json TEXT NOT NULL,
  sse_channel TEXT NOT NULL,
  ledger_receipt_id TEXT,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL
);