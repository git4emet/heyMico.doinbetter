# API Contract — Operationalized Systems

## POST /api/gideon/next-action

Input:
```json
{
  "context_anchor": "current_party_or_source",
  "observed_state": {}
}
```

Output:
```json
{
  "recommended_skill_key": "mirror.reflect.route",
  "question": "What should this become?",
  "route_state": "held",
  "receipt_id": "gideon_..."
}
```

## POST /api/mirror/reflect

Input:
```json
{
  "source_object_type": "source_card",
  "source_object_id": "src_...",
  "mirror_mode": "duplicate_check"
}
```

Output:
```json
{
  "guardian_state": "routed",
  "route_recommendation": {
    "target": "partychain_surface",
    "reason": "visual routing lead"
  },
  "receipt_id": "mirror_..."
}
```

## POST /api/security/command-envelope

Input:
```json
{
  "target_skill_key": "google.gmail.create_draft",
  "payload": {},
  "idempotency_key": "stable_unique_action_key"
}
```

Output:
```json
{
  "command_envelope_id": "cmd_...",
  "confirmation_state": "pending"
}
```

## POST /api/events/launch

Input:
```json
{
  "source_anchor": "mirror_receipt_...",
  "coordinate": {
    "surface": "catlabs",
    "room": "mirror_room",
    "panel": "buddy_panel"
  },
  "rag_query": {
    "source_card_ids": ["src_..."]
  }
}
```

Output:
```json
{
  "launch_header_id": "lh_...",
  "sse_channel": "partychain.launch",
  "receipt_id": "tel_..."
}
```
