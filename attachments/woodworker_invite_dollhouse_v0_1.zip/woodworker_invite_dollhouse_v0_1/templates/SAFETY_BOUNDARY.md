# Safety and Scope Boundary

This prototype supports woodworking, decorative fabrication, community craft, signage, display fixtures, wall art, storytelling, and clearly non-functional cosplay/display props.

It does not include dimensions, materials lists, sharpening methods, reinforcement advice, handling techniques, or any other guidance for making or improving a weapon.

The project label may reference a fictional object, but the collaboration invitation is for safe, non-functional art and maker work only.
