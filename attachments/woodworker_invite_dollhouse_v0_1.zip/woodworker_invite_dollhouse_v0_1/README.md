# Woodworker Invite Dollhouse v0.1

A reviewable invitation interface for a local woodworker or maker collaboration.

## Open

Open `site/index.html` in a browser.

## Included

- Invite dollhouse interface
- Generic recipient identity until confirmed
- Dave / D-Glasses Guy contact card
- Copyable invitation
- Safety boundary
- Search receipt
- Checksums

No message is sent automatically.
