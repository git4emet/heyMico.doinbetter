# 1.78× Resonance Multiplier — Mathematical Spec

## Core formula

```text
eligible = I[α >= 0.743] × I[GuardianPass] × I[F15Present]

CRED = eligible × 1.78 × B × α × G × F15 × P × Q
```

## Variables

- `B`: base intensity of contribution.
- `α`: trust/coherence score.
- `G`: Seven Gates aggregate.
- `F15`: Coherence Witness score.
- `P`: Mercury Switch phase factor.
- `Q`: TOFAR provenance confidence.

## Phase factors

```text
Spring: P = 0.25  seed potential
Summer: P = 0.60  refinement credit
Autumn: P = 1.00  full harvest mint
Winter: P = 0.40  persistence/reputation memory
```

These phase factors are specified defaults, not verified constants.

## Rule

The multiplier rewards resonance, not volume. A noisy high-volume contribution that fails Guardian/α/F15 mints zero CRED.
