# Skill Coin Trails Encyclopedic Almanac

**Generated:** 2026-07-03  
**Status:** Executed bounded extraction / normalization pass  
**Sources scanned:** 30  
**Unique inline/source code units extracted:** 2117  
**Skill Coin Trails generated:** 2117  
**Graphic artifact:** `graphics/mercury_switch_cred_phase_map.svg`

## Receipt

```text
ShiftEvent:
  skill_coin_trails_almanac_cred_populate_20260703

Status:
  Executed

Boundary:
  This pass extracts and normalizes code-like material from current focused sources
  plus the already-created PDF preview datablock.
  It is not a claim that every expired or graphical source has been exhaustively read.
```

## Seasonal Ledger

| Phase | Entry type | CRED phase behavior | Code units |
|---|---|---|---:|
| Spring / Ingestion / Init.0 | Seed Notes | P=0.25 — seed CRED potential only; source is captured, not fully minted | 484 |
| Summer / Refinement / Full Sail | Growth Notes | P=0.6 — refinement credit grows as routing and vocabulary stabilize | 22 |
| Autumn / Harvest / Extraction | Harvest Notes | P=1.0 — full CRED minting after harvest/witness/output | 1284 |
| Winter / Persistence / Rest | Root Notes | P=0.4 — audit/reputation memory credit; stabilizes root ledger rather than new expansion | 327 |


## 1.78× Resonance Multiplier

The multiplier belongs to the **INNER Tier / 0x1 WEIGH** primitive. It should not be treated as ambient decoration; it is applied only after the contribution passes the eligibility gate.

```text
eligible = 1 if:
  trust_alpha >= 0.743
  Guardian / Seven Gates pass
  F15 witness is present
  TOFAR provenance is logged

CRED = eligible × 1.78 × B × α × G × F15 × P × Q
```

Where:

```text
B    = base intensity
α    = trust / coherence
G    = Seven Gates aggregate score
F15  = Coherence Witness score
P    = Mercury Switch phase factor
Q    = TOFAR provenance confidence
```

## Phase Interaction

### Spring — Ingestion
The multiplier creates **CRED potential**, not final value. Seeds are captured, hashed, and held.

### Summer — Refinement
The multiplier is damped by refinement phase factor. Routing, matching, and folding raise the future mintability of the contribution.

### Autumn — Harvest
This is the full minting season. If the witness and gate conditions pass, CRED is minted into the ledger.

### Winter — Persistence
The multiplier stabilizes reputation/memory. Winter emphasizes audit, replay, and long-tail fidelity rather than expansion.

## SkillCore Tier Map

| Tier | Multiplier role |
|---|---|
| INNER | WEIGH enforces α ≥ 0.743, Seven Gates, Guardian, and ethical eligibility. |
| INTRA | FOLD/MATCH/SEND normalize the contribution, compute route clarity, and prepare SourceCards. |
| INTER | SURFACE/SERVE shows CRED receipts, dashboards, and user-facing ledgers without silent publication. |

## Almanac sections populated

```text
1. Seasonal Ledger                  ledgers/mercury_switch_phase_ledger.jsonl
2. Skill Coin Trails Index          ledgers/skill_coin_trails.jsonl
3. Inline Code Registry             ledgers/normalized_inline_code.jsonl
4. Conversational Spec Ledger       manifests/source_manifest.json
5. Holographic Vinyl Agency Tiles   implied by lane/tier/phase cards
6. Chromic Sieve Remixing Notes     this report + claim_status_ledger
```

## Verification status

```text
Almanac package:             Executed
Inline extraction:            Executed bounded pass
1.78 formula:                 Specified
CRED examples:                Simulated
Runtime execution of code:    Unresolved
Full corpus integration:      Unresolved
Economic/physical truth:      Rejected unless externally proven
```
