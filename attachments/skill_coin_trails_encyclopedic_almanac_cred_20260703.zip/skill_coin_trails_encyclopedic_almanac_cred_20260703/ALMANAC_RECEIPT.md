# Skill Coin Trails Almanac Receipt

```text
ShiftEvent:
  skill_coin_trails_almanac_cred_populate_20260703

Status:
  Executed

Sources scanned:
  30

Unique inline/source code units extracted:
  2117

Skill Coin Trails generated:
  2117

CRED formula:
  Specified

CRED examples:
  Simulated

Graphic artifact:
  graphics/mercury_switch_cred_phase_map.svg

Boundary:
  Bounded extraction from current focused sources plus PDF preview datablock; not full expired corpus integration; no runtime verification claimed.
```
