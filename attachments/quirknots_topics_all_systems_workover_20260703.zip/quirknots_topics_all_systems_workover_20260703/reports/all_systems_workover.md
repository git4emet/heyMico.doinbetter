# Quirknots All-Systems Workover

## IS Operator Patch

```text
IS before action.
STATE before judgment.
RECEIPT before promotion.
```

## System Matrix

### Guardian

Status: `Specified`

Operator grammar becomes IS-state assignment. Guardian names state, gate, boundary, and receipt.

Receives: T01_is_state_grammar, T03_link_atlas_privacy, T05_tool_nexus_seven_gates, T10_boundary_private_exports

### Almanac

Status: `Specified`

Topics become seasonal entries; Spring holds seeds, Summer routes, Autumn harvests, Winter persists.

Receives: T02_canonical_merge_law, T04_vinyl_ledger_replay, T12_hofstadter_scatter_merger

### SkillCore

Status: `Specified`

WEIGH, UNFOLD, FOLD, MATCH, SEND, SURFACE, SERVE, PERSIST receive topic-linked fun’ktiuns.

Receives: T05_tool_nexus_seven_gates, T06_maigll_bootfile, T08_mcp_affiliate_resources

### Connector Spring

Status: `Specified`

Connector actions stay seed-only: read/search/list/parse/stage/receipt, with user-named targets.

Receives: T03_link_atlas_privacy, T08_mcp_affiliate_resources, T10_boundary_private_exports

### Ledger / TOFAR / CRED

Status: `Specified`

Vinyl grooves, checkpoint_42, FAST replay, CRED trails, and 1.78 formula join one receipt spine.

Receives: T04_vinyl_ledger_replay, T08_mcp_affiliate_resources

### Canvas / HUD / JS-Web

Status: `Specified`

p5 visual frames, interference canvas, graph persistence, party games, and scatter-merger viewer share one local web lane.

Receives: T09_visual_hud_kaleidoscope, T11_party_browser_games, T12_hofstadter_scatter_merger

### Deployment Mesh

Status: `Extracted`

Raspberry Pi, ESP32, mobile, mesh, and Whisper++ become deployment specs with execution receipts pending.

Receives: T07_deployment_mesh

### Boot / Kernel / MCP

Status: `Specified`

MAIGLL, Tool Nexus, MCP resources, and affiliate tools are SourceCarded before runtime promotion.

Receives: T05_tool_nexus_seven_gates, T06_maigll_bootfile, T08_mcp_affiliate_resources

### Boundary Lens

Status: `Specified`

Private exports, share links, and PII lanes are INNER tier fuel with hash-only external handling.

Receives: T03_link_atlas_privacy, T10_boundary_private_exports

### Life Gets Paid Back First

Status: `Specified`

All public/party/deploy excitement is routed through body-first and manual-consent constraints.

Receives: T11_party_browser_games, T01_is_state_grammar

## Boundary

External calls state: zero. Connector mutation state: locked. Private export handling state: Guardian-held. Hardware run receipts: unresolved.
