# Quirknots Topic Highlights

Source: `Quirknots.txt`  
Bytes: 9,505,625  
Lines: 175,036  
SHA-256: `0e444ad8149a97d8272e373a06c6f7ff0d9cae85d32b7607ee3aced7a07c7819`  
Status: Executed

## T01_is_state_grammar — IS-state grammar / removal of negation-as-operator

State: `Specified`  
Systems: Guardian, Claim Ledger, Spring Connector Cycle, Party Kit, Almanac

System grammar shifts from erase/deny behavior into presence + state + route. Every object receives a named state.

Next route: Patch ledgers to use zero/locked/held/unresolved/rejected states.

## T02_canonical_merge_law — 12-stage canonical merge law

State: `Extracted`  
Systems: Archive Ingest, Functional Linguistics Merge, HUD, TOFAR, CRED

raw_surface → functional_inference → verb_engine → domain_slits → WE_map → photonic_vocab → symphonizer → seven_gates → MCP_runtime → HUD → TOFAR → CRED

Next route: Adopt as README epigraph and tier-alignment scaffold.

## T03_link_atlas_privacy — HTTPS link atlas with privacy review

State: `Extracted`  
Systems: Source Link Atlas, Boundary Lens, Connector Spring, Guardian

Quirknots includes a corpus-wide link extractor summary: unique links, occurrences, domain summary, category summary, and review flags.

Next route: Publish state: category/domain summaries only; raw link CSVs Guardian-held.

## T04_vinyl_ledger_replay — Vinyl Ledger / Cartridge / Needle / AutoSubstream

State: `Extracted`  
Systems: Ledger, FAST Memory, CRED Trail, Seasonal Recompute Engine

Append-only grooves, hash-chained events, checkpoint_42, FAST replay, and CRED trail create the archive-to-state replay layer.

Next route: Promote into local ledger module after tests.

## T05_tool_nexus_seven_gates — Tool Nexus with Seven Gates and provenance logger

State: `Extracted`  
Systems: Guardian, Tool Nexus, Whisper++, STT Dashboard, Provenance

Offline Flask tool server, tool definitions, entropy thresholds, FART/TOFAR-style provenance lines, ethics gates, repair/whisper/optimizer stubs.

Next route: Map to local-only tools; test one repair_stream route.

## T06_maigll_bootfile — MAIGLL bootfile / recursion kernel

State: `Specified`  
Systems: Boot, Caputo Registry, MCP Server, Skill Index

Bootfile lane proposes recursion, bit-mask logic, Caputo smoothing, shard recombination, and manifest edges to MCP/CAPUTO/GLIFT.

Next route: Register as SourceCard; execute only after code audit.

## T07_deployment_mesh — Deployment whitepaper / field guide

State: `Extracted`  
Systems: Raspberry Pi, ESP32, Whisper++, Community Mesh, Edge Deployment

Raspberry Pi, ESP32, mobile, community mesh, Whisper++ voice processing, and deployment tiers form a hardware field lane.

Next route: Keep as deployment spec; mark hardware execution unresolved until physical run receipt.

## T08_mcp_affiliate_resources — MCP resources and affiliate/CRED tools

State: `Specified`  
Systems: MCP, Affiliate Engine, Namecheap Lane, CRED, Revenue Domain

MCP server patterns expose tools/resources/prompts; affiliate link generation and Caputo-weighted revenue projections are described as tool candidates.

Next route: Simulated/private tool lane; external API action requires explicit unlock.

## T09_visual_hud_kaleidoscope — Visual HUD / p5 / spirograph / interference canvas

State: `Extracted`  
Systems: HUD, Kaleidoscope Lens, Einstein Ring Lens, Party Browser Kit, Canvas

JS visual surfaces include sefirah frames, spirograph rendering, interference canvas, SSE lamps, graph nodes, and localStorage persistence.

Next route: Fold into a local JS/Web scatter-merger viewer.

## T10_boundary_private_exports — Private export boundary lens

State: `Extracted`  
Systems: Boundary Lens, Guardian, Archive, Connector Spring

DeepSeek/user export lanes carry PII and conversation graphs; these are INNER tier fuel and receive private hash-only handling.

Next route: Reference by hash and SourceCard; quote state remains Guardian-held.

## T11_party_browser_games — Party/browser game lane

State: `Implemented`  
Systems: Fourth Party Kit, TimmyU/Game Lane, Manual Share Square, Life Gets Paid Back First

Game and browser surfaces become a local party square: manual share, games, receipts, and zero connector mutation.

Next route: Add source-backed game inventory during next read pass.

## T12_hofstadter_scatter_merger — Hofstadter loop + Einstein Ring scatter merger

State: `Specified`  
Systems: Fun’ktiun Atlas, Seasonal Recompute, Einstein Ring Lens, Kaleidoscope

Map enters mapped system; ring/kaleidoscope visualizes scatter recurrence; Guardian receipt turns strange loop into usable route.

Next route: Create local viewer target after source IDs are attached.

