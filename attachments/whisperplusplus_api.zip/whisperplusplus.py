import os
import tempfile
import whisper
from flask import Flask, request, jsonify

model = whisper.load_model("base")

def transcribe_audio(file_path):
    result = model.transcribe(file_path)
    return result["text"]
