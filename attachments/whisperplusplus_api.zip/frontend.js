async function sendAudioToWhisper(audioBlob) {
  const formData = new FormData();
  formData.append("audio", audioBlob, "recording.wav");

  const response = await fetch("/api/whisper++", {
    method: "POST",
    body: formData
  });

  const result = await response.json();
  document.getElementById("transcription-output").innerText = result.transcription || "Error transcribing.";
}

async function recordAudioAndSend() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const mediaRecorder = new MediaRecorder(stream);
  const audioChunks = [];

  mediaRecorder.ondataavailable = event => {
    audioChunks.push(event.data);
  };

  mediaRecorder.onstop = () => {
    const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
    sendAudioToWhisper(audioBlob);
  };

  mediaRecorder.start();
  setTimeout(() => mediaRecorder.stop(), 5000);
}
