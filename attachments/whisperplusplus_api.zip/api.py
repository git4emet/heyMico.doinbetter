from flask import Flask, request, jsonify
from whisperplusplus import transcribe_audio
import tempfile

app = Flask(__name__)

@app.route("/api/whisper++", methods=["POST"])
def whisper_api():
    if "audio" not in request.files:
        return jsonify({"error": "No audio file provided"}), 400

    audio_file = request.files["audio"]
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
        audio_file.save(temp_audio.name)
        transcription = transcribe_audio(temp_audio.name)

    return jsonify({"transcription": transcription})

if __name__ == "__main__":
    app.run(debug=True)
