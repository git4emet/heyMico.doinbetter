# PLUS THIS Graphics Rebuild Receipt

```text
State:
  Executed

Doctrine:
  always rebuild from what we had plus this

Sources:
  9

Archive members indexed:
  202

Graphics queued:
  21

Embedded interface candidates:
  37

External actions:
  0

Connector actions:
  0
```
