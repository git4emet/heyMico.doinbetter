# Puppy Protocol / Prime Chamber Ring Patch

Open first:
- `reports/PUPPY_PROTOCOL_PRIME_CHAMBER_REPORT.md`
- `prompts/BUILDER_ADDENDUM_PUPPY_PROTOCOL_PRIME_CHAMBER.md`

Core law:

```text
Don't rub my nose in it.
Show me where to go instead.
```

This turns errors, missing permissions, expired files, duplicate checks, and ambiguous replies into friendly next actions.

## Main files

- `database/puppy_protocol_prime_chamber_patch.sql`
- `seeds/puppy_protocol_skill_registry_patch.json`
- `workflows/puppy_protocol_route_not_rub.workflow.json`
- `indexes/prime_chamber_ring_zip_inventory.csv`
- `ledgers/prime_chamber_ring_text_hits.jsonl`
