# Builder Addendum — Puppy Protocols / Prime Chamber Ring

Continue the existing PartyChain / CatLabs / Buddy build.

Do not start over.

```text
Always rebuild from what we had PLUS THIS.
```

## New product law

```text
Don't rub my nose in it.
Show me where to go instead.
```

This becomes a system behavior, not just copy.

## Implement

Add:

```text
PuppyProtocol
RouteHint
CorrectionReceipt
PrimeChamberRing
```

Use:

```text
database/puppy_protocol_prime_chamber_patch.sql
seeds/puppy_protocol_skill_registry_patch.json
workflows/puppy_protocol_route_not_rub.workflow.json
```

## Behavior

When the system finds a problem:

Wrong behavior:
```text
No.
Invalid.
You did it wrong.
```

Correct behavior:
```text
State: held.
Reason: Google connection needed.
Next: Connect Google.
Why: Gmail draft creation needs permission.
```

## Apply everywhere

- Google/Gmail/Contacts permission flow
- missing source files
- expired source files
- duplicate contacts
- duplicate threads
- missing RSVP info
- ambiguous reply tunnel entries
- WobbleNode at ring edge
- Magic Mirror duplicate check
- Gideon next-action panel

## Prime Chamber Ring

The Prime Chamber Ring is the routing chamber for corrections:

```text
intake
→ mirror
→ Gideon guide
→ route hint
→ user action
→ correction receipt
```

## UI copy examples

```text
This path is held.
Go here next.

I found the snag.
Use this button.

That source is outside the active graph.
Drop it here and I’ll fold it in.

Google is needed for this rail.
Connect it when you are ready.

This reply can mean a few things.
Choose RSVP, Need, Help, or Bring.
```

## Tone

Friendly.
Puppy-training logic.
No shame.
No nose-rubbing.
Next step visible.
One button.
Receipt.
