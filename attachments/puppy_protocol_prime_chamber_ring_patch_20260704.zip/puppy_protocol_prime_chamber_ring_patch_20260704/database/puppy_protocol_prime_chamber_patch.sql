-- Puppy Protocols / Prime Chamber Ring operational patch
-- Purpose: replace shame/error loops with next-action routing.

CREATE TABLE IF NOT EXISTS human_training_protocol (
  id TEXT PRIMARY KEY,
  protocol_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  principle TEXT NOT NULL,          -- show_where_to_go / redirect_without_shame / route_not_rub
  trigger_state_json TEXT NOT NULL,
  response_pattern_json TEXT NOT NULL,
  allowed_actions_json TEXT NOT NULL,
  forbidden_actions_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS route_hint (
  id TEXT PRIMARY KEY,
  source_object_type TEXT NOT NULL,
  source_object_id TEXT NOT NULL,
  current_state TEXT NOT NULL,
  friction_label TEXT,
  next_place TEXT NOT NULL,
  next_action TEXT NOT NULL,
  why_this_way TEXT,
  confidence REAL,
  guardian_state TEXT NOT NULL,     -- route / brake / hold / return
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prime_chamber_ring (
  id TEXT PRIMARY KEY,
  chamber_key TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  ring_role TEXT NOT NULL,          -- intake / mirror / guide / route / receipt
  entry_condition_json TEXT NOT NULL,
  exit_condition_json TEXT NOT NULL,
  linked_skill_keys_json TEXT NOT NULL,
  visual_refs_json TEXT NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS correction_receipt (
  id TEXT PRIMARY KEY,
  actor TEXT,
  source_state TEXT NOT NULL,
  correction_type TEXT NOT NULL,    -- redirect / clarify / route / brake / hold
  old_path TEXT,
  new_path TEXT,
  message_shown TEXT NOT NULL,
  receipt_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);