# Puppy Protocol / Prime Chamber Ring Patch

**State:** Executed  
**Rule:** Always rebuild from what we had PLUS THIS.

## Uploaded image

```text
File:
  whoknows.png

State:
  present

Dimensions:
  1024 x 1536
```

## Uploaded archive

```text
File:
  pRIMEcHAMBERrING.zip

State:
  present

Archive members:
  2

Image-like members:
  0

Text/code/spec-like members:
  2

Text signal snippets:
  0
```

## Core operational law

```text
Don't rub my nose in it.
Show me where to go instead.
```

## System translation

```text
error
→ state assignment
→ route hint
→ one next action
→ correction receipt
```

## Integration into existing systems

```text
Guardian:
  route/brake/hold/return without shame

Gideon:
  asks missing question and points to next action

Magic Mirror:
  reflects before correcting

Buddy Panel:
  shows current state, next place, and receipt

Prime Chamber Ring:
  routes blocked/ambiguous states through intake → mirror → guide → route → receipt

PartyChain:
  turns errors into friendly party next steps

Google rail:
  missing permission becomes Connect Google, not failure copy

Expired source:
  source outside active graph; re-upload only that source
```

## Prime Chamber Ring function

```text
intake the snag
→ mirror it
→ guide it
→ show next place
→ receipt it
```

## Boundary

This packet operationalizes UI behavior and routing logic.  
No live connector actions were performed.
