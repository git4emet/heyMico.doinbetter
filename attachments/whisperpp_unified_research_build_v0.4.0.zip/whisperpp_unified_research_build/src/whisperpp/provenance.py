import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from uuid import uuid4

def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':')).encode()

@dataclass(frozen=True, slots=True)
class Receipt:
    receipt_id: str
    created_at: str
    action: str
    source_ref: str
    output_ref: str
    component: str
    component_version: str
    config_sha256: str
    previous_hash: str | None
    receipt_hash: str

class JsonlLedger:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _last_hash(self):
        if not self.path.exists() or not self.path.stat().st_size:
            return None
        return json.loads(self.path.read_text(encoding='utf-8').splitlines()[-1]).get('receipt_hash')

    def append(self, *, action, source_ref, output_ref, component, component_version, config):
        base = {
            'receipt_id': f'rcpt_{uuid4().hex}',
            'created_at': datetime.now(timezone.utc).isoformat(),
            'action': action,
            'source_ref': source_ref,
            'output_ref': output_ref,
            'component': component,
            'component_version': component_version,
            'config_sha256': sha256(canonical(config)).hexdigest(),
            'previous_hash': self._last_hash(),
        }
        receipt = Receipt(**base, receipt_hash=sha256(canonical(base)).hexdigest())
        with self.path.open('a', encoding='utf-8') as f:
            f.write(json.dumps(asdict(receipt), sort_keys=True) + '\n')
        return receipt
