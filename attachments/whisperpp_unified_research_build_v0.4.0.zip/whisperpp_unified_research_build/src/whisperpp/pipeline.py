from dataclasses import dataclass
from pathlib import Path
from whisperpp.events import CaptureEvent
from whisperpp.transcript import TranscriptRecord
from whisperpp.stages.normalization import normalize_text, presentation_projection

@dataclass(frozen=True)
class PipelineResult:
    event: object
    raw: object
    normalized: object
    presentation: object
    receipt: object

class Pipeline:
    def __init__(self, backend, ledger):
        self.backend = backend
        self.ledger = ledger

    def run(self, path):
        source = Path(path)
        event = CaptureEvent.from_path(source)
        raw = self.backend.transcribe(source, event.event_id)
        normalized = TranscriptRecord.create(event.event_id, raw.backend+':normalize', normalize_text(raw.text), raw.segments, {'derived_from':raw.record_id})
        presentation = TranscriptRecord.create(event.event_id, raw.backend+':presentation', presentation_projection(normalized.text), normalized.segments, {'derived_from':normalized.record_id})
        receipt = self.ledger.append(action='transcribe', source_ref=event.event_id, output_ref=presentation.record_id, component=self.backend.name, component_version=self.backend.version, config={'backend':self.backend.name})
        return PipelineResult(event, raw, normalized, presentation, receipt)
