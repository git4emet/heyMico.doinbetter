class OpsDomain:
    name = "ops"
    role = "viewport projection"
    def project(self, record):
        return {"domain":self.name, "role":self.role, "source_ref":getattr(record,"record_id",None)}
