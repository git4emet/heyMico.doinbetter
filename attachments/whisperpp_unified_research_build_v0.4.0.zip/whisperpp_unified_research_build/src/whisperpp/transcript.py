from dataclasses import dataclass, asdict, field
from typing import Any
from uuid import uuid4

@dataclass(frozen=True, slots=True)
class Segment:
    start_s: float
    end_s: float
    text: str
    confidence: float | None = None
    speaker: str | None = None

@dataclass(frozen=True, slots=True)
class TranscriptRecord:
    record_id: str
    event_id: str
    backend: str
    text: str
    segments: tuple[Segment, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(cls, event_id, backend, text, segments=(), metadata=None):
        return cls(f'tr_{uuid4().hex}', event_id, backend, text, tuple(segments), dict(metadata or {}))

    def to_dict(self):
        data = asdict(self)
        data['segments'] = [asdict(s) for s in self.segments]
        return data
