import re

def normalize_text(text):
    return re.sub(r'\s+', ' ', text).strip()

def presentation_projection(text):
    return normalize_text(text)
