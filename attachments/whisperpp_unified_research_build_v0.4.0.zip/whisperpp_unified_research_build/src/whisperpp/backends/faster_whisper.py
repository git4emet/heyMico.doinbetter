from whisperpp.backends.base import TranscriptionBackend
from whisperpp.transcript import TranscriptRecord, Segment

class FasterWhisperBackend(TranscriptionBackend):
    name = 'faster-whisper'
    version = 'adapter-1'

    def __init__(self, model_name='base', device='auto'):
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise RuntimeError('Install with: pip install faster-whisper') from exc
        self.model_name = model_name
        self.model = WhisperModel(model_name, device=device)

    def transcribe(self, path, event_id):
        parts, info = self.model.transcribe(str(path))
        segments = tuple(Segment(float(s.start), float(s.end), s.text, getattr(s,'avg_logprob',None)) for s in parts)
        return TranscriptRecord.create(event_id, self.name, ' '.join(s.text.strip() for s in segments), segments, {'model':self.model_name,'language':getattr(info,'language',None)})
