from whisperpp.backends.base import TranscriptionBackend
from whisperpp.transcript import TranscriptRecord, Segment

class OpenAIWhisperBackend(TranscriptionBackend):
    name = 'openai-whisper'
    version = 'adapter-1'

    def __init__(self, model_name='base'):
        try:
            import whisper
        except ImportError as exc:
            raise RuntimeError('Install with: pip install openai-whisper') from exc
        self.model_name = model_name
        self.model = whisper.load_model(model_name)

    def transcribe(self, path, event_id):
        result = self.model.transcribe(str(path))
        segments = tuple(Segment(float(s.get('start',0)), float(s.get('end',0)), str(s.get('text',''))) for s in result.get('segments', []))
        return TranscriptRecord.create(event_id, self.name, str(result.get('text','')), segments, {'model':self.model_name,'language':result.get('language')})
