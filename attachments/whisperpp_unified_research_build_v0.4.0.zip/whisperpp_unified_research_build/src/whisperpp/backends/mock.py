from whisperpp.backends.base import TranscriptionBackend
from whisperpp.transcript import TranscriptRecord, Segment

class MockBackend(TranscriptionBackend):
    name = 'mock'
    version = '1.0'

    def transcribe(self, path, event_id):
        text = f'[mock transcript for {path.name}]'
        return TranscriptRecord.create(event_id, self.name, text, (Segment(0.0, 1.0, text, 1.0),), {'model':'none','test_only':True})
