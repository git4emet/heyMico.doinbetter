from abc import ABC, abstractmethod

class TranscriptionBackend(ABC):
    name = 'base'
    version = '0'

    @abstractmethod
    def transcribe(self, path, event_id):
        raise NotImplementedError
