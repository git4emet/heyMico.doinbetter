import json, subprocess, tempfile
from pathlib import Path
from whisperpp.backends.base import TranscriptionBackend
from whisperpp.transcript import TranscriptRecord

class WhisperCppBackend(TranscriptionBackend):
    name = 'whisper.cpp'
    version = 'adapter-1'

    def __init__(self, binary, model):
        self.binary = binary
        self.model = model

    def transcribe(self, path, event_id):
        with tempfile.TemporaryDirectory(prefix='whisperpp-') as tmp:
            out = Path(tmp) / 'result'
            subprocess.run([self.binary, '-m', self.model, '-f', str(path), '-oj', '-of', str(out)], check=True, capture_output=True, text=True)
            payload = json.loads(out.with_suffix('.json').read_text(encoding='utf-8'))
        text = ' '.join(x.get('text','') for x in payload.get('transcription', [])).strip()
        return TranscriptRecord.create(event_id, self.name, text, metadata={'model_path':self.model})
