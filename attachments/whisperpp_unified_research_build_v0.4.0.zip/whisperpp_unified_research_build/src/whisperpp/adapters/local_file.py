class LocalFileAdapter:
    name = "local_file"
    def collect(self, locator: str):
        raise NotImplementedError("Connector not enabled in the offline core.")
