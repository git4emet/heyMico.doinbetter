class GoogleDriveAdapter:
    name = "google_drive"
    def collect(self, locator: str):
        raise NotImplementedError("Connector not enabled in the offline core.")
