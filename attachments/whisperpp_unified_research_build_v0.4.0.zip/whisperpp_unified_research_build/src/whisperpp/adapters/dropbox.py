class DropboxAdapter:
    name = "dropbox"
    def collect(self, locator: str):
        raise NotImplementedError("Connector not enabled in the offline core.")
