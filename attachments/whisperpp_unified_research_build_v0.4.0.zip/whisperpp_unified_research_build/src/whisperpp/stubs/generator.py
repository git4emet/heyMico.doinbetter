import re
from pathlib import Path

KINDS = {'adapter','backend','stage','skill','domain'}

TEMPLATES = {
    'adapter': '''class {class_name}Adapter:\n    name = "{slug}"\n    def collect(self, locator: str):\n        raise NotImplementedError("Add explicit authorization and provenance before enabling.")\n''',
    'backend': '''from whisperpp.backends.base import TranscriptionBackend\nclass {class_name}Backend(TranscriptionBackend):\n    name = "{slug}"\n    version = "0.1-stub"\n    def transcribe(self, path, event_id):\n        raise NotImplementedError\n''',
    'stage': '''class {class_name}Stage:\n    name = "{slug}"\n    def process(self, record):\n        return record\n''',
    'skill': '''class {class_name}Skill:\n    name = "{slug}"\n    def run(self, context: dict):\n        return {{"status":"stub", "skill":self.name, "context":context}}\n''',
    'domain': '''class {class_name}Domain:\n    name = "{slug}"\n    def project(self, record):\n        return {{"domain":self.name, "source_ref":getattr(record,"record_id",None)}}\n''',
}

def clean_slug(value):
    slug = re.sub(r'[^a-zA-Z0-9_]+', '_', value.strip()).strip('_').lower()
    if not slug or slug[0].isdigit():
        raise ValueError('invalid name')
    return slug

def class_name(slug):
    return ''.join(part.capitalize() for part in slug.split('_'))

def generate(project_root, kind, name, overwrite=False):
    if kind not in KINDS:
        raise ValueError(f'kind must be one of {sorted(KINDS)}')
    slug = clean_slug(name)
    folder = {'adapter':'adapters','backend':'backends','stage':'stages','skill':'skills','domain':'domains'}[kind]
    target = Path(project_root)/'src'/'whisperpp'/folder/f'{slug}.py'
    if target.exists() and not overwrite:
        raise FileExistsError(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(TEMPLATES[kind].format(slug=slug, class_name=class_name(slug)), encoding='utf-8')
    return target
