import argparse, json, os, sys
from pathlib import Path
from dataclasses import asdict
from whisperpp.backends.mock import MockBackend
from whisperpp.expression_lattice import expression_id
from whisperpp.pipeline import Pipeline
from whisperpp.provenance import JsonlLedger
from whisperpp.stubs.generator import generate

def doctor(_):
    print(json.dumps({'python':sys.version.split()[0], 'network_default':False, 'backend_default':os.getenv('WHISPERPP_BACKEND','mock'), 'expression_0':expression_id(0), 'status':'ok'}, indent=2))
    return 0

def transcribe(args):
    if args.backend != 'mock':
        raise SystemExit('Minimal CLI enables mock only; configure optional backends in deployment code.')
    result = Pipeline(MockBackend(), JsonlLedger('runtime/events.jsonl')).run(args.path)
    print(json.dumps({'event':result.event.to_dict(), 'raw':result.raw.to_dict(), 'presentation':result.presentation.to_dict(), 'receipt':asdict(result.receipt)}, indent=2))
    return 0

def demo(_):
    fixture = Path('examples/sample_audio.placeholder')
    fixture.parent.mkdir(parents=True, exist_ok=True)
    if not fixture.exists(): fixture.write_text('mock media', encoding='utf-8')
    return transcribe(argparse.Namespace(path=str(fixture), backend='mock'))

def stub(args):
    print(generate(Path(args.root), args.kind, args.name, args.overwrite))
    return 0

def main():
    parser = argparse.ArgumentParser(prog='whisperpp')
    sub = parser.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('doctor'); p.set_defaults(func=doctor)
    p = sub.add_parser('demo'); p.set_defaults(func=demo)
    p = sub.add_parser('transcribe'); p.add_argument('path'); p.add_argument('--backend', default='mock'); p.set_defaults(func=transcribe)
    p = sub.add_parser('stub'); p.add_argument('kind', choices=['adapter','backend','stage','skill','domain']); p.add_argument('name'); p.add_argument('--root', default='.'); p.add_argument('--overwrite', action='store_true'); p.set_defaults(func=stub)
    args = parser.parse_args()
    return args.func(args)

if __name__ == '__main__':
    raise SystemExit(main())
