from hashlib import blake2b
EXPRESSION_COUNT = 8888

def expression_id(index, seed='whisperpp'):
    if not 0 <= index < EXPRESSION_COUNT:
        raise ValueError('index out of range')
    digest = blake2b(f'{seed}:{index}'.encode(), digest_size=6).hexdigest()
    return f'expr_{index:04d}_{digest}'

def iter_expression_ids(seed='whisperpp'):
    for i in range(EXPRESSION_COUNT):
        yield expression_id(i, seed)
