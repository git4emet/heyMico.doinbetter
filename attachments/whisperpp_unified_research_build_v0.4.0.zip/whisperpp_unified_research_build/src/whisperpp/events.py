from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any
from uuid import uuid4

@dataclass(frozen=True, slots=True)
class CaptureEvent:
    schema_version: str
    event_id: str
    created_at: str
    source: str
    media_sha256: str
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_path(cls, path, metadata=None):
        p = Path(path)
        return cls('1.0', f'evt_{uuid4().hex}', datetime.now(timezone.utc).isoformat(), str(p), sha256(p.read_bytes()).hexdigest(), dict(metadata or {}))

    def to_dict(self):
        return asdict(self)
