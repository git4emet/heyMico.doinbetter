# Whisper++ Unified Research Build

Offline-first scaffold consolidating the DoinBetter-Fractal-Whisper lane with shared provenance patterns from ALTA Survey, Floodwater, and the ops-console.

## Included

- immutable capture events
- append-only hash-chained receipts
- mock, OpenAI Whisper, faster-whisper, and whisper.cpp backend adapters
- raw, normalized, and presentation projections
- 42-face concept registry
- deterministic 8,888-expression namespace
- speech, survey, hydro, and ops domain projections
- dynamic stub generator
- connector stubs that require explicit user authorization
- research/source inventory and safety notes

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
whisperpp doctor
whisperpp demo
```

Generate a component:

```bash
whisperpp stub adapter gmail
whisperpp stub backend whisper_cpp
whisperpp stub skill terminology_resolver
```

No credentials, model weights, or silent network access are included.
