#!/usr/bin/env python3
import hashlib, json, sys
from pathlib import Path
root = Path(sys.argv[1] if len(sys.argv)>1 else '.')
rows = []
for path in sorted(p for p in root.rglob('*') if p.is_file() and '.git' not in p.parts):
    data = path.read_bytes()
    rows.append({'path':str(path.relative_to(root)), 'size':len(data), 'sha256':hashlib.sha256(data).hexdigest(), 'suffix':path.suffix.lower()})
print(json.dumps(rows, indent=2))
