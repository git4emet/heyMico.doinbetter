# Source Inventory

## Gmail sampled
- `fwdtothe4th8th`: Whisper/Caputo text, HUD integration, research report, inventory, domains, GGML trace
- `STACKEDDEEP!`: nested project-email archive
- `primeBuddy8009 beta voxel`: TinyBox/HUD/Seven-Gate architecture description
- `BuddyHeptadic`: retained only as a modular-topology idea

## Google Drive sampled
- `Whisper++ Offline Voice Deployment.pdf`
- `Whisper++ STT: Unified Offline Voice Ingestion`
- `Mobii3us_Whitepaper_WhisperPlusPlus.pdf`
- `WhisperStream.PDF`
- multiple `whisper.html` snapshots
- ALTA Survey and integration-manifest documents

## Dropbox sampled
- `/py/Whisper++app.py`
- `/txt/whisperplusplus.txt`
- `/txt/Whisper++_250808_103218.txt`
- `/py/whisper_glue.py`
- several Whisper++ ZIPs

## Canva and Figma
No relevant Whisper/Mobiius Canva design was returned. No Figma file key was discoverable in the sampled sources, so only safe connector stubs are included.

## Public primary sources
- OpenAI Whisper
- ggml-org whisper.cpp
- SYSTRAN faster-whisper
- WhisperX
- pyannote.audio

## Limits
This is a selective, provenance-aware synthesis, not a byte-for-byte export of every account or nested archive. Historical performance claims without reproducible data were excluded from the verified layer.
