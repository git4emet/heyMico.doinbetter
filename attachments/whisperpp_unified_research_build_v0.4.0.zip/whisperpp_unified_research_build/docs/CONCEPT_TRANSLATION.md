# Concept Translation

| Project term | Engineering interpretation |
|---|---|
| Whisper++ | orchestration around one or more STT engines |
| Crystal core | minimal event/transcript/provenance kernel |
| Fizzy Bubble | live operator viewport |
| Fizz Mill | batch/stream pipeline |
| Fuzz Box | noisy-input test harness |
| Charcoal | minimal dark UI skin |
| Kitty/Cat | friendly local-device profile |
| Shelter | privacy-sensitive workflow profile |
| Lab | isolated experimental features |
| Class | teaching/annotation workspace |
| Hats | roles and permissions |
| TED Talk Coach | opt-in delivery-feedback subscriber |
| Wonka Holodeck | synthetic demo/visualization generator |
| 42 faces | concept registry slots |
| 8,888 expressions | deterministic state/view IDs |
| TOFAR | provenance receipt family |
