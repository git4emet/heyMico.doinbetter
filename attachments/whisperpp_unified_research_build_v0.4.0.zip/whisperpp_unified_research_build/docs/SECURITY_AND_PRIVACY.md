# Security and Privacy

- Local processing is the default.
- Network access requires explicit enablement.
- Connector adapters require user-authorized credentials supplied at runtime.
- Audio and transcripts are never silently uploaded.
- Raw media, raw transcript, and presentation transcript have separate retention controls.
- Do not infer speaker identity, emotion, mental state, honesty, morality, or intent merely from voice features.
- Production deployments need file-size limits, MIME checks, malware scanning, encryption at rest, access controls, and deletion tests.
