# Public Research Notes

- OpenAI Whisper is a general-purpose multitask sequence-to-sequence speech model supporting multilingual recognition, translation, and language identification.
- whisper.cpp is a C/C++ port oriented toward portable local inference.
- faster-whisper uses CTranslate2 for efficient Python CPU/GPU execution.
- WhisperX adds word-level alignment and can integrate diarization.
- pyannote.audio provides diarization, speech-activity, speaker-change, and overlap components.

Whisper++ should wrap these engines rather than fork their internals prematurely. Its distinct value belongs in provenance, routing, evaluation, UI, domain adapters, and optional research stages.
