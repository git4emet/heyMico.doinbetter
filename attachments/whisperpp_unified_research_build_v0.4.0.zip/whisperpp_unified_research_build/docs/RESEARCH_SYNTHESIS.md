# Research Synthesis

The historical Whisper++ material contains three layers:

1. **Implementable software:** local speech-to-text, segmentation, streaming, raw/presentation projections, JSONL ledgers, HUD integration, and domain routing.
2. **Research hypotheses:** fractal-dimension features as auxiliary VAD or quality signals, fractional-memory smoothing, and multi-dimensional tagging.
3. **Project vocabulary:** Fizzy Bubble, Fizz Mill, Fuzz Box, Charcoal, crystal core, glyph plate, 42 faces, and 8,888 expressions.

This build preserves all three but labels them. Metaphor never substitutes for a benchmark, and acoustic features are not treated as proof of morality, identity, honesty, emotion, or intent.

## Consolidated flow

```text
Authorized input
  -> immutable CaptureEvent
  -> optional VAD/chunking
  -> selected STT backend
  -> raw TranscriptRecord
  -> normalization/alignment
  -> presentation projection
  -> independent domain subscribers
  -> append-only provenance ledger
  -> HUD/reports/exports
```

## Shared lanes

| Lane | Role | Common record family |
|---|---|---|
| Fractal Whisper | speech capture/transcription | event, transcript, receipt |
| ALTA Survey | field notes/spatial evidence | event, artifact, receipt |
| Floodwater | hydrologic observations | event, observation, receipt |
| Ops Console | orchestration/views | references derived records |

The practical common core is an event model, provenance, typed adapters, independent subscribers, and replayable logs.

## Legacy findings translated into design

- The Flask prototype proves the intended transcription API but mixes flood data, model loading, optimization, Redis, and audio handling; the new scaffold separates those concerns.
- The tiny direct-Whisper prototype becomes a minimal backend interface.
- The two-stream idea becomes neutral `raw` and `presentation` projections with lineage.
- HUD/SSE and Guardian-style outputs remain subscribers, not kernel mutations.
- 8D/42D tagging is represented as an extensible registry, not a claim of validated semantic or ethical inference.

## Recommended first deployment

- whisper.cpp for portable CPU-first local execution
- faster-whisper for efficient Python/CTranslate2 inference
- optional WhisperX and pyannote.audio for alignment/diarization
- explicit VAD
- media fingerprint plus model/config receipt for every run
- consent and retention controls
