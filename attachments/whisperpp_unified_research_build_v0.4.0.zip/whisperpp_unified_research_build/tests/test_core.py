from whisperpp.events import CaptureEvent
from whisperpp.backends.mock import MockBackend
from whisperpp.pipeline import Pipeline
from whisperpp.provenance import JsonlLedger
from whisperpp.expression_lattice import expression_id, EXPRESSION_COUNT
from whisperpp.stubs.generator import generate

def test_core(tmp_path):
    media = tmp_path/'x.wav'; media.write_bytes(b'abc')
    event = CaptureEvent.from_path(media)
    assert event.media_sha256 == 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
    result = Pipeline(MockBackend(), JsonlLedger(tmp_path/'events.jsonl')).run(media)
    assert result.raw.event_id == result.event.event_id
    assert EXPRESSION_COUNT == 8888 and expression_id(8887).startswith('expr_8887_')
    target = generate(tmp_path, 'adapter', 'sample source')
    assert 'SampleSourceAdapter' in target.read_text()
