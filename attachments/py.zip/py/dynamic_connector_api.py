#!/usr/bin/env python3
"""
Dynamic Connector API
Extensible interface for adding new data sources to the Möbii³us reconciliation engine.
Supports: CSV files, JSON data, API endpoints, Gmail, Slack, GitHub, and custom connectors.

API Endpoints:
  POST /api/connectors          - Register new connector
  GET  /api/connectors          - List all connectors
  POST /api/connectors/{id}/sync - Trigger sync for connector
  GET  /api/metrics             - Get current system metrics
  POST /api/reconcile           - Trigger incremental reconciliation

Design Pattern: Plugin architecture with connector registry.
Each connector implements: connect(), fetch(), transform(), validate()
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from pathlib import Path
import json
import csv
from datetime import datetime
from typing import Dict, List, Any, Optional
import hashlib
import subprocess

app = Flask(__name__)
CORS(app)

# Connector registry
CONNECTORS = {}
CONNECTOR_STORE = Path('/home/claude/connectors.json')
STATE_FILE = Path('/home/claude/reconciliation_state.json')

class BaseConnector:
    """Base class for all connectors"""
    def __init__(self, config: Dict):
        self.config = config
        self.id = config.get('id') or self._generate_id()
        self.name = config['name']
        self.type = config['type']
        self.status = 'pending'
        self.records_count = 0
        self.last_sync = None
        
    def _generate_id(self) -> str:
        """Generate unique connector ID"""
        timestamp = datetime.now().isoformat()
        hash_input = f"{self.name}_{timestamp}"
        return hashlib.md5(hash_input.encode()).hexdigest()[:12]
    
    def connect(self) -> bool:
        """Establish connection to data source"""
        raise NotImplementedError
    
    def fetch(self) -> List[Dict]:
        """Fetch data from source"""
        raise NotImplementedError
    
    def transform(self, data: List[Dict]) -> List[Dict]:
        """Transform data to standard format"""
        return data
    
    def validate(self, data: List[Dict]) -> bool:
        """Validate data meets requirements"""
        return len(data) > 0
    
    def sync(self) -> Dict:
        """Execute full sync cycle"""
        try:
            if not self.connect():
                return {'status': 'error', 'message': 'Connection failed'}
            
            raw_data = self.fetch()
            transformed = self.transform(raw_data)
            
            if not self.validate(transformed):
                return {'status': 'error', 'message': 'Validation failed'}
            
            self.records_count = len(transformed)
            self.status = 'active'
            self.last_sync = datetime.now().isoformat()
            
            return {
                'status': 'success',
                'records': self.records_count,
                'timestamp': self.last_sync
            }
        except Exception as e:
            self.status = 'error'
            return {'status': 'error', 'message': str(e)}
    
    def to_dict(self) -> Dict:
        """Serialize connector state"""
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type,
            'status': self.status,
            'records': self.records_count,
            'last_sync': self.last_sync,
            'config': self.config
        }

class CSVConnector(BaseConnector):
    """Connector for CSV files"""
    def connect(self) -> bool:
        filepath = Path(self.config.get('filepath', ''))
        return filepath.exists() and filepath.suffix == '.csv'
    
    def fetch(self) -> List[Dict]:
        filepath = Path(self.config['filepath'])
        data = []
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            data = list(reader)
        return data

class JSONConnector(BaseConnector):
    """Connector for JSON files"""
    def connect(self) -> bool:
        filepath = Path(self.config.get('filepath', ''))
        return filepath.exists() and filepath.suffix == '.json'
    
    def fetch(self) -> List[Dict]:
        filepath = Path(self.config['filepath'])
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # Handle both array and object with array property
        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            # Look for common array properties
            for key in ['items', 'data', 'results', 'records']:
                if key in data and isinstance(data[key], list):
                    return data[key]
        return []

class APIConnector(BaseConnector):
    """Connector for HTTP API endpoints"""
    def connect(self) -> bool:
        # TODO: Implement HTTP connection check
        return True
    
    def fetch(self) -> List[Dict]:
        # TODO: Implement HTTP fetch with requests library
        # For now, return empty to prevent errors
        return []

class GmailConnector(BaseConnector):
    """Connector for Gmail API"""
    def connect(self) -> bool:
        # TODO: Implement Gmail OAuth flow
        # Check for credentials.json and token.pickle
        return Path(self.config.get('credentials_path', 'credentials.json')).exists()
    
    def fetch(self) -> List[Dict]:
        # TODO: Implement Gmail API fetch
        # For now, simulate with draft count from config
        draft_count = self.config.get('draft_count', 97)
        return [{'type': 'draft', 'index': i} for i in range(draft_count)]

class SlackConnector(BaseConnector):
    """Connector for Slack API"""
    def connect(self) -> bool:
        # TODO: Implement Slack OAuth flow
        return 'token' in self.config
    
    def fetch(self) -> List[Dict]:
        # TODO: Implement Slack API fetch
        return []

class GitHubConnector(BaseConnector):
    """Connector for GitHub API"""
    def connect(self) -> bool:
        # TODO: Implement GitHub auth
        return 'repo' in self.config
    
    def fetch(self) -> List[Dict]:
        # TODO: Implement GitHub API fetch
        return []

# Connector factory
CONNECTOR_CLASSES = {
    'csv': CSVConnector,
    'json': JSONConnector,
    'api': APIConnector,
    'gmail': GmailConnector,
    'slack': SlackConnector,
    'github': GitHubConnector
}

def create_connector(config: Dict) -> BaseConnector:
    """Factory method to create connector instance"""
    connector_type = config['type']
    if connector_type not in CONNECTOR_CLASSES:
        raise ValueError(f"Unknown connector type: {connector_type}")
    
    connector_class = CONNECTOR_CLASSES[connector_type]
    return connector_class(config)

def load_connectors():
    """Load connectors from persistent storage"""
    global CONNECTORS
    if CONNECTOR_STORE.exists():
        with open(CONNECTOR_STORE, 'r') as f:
            stored = json.load(f)
            for config in stored:
                try:
                    connector = create_connector(config)
                    CONNECTORS[connector.id] = connector
                except Exception as e:
                    print(f"Failed to load connector {config.get('name')}: {e}")

def save_connectors():
    """Save connectors to persistent storage"""
    configs = [conn.to_dict() for conn in CONNECTORS.values()]
    with open(CONNECTOR_STORE, 'w') as f:
        json.dump(configs, f, indent=2)

# API Routes
@app.route('/api/connectors', methods=['GET'])
def list_connectors():
    """List all registered connectors"""
    return jsonify({
        'connectors': [conn.to_dict() for conn in CONNECTORS.values()],
        'count': len(CONNECTORS)
    })

@app.route('/api/connectors', methods=['POST'])
def register_connector():
    """Register a new connector"""
    config = request.json
    
    # Validate required fields
    if 'name' not in config or 'type' not in config:
        return jsonify({'error': 'Missing required fields: name, type'}), 400
    
    try:
        connector = create_connector(config)
        CONNECTORS[connector.id] = connector
        save_connectors()
        
        return jsonify({
            'status': 'success',
            'connector': connector.to_dict()
        }), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/connectors/<connector_id>/sync', methods=['POST'])
def sync_connector(connector_id: str):
    """Trigger sync for specific connector"""
    if connector_id not in CONNECTORS:
        return jsonify({'error': 'Connector not found'}), 404
    
    connector = CONNECTORS[connector_id]
    result = connector.sync()
    save_connectors()
    
    return jsonify(result)

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    """Get current system metrics"""
    if STATE_FILE.exists():
        with open(STATE_FILE, 'r') as f:
            state = json.load(f)
        return jsonify(state.get('metrics', {}))
    else:
        return jsonify({'error': 'No metrics available'}), 404

@app.route('/api/reconcile', methods=['POST'])
def trigger_reconcile():
    """Trigger incremental reconciliation"""
    try:
        # Run reconciliation engine
        result = subprocess.run(
            ['python3', '/home/claude/init0_reconciliation_engine.py'],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            # Load updated metrics
            with open(STATE_FILE, 'r') as f:
                state = json.load(f)
            
            return jsonify({
                'status': 'success',
                'metrics': state.get('metrics', {}),
                'output': result.stdout
            })
        else:
            return jsonify({
                'status': 'error',
                'error': result.stderr
            }), 500
    except Exception as e:
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'connectors': len(CONNECTORS)
    })

@app.route('/reconciliation_state.json', methods=['GET'])
def serve_state():
    """Serve reconciliation state for dashboard"""
    if STATE_FILE.exists():
        with open(STATE_FILE, 'r') as f:
            return jsonify(json.load(f))
    else:
        return jsonify({'error': 'State not found'}), 404

# Initialize
if __name__ == '__main__':
    # Load existing connectors
    load_connectors()
    
    # Add default connectors if none exist
    if len(CONNECTORS) == 0:
        defaults = [
            {
                'name': 'Master Conversation Index',
                'type': 'csv',
                'filepath': '/mnt/project/master_conversation_index_MERGED.csv'
            },
            {
                'name': 'DeepSeek Fragments',
                'type': 'csv',
                'filepath': '/mnt/project/deepseek_fragments_meta.csv'
            },
            {
                'name': 'Gmail Drafts (Pending)',
                'type': 'gmail',
                'draft_count': 97,
                'credentials_path': 'credentials.json'
            }
        ]
        
        for config in defaults:
            try:
                connector = create_connector(config)
                CONNECTORS[connector.id] = connector
            except Exception as e:
                print(f"Failed to create default connector: {e}")
        
        save_connectors()
    
    print(f"Loaded {len(CONNECTORS)} connectors")
    print("Starting Dynamic Connector API on http://localhost:8017")
    print("\nAvailable endpoints:")
    print("  GET  /api/connectors          - List connectors")
    print("  POST /api/connectors          - Add connector")
    print("  POST /api/connectors/{id}/sync - Sync connector")
    print("  GET  /api/metrics             - Get metrics")
    print("  POST /api/reconcile           - Run reconciliation")
    print("  GET  /reconciliation_state.json - Get state")
    
    app.run(host='0.0.0.0', port=8017, debug=True)
