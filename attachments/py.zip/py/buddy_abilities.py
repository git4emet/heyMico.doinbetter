#!/usr/bin/env python3
"""
buddy_abilities.py

A tiny, local "abilities memory box" for this workspace.
- Keeps an index of where key docs/archives live
- Updates file metadata on each run
- Tracks which "ability" you used most recently
- Lets you sample zip contents without extracting everything

Usage:
  python buddy_abilities.py list
  python buddy_abilities.py use boot_project_docs
  python buddy_abilities.py scan
  python buddy_abilities.py zip-sample "/mnt/data/Mobiiius_All_in_One.zip" --n 80
  python buddy_abilities.py unzip "/mnt/data/Mobiiius_All_in_One.zip" --out "/mnt/data/_unpacked/Mobiiius_All_in_One"
"""

from __future__ import annotations
import argparse, json, os, sys, time, hashlib, datetime, zipfile, pathlib
from typing import Dict, Any, List

ROOT_DEFAULT = "/mnt/data"
INDEX_DEFAULT = os.path.join(ROOT_DEFAULT, "buddy_abilities_index.json")


def now_iso() -> str:
    return datetime.datetime.now().isoformat()


def file_meta(path: str, hash_bytes_limit: int = 2_000_000) -> Dict[str, Any]:
    """Return basic metadata and a fast partial hash for change detection."""
    if not os.path.exists(path):
        return {"path": path, "exists": False}

    st = os.stat(path)
    meta = {
        "path": path,
        "exists": True,
        "size_bytes": st.st_size,
        "mtime_iso": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(),
    }

    h = hashlib.sha256()
    with open(path, "rb") as f:
        chunk = f.read(hash_bytes_limit)
        h.update(chunk)
    meta["sha256_first2mb"] = h.hexdigest()
    meta["hashed_bytes"] = len(chunk)
    return meta


def load_index(index_path: str) -> Dict[str, Any]:
    if not os.path.exists(index_path):
        raise FileNotFoundError(f"Index not found: {index_path}")
    with open(index_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_index(index_path: str, data: Dict[str, Any]) -> None:
    data["generated_at_iso"] = now_iso()
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def scan(index_path: str) -> None:
    data = load_index(index_path)

    # refresh docs metadata
    refreshed = []
    for d in data.get("docs", []):
        refreshed.append(file_meta(d["path"]))
    data["docs"] = refreshed

    # refresh archives metadata (lightweight)
    for a in data.get("archives", []):
        path = a.get("path")
        if path:
            a["_meta"] = file_meta(path)

    save_index(index_path, data)
    print(f"✅ scanned + updated: {index_path}")


def list_index(index_path: str) -> None:
    data = load_index(index_path)
    print(f"Index: {index_path}")
    print(f"Workspace: {data.get('workspace_root')}")
    print("\nAbilities:")
    for ab in data.get("abilities", []):
        name = ab.get("name")
        goal = ab.get("goal", "")
        print(f" - {name}: {goal}")

    print("\nKey docs:")
    for d in data.get("docs", []):
        p = d["path"]
        exists = "✅" if d.get("exists") else "❌"
        size = d.get("size_bytes", 0)
        print(f" {exists} {p} ({size} bytes)")

    print("\nArchives:")
    for a in data.get("archives", []):
        p = a.get("path")
        tf = a.get("total_files")
        ts = a.get("total_size_bytes")
        print(f" 📦 {p} — {tf} files, {ts} bytes")


def record_use(index_path: str, ability_name: str) -> None:
    data = load_index(index_path)
    usage = data.setdefault("usage", {})
    rec = usage.setdefault(ability_name, {"count": 0, "last_used_iso": None})
    rec["count"] += 1
    rec["last_used_iso"] = now_iso()
    save_index(index_path, data)
    print(f"🧠 recorded use: {ability_name} (count={rec['count']})")


def zip_sample(zip_path: str, n: int = 100) -> None:
    with zipfile.ZipFile(zip_path, "r") as z:
        names = z.namelist()
    for name in names[:n]:
        print(name)
    if len(names) > n:
        print(f"... ({len(names)-n} more)")


def unzip(zip_path: str, out_dir: str) -> None:
    os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(out_dir)
    print(f"✅ extracted to: {out_dir}")


def main(argv: List[str]) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", default=INDEX_DEFAULT, help="Path to buddy_abilities_index.json")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list")
    sub.add_parser("scan")

    p_use = sub.add_parser("use")
    p_use.add_argument("ability_name")

    p_zs = sub.add_parser("zip-sample")
    p_zs.add_argument("zip_path")
    p_zs.add_argument("--n", type=int, default=100)

    p_uz = sub.add_parser("unzip")
    p_uz.add_argument("zip_path")
    p_uz.add_argument("--out", required=True)

    args = ap.parse_args(argv)

    if args.cmd == "list":
        list_index(args.index)
        return 0
    if args.cmd == "scan":
        scan(args.index)
        return 0
    if args.cmd == "use":
        record_use(args.index, args.ability_name)
        return 0
    if args.cmd == "zip-sample":
        zip_sample(args.zip_path, args.n)
        return 0
    if args.cmd == "unzip":
        unzip(args.zip_path, args.out)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
