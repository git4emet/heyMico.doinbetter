import re
import json
from collections import defaultdict

def parse_filelist(lines):
    files = []
    for line in lines:
        if not line.strip() or line.startswith('total'):
            continue
        parts = line.split()
        if len(parts) < 9:
            continue
        size_str = parts[4]
        month = parts[5]
        day = parts[6]
        time_or_year = parts[7]
        path = ' '.join(parts[8:])
        files.append({
            'path': path,
            'size': size_str,
            'modified': f"{month} {day} {time_or_year}"
        })
    return files

with open('filelist.txt', 'r') as f:
    lines = f.readlines()

all_files = parse_filelist(lines)
print(f"Total files parsed: {len(all_files)}")

exclude_dirs = ['.cache', '.local/share/Trash', '.mozilla', '.thunderbird',
                '.config', '.var', '.dropbox', '.linuxmint', '.vscodium-insiders', 'snap']
filtered = []
for f in all_files:
    path = f['path']
    if path.startswith('./'):
        path = path[2:]
    if any(path.startswith(ex) for ex in exclude_dirs):
        continue
    filtered.append(f)

print(f"After filtering: {len(filtered)}")

groups = defaultdict(list)
for f in filtered:
    path = f['path']
    if path.startswith('./'):
        path = path[2:]
    top = path.split('/')[0]
    groups[top].append(f)

print("\n=== PROJECT SUMMARY ===\n")
for top, files in sorted(groups.items()):
    exts = defaultdict(int)
    for f in files:
        ext = f['path'].split('.')[-1] if '.' in f['path'] else 'noext'
        exts[ext] += 1
    top_exts = sorted(exts.items(), key=lambda x: x[1], reverse=True)[:5]
    print(f"{top}: {len(files)} files")
    print(f"  Extensions: {top_exts}")
    print(f"  Sample: {files[0]['path'][:80]}")
    print()

with open('project_files_index.json', 'w') as f:
    json.dump(filtered, f, indent=2)

print("✅ Saved filtered file list to project_files_index.json")