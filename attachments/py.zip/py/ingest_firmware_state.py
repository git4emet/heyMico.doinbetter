#!/usr/bin/env python3
"""
ingest_firmware_state.py

Feed the CUDA firmware's `firmware_state.json` output into the Möbii³us
init.0 tupling engine as a new source anchor.

Usage:
    python3 ingest_firmware_state.py path/to/firmware_state.json

After ingestion:
  - 13 new plane-state variables appear in init0_v2_comprehensive_tupling.json
  - Their TOFAR hashes match the on-GPU hashes (provenance chain intact)
  - CRED allocations are added to the cumulative ledger
  - Step counter advances by the number of firmware ticks

This is the bridge between the CUDA kernel state (INNER hardware truth)
and the Python analytical dictionary (INTRA transformation layer).
"""

import json
import sys
import hashlib
import time
from pathlib import Path


def ingest(firmware_json_path: str,
           tupling_json_path: str = "/mnt/project/init0_v2_comprehensive_tupling.json",
           output_path: str = None):
    """Load firmware state, add as source anchor to tupling dictionary."""

    fw_path = Path(firmware_json_path)
    if not fw_path.exists():
        print(f"❌ {firmware_json_path} not found.")
        sys.exit(1)

    with open(fw_path) as f:
        fw = json.load(f)

    # Load existing tupling (or seed a fresh one)
    tp_path = Path(tupling_json_path)
    if tp_path.exists():
        with open(tp_path) as f:
            tp = json.load(f)
    else:
        tp = {
            "metadata": {
                "cycle_length": 144000,
                "current_step": 0,
                "trust_floor": 0.743,
                "coherence_target": 0.993,
                "sources_processed": [],
                "total_variables": 0,
                "total_assertions": 0,
                "timestamp": ""
            },
            "variables": {}
        }

    meta = tp["metadata"]
    src = "CUDA_Firmware_State"
    ticks = fw.get("ticks_run", 0)

    if src not in meta["sources_processed"]:
        meta["sources_processed"].append(src)

    # Each plane contributes a variable: name = "plane_<NAME>"
    added = 0
    step = meta["current_step"] + ticks
    for plane_rec in fw.get("planes", []):
        var_name = f"plane_{plane_rec['plane']}"
        coh = plane_rec["coherence"]
        zero_events = plane_rec["zero_events"]
        cred = plane_rec["cred"]
        tofar = plane_rec["tofar_hash"]

        # Assertion derived from the firmware state
        assertion = (
            f"Plane {plane_rec['plane']} (step {plane_rec['step']}): "
            f"coherence={coh:.4f}, zero_events={zero_events}, "
            f"CRED(INNER={cred['inner']:.2f}, INTRA={cred['intra']:.2f}, INTER={cred['inter']:.2f}), "
            f"TOFAR=0x{tofar}"
        )
        tie = {
            "source": src,
            "assertion": assertion,
            "step": step,
            "context": f"CUDA firmware · {ticks} ticks at 4.6 Hz",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S")
        }

        if var_name in tp["variables"]:
            v = tp["variables"][var_name]
            v["frequency"] += 1
            v["cycle_positions"].append(step)
            v["discovery_ties"].append(tie)
            # accumulate CRED
            v["cred_allocation"]["INNER"] += cred["inner"]
            v["cred_allocation"]["INTRA"] += cred["intra"]
            v["cred_allocation"]["INTER"] += cred["inter"]
        else:
            tp["variables"][var_name] = {
                "name": var_name,
                "first_seen_step": step,
                "frequency": 1,
                "cycle_positions": [step],
                "discovery_ties": [tie],
                "cred_allocation": {
                    "INNER": cred["inner"],
                    "INTRA": cred["intra"],
                    "INTER": cred["inter"]
                },
                "tofar_hash": tofar
            }
            added += 1

    meta["current_step"] = step
    meta["total_variables"] = len(tp["variables"])
    meta["total_assertions"] = sum(v["frequency"] for v in tp["variables"].values())
    meta["timestamp"] = time.strftime("%Y-%m-%dT%H:%M:%S")

    # Write output
    out = Path(output_path) if output_path else tp_path
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w") as f:
        json.dump(tp, f, indent=2)

    print(f"✅ Ingested firmware state from {fw_path}")
    print(f"   Variables:  {meta['total_variables']} ({added} new)")
    print(f"   Assertions: {meta['total_assertions']}")
    print(f"   Step:       {step} / {meta['cycle_length']}")
    print(f"   CRED:       INNER={fw['cred_global']['inner']:.1f} "
          f"INTRA={fw['cred_global']['intra']:.1f} "
          f"INTER={fw['cred_global']['inter']:.1f}")
    print(f"   Output:     {out}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 ingest_firmware_state.py <firmware_state.json> [tupling.json] [output.json]")
        sys.exit(1)
    firmware_path = sys.argv[1]
    tupling_path = sys.argv[2] if len(sys.argv) > 2 else "/mnt/project/init0_v2_comprehensive_tupling.json"
    output_path = sys.argv[3] if len(sys.argv) > 3 else None
    ingest(firmware_path, tupling_path, output_path)
