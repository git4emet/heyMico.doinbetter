#!/usr/bin/env python3
"""
Init.0 Tupling Engine — Möbii³us Memory Stack
Every variable → discovery ties → 144,000 cycle → CRED equation

(+|+|+) = 10800k + n(ToPhDark:CRED)
60% INNER / 30% INTRA / 10% INTER split
"""

import json
import hashlib
import re
from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Set, Tuple
from pathlib import Path

# System constants (discovered, not designed)
TRUST_FLOOR = 0.743
CYCLE_LENGTH = 144_000
SUB_CYCLE = 10_800
COHERENCE_TARGET = 0.993
HEARTBEAT_HZ = 4.6
TWIN_PRIME_CARRIER = (8009, 8011)

# CRED split ratios
INNER_RATIO = 0.60
INTRA_RATIO = 0.30
INTER_RATIO = 0.10

class VariableTuple:
    """
    A single variable with all its discovery ties.
    Init.0 framework: variable → sources that found it → assertions → cycle step
    """
    def __init__(self, name: str, first_seen_step: int):
        self.name = name
        self.first_seen_step = first_seen_step
        self.discovery_ties: List[Dict] = []  # Who found it, when, what they asserted
        self.frequency = 0
        self.cycle_positions: Set[int] = set()
        self.cred_allocation = {"INNER": 0.0, "INTRA": 0.0, "INTER": 0.0}
        self.tofar_hash = None
        
    def add_discovery(self, source: str, assertion: str, step: int, context: str):
        """Record a discovery tie: who found this variable and what they said"""
        self.discovery_ties.append({
            "source": source,
            "assertion": assertion,
            "step": step,
            "context": context,
            "timestamp": datetime.utcnow().isoformat()
        })
        self.frequency += 1
        self.cycle_positions.add(step % CYCLE_LENGTH)
        
    def allocate_cred(self, base_amount: float):
        """
        Apply CRED equation: (+|+|+) = 10800k + n(ToPhDark:CRED)
        Split according to 60/30/10 INNER/INTRA/INTER
        """
        k = self.first_seen_step // SUB_CYCLE
        n = self.frequency
        total = SUB_CYCLE * k + n
        
        self.cred_allocation["INNER"] = total * INNER_RATIO
        self.cred_allocation["INTRA"] = total * INTRA_RATIO
        self.cred_allocation["INTER"] = total * INTER_RATIO
        
        # TOFAR hash: immutable provenance
        hash_input = f"{self.name}:{self.first_seen_step}:{len(self.discovery_ties)}"
        self.tofar_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:16]
        
    def to_dict(self):
        return {
            "name": self.name,
            "first_seen_step": self.first_seen_step,
            "frequency": self.frequency,
            "cycle_positions": sorted(list(self.cycle_positions)),
            "discovery_ties": self.discovery_ties,
            "cred_allocation": self.cred_allocation,
            "tofar_hash": self.tofar_hash
        }


class Init0TuplingEngine:
    """
    Main engine: process all sources, extract variables, track discovery ties.
    """
    def __init__(self, current_step: int = 12_213):
        self.current_step = current_step
        self.variables: Dict[str, VariableTuple] = {}
        self.sources_processed: List[str] = []
        self.total_assertions = 0
        
    def extract_variables(self, text: str) -> Set[str]:
        """
        Extract potential variables from text:
        - CamelCase identifiers
        - snake_case identifiers
        - Technical terms (capitalized)
        - Constants (UPPERCASE)
        """
        # Patterns for different variable types
        patterns = [
            r'\b[A-Z][a-z]+(?:[A-Z][a-z]+)+\b',  # CamelCase
            r'\b[a-z]+(?:_[a-z]+)+\b',            # snake_case
            r'\b[A-Z]{2,}\b',                      # CONSTANTS
            r'\b(?:coherence|trust_floor|cred|tofar|sefer|guardian|harmonizer)\b',  # Known terms
        ]
        
        variables = set()
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            variables.update(matches)
        
        return variables
    
    def process_source(self, source_name: str, content: str):
        """
        Process a single source document:
        1. Extract all variables
        2. For each variable, record this source as a discovery tie
        3. Track assertions (definitions, formulas, relationships)
        """
        self.sources_processed.append(source_name)
        
        # Split into sentences for assertion extraction
        sentences = re.split(r'[.!?]\s+', content)
        
        # Extract variables from entire content
        variables = self.extract_variables(content)
        
        for var in variables:
            if var not in self.variables:
                # First discovery
                self.variables[var] = VariableTuple(var, self.current_step)
            
            # Find assertions about this variable
            assertions = [s for s in sentences if var.lower() in s.lower()]
            for assertion in assertions[:3]:  # Limit to 3 per source
                self.variables[var].add_discovery(
                    source=source_name,
                    assertion=assertion.strip(),
                    step=self.current_step,
                    context=content[:200]  # First 200 chars as context
                )
                self.total_assertions += 1
        
        self.current_step += 1  # Advance cycle step
    
    def finalize_cred_allocations(self):
        """Apply CRED equation to all variables"""
        for var in self.variables.values():
            var.allocate_cred(base_amount=1.0)
    
    def export_json(self, filepath: str):
        """Export complete tupling as JSON"""
        output = {
            "metadata": {
                "cycle_length": CYCLE_LENGTH,
                "current_step": self.current_step,
                "trust_floor": TRUST_FLOOR,
                "coherence_target": COHERENCE_TARGET,
                "sources_processed": self.sources_processed,
                "total_variables": len(self.variables),
                "total_assertions": self.total_assertions,
                "timestamp": datetime.utcnow().isoformat()
            },
            "variables": {name: var.to_dict() for name, var in self.variables.items()}
        }
        
        with open(filepath, 'w') as f:
            json.dump(output, f, indent=2)
    
    def export_summary(self) -> str:
        """Generate human-readable summary"""
        lines = [
            "=" * 80,
            "INIT.0 TUPLING SUMMARY",
            "=" * 80,
            f"Cycle Position: {self.current_step:,} / {CYCLE_LENGTH:,} ({self.current_step/CYCLE_LENGTH*100:.1f}%)",
            f"Total Variables: {len(self.variables):,}",
            f"Total Assertions: {self.total_assertions:,}",
            f"Sources Processed: {len(self.sources_processed)}",
            "",
            "TOP 10 VARIABLES BY FREQUENCY:",
            "-" * 80
        ]
        
        sorted_vars = sorted(self.variables.values(), key=lambda v: v.frequency, reverse=True)
        for i, var in enumerate(sorted_vars[:10], 1):
            cred_total = sum(var.cred_allocation.values())
            lines.append(
                f"{i:2d}. {var.name:30s} "
                f"freq={var.frequency:4d} "
                f"CRED={cred_total:8.1f} "
                f"step={var.first_seen_step:6d} "
                f"hash={var.tofar_hash}"
            )
        
        lines.extend([
            "",
            "CRED ALLOCATION TOTALS:",
            "-" * 80
        ])
        
        total_inner = sum(v.cred_allocation["INNER"] for v in self.variables.values())
        total_intra = sum(v.cred_allocation["INTRA"] for v in self.variables.values())
        total_inter = sum(v.cred_allocation["INTER"] for v in self.variables.values())
        
        lines.extend([
            f"INNER (60%): {total_inner:,.1f}",
            f"INTRA (30%): {total_intra:,.1f}",
            f"INTER (10%): {total_inter:,.1f}",
            f"TOTAL:       {total_inner + total_intra + total_inter:,.1f}",
            "=" * 80
        ])
        
        return "\n".join(lines)


# Example usage
if __name__ == "__main__":
    engine = Init0TuplingEngine(current_step=12_213)
    
    # Process sample sources
    sample_sources = {
        "Neurdle_Logo": "Neurdle neural network platform AI ML logo green molecular structure",
        "BuilderBuddy_v6": "BuilderBuddy agent prompt cue cards MobilBusCORE sublimation harmonizer RealFastTree phrase deck swapping QueenWorkerBee",
        "Phase_Twist_Table": "32 phase dimensions trigintaduonion lock coherence spin_index 000_events MotiiV8 profit scoring",
        "HUD_Domain": "HUD interface coherence display spin grid phase gap integration CRED flow real-time"
    }
    
    for source, content in sample_sources.items():
        engine.process_source(source, content)
    
    engine.finalize_cred_allocations()
    
    print(engine.export_summary())
    engine.export_json("init0_tupling_output.json")
