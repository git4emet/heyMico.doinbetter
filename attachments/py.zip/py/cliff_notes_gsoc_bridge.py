"""
CliffNotes Autoreveal + GSOC-TOFAR Provenance Bridge
Connects uncertainty archival to infrastructure safety workflows.
"""

import json
import hashlib
from typing import List, Optional, Dict, Tuple
from datetime import datetime
from enum import Enum
from dataclasses import dataclass, asdict
import numpy as np


# ============== CLIFF NOTES AUTOREVEAL ==============

@dataclass
class CliffNote:
    """A single highlighted insight from a resolved uncertainty trail"""
    index: int
    essence: str
    frequency: float  # MHz (50.0-54.0)
    certainty_boost: float  # How much it raised confidence
    reveal_trigger: str  # Pattern that activates this note
    path_attribute: str  # Which trail led here
    trail_id: str  # Parent trail


@dataclass
class SimilarityMatch:
    """Result of comparing new uncertainty to archive"""
    trail_id: str
    similarity_score: float  # 0.0-1.0
    cliff_notes: List[CliffNote]
    recommended_action: str
    certainty_gain: float


class CliffNotesAutoReveal:
    """Watch for incoming uncertainties and surface relevant Cliff Notes"""
    
    def __init__(self, signpost_archive: List[Dict], similarity_threshold: float = 0.6):
        self.archive = signpost_archive  # List of dicts with 'message', 'cliff_notes', etc.
        self.threshold = similarity_threshold
        self.reveal_history = []  # Log of reveals
        
    def check_and_reveal(self, new_uncertainty: str) -> Optional[List[Dict]]:
        """
        Scan archive for similar trails. If found, auto-surface Cliff Notes.
        
        Returns:
            List of Cliff Notes + recommended actions, or None if no match.
        """
        matches = self._find_similar_trails(new_uncertainty)
        
        if not matches:
            return None
        
        # Sort by similarity
        matches.sort(key=lambda m: m['similarity_score'], reverse=True)
        top_match = matches[0]
        
        # Log the reveal
        reveal_record = {
            'timestamp': datetime.now().isoformat(),
            'new_uncertainty': new_uncertainty[:100],
            'matched_trail': top_match['trail_id'],
            'similarity': top_match['similarity_score'],
            'cliff_notes_revealed': len(top_match['cliff_notes'])
        }
        self.reveal_history.append(reveal_record)
        
        return {
            'matched_trail_id': top_match['trail_id'],
            'similarity': top_match['similarity_score'],
            'cliff_notes': top_match['cliff_notes'],
            'recommended_action': top_match['recommended_action'],
            'certainty_gain': top_match['certainty_gain']
        }
    
    def _find_similar_trails(self, uncertainty_text: str) -> List[Dict]:
        """Find archive trails matching this uncertainty"""
        matches = []
        text_lower = uncertainty_text.lower()
        text_words = set(text_lower.split())
        
        for signpost in self.archive:
            message = str(signpost.get('message', '')).lower()
            message_words = set(message.split())
            
            # Jaccard similarity
            if len(text_words | message_words) == 0:
                similarity = 0.0
            else:
                similarity = len(text_words & message_words) / len(text_words | message_words)
            
            if similarity >= self.threshold:
                matches.append({
                    'trail_id': signpost.get('trail_id', 'unknown'),
                    'similarity_score': similarity,
                    'cliff_notes': signpost.get('cliff_notes', []),
                    'recommended_action': f"Follow trail {signpost.get('trail_id', '?')} via {signpost.get('location', '?')}MHz",
                    'certainty_gain': signpost.get('certainty_anchor', 0.743) - 0.743
                })
        
        return matches
    
    def get_reveal_stats(self) -> Dict:
        """Return statistics on Cliff Notes reveals"""
        total_reveals = len(self.reveal_history)
        unique_trails = len(set(r['matched_trail'] for r in self.reveal_history))
        avg_similarity = np.mean([r['similarity'] for r in self.reveal_history]) if self.reveal_history else 0.0
        
        return {
            'total_reveals': total_reveals,
            'unique_trails_accessed': unique_trails,
            'average_similarity': avg_similarity,
            'reveal_history': self.reveal_history[-10:]  # Last 10
        }


# ============== GSOC-TOFAR PROVENANCE BRIDGE ==============

class GSocTicketType(Enum):
    """Types of GSOC utility locate tickets"""
    NORMAL = "Normal"
    EMERGENCY = "Emergency"
    MARKED_DAMAGE = "Marked Damage"


@dataclass
class GSocTicket:
    """Gopher State One Call (GSOC) utility locate ticket"""
    ticket_no: str
    ticket_type: GSocTicketType
    excavator_company: str
    dig_site_lat_lon: Tuple[float, float]
    requested_date: str
    utility_types: List[str]  # ['electric', 'gas', 'water', 'telecom']
    dig_depth_ft: Optional[float] = None
    notes: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            'ticket_no': self.ticket_no,
            'type': self.ticket_type.value,
            'excavator_company': self.excavator_company,
            'dig_site': self.dig_site_lat_lon,
            'date': self.requested_date,
            'utilities': self.utility_types,
            'depth': self.dig_depth_ft,
            'notes': self.notes
        }


class GSocTOFARBridge:
    """
    Links GSOC utility tickets to TOFAR provenance.
    Every dig becomes a traced decision with origin vectors.
    """
    
    def __init__(self, tofar_logger=None):
        self.tofar = tofar_logger  # Connection to existing TOFAR system
        self.integrated_tickets = []
        self.safety_chain = []  # Linked list of ticket→outcome
        
    def ingest_gsoc_ticket(self, ticket: GSocTicket) -> Dict:
        """
        Ingest a GSOC ticket and trace it through TOFAR.
        Assigns origin vector, certainty anchors, and safety checks.
        """
        
        # Step 1: Create origin vector for this ticket
        origin_vector = self._create_origin_vector(ticket)
        
        # Step 2: Run safety checks (against 7 ethical gates)
        safety_verdict = self._run_safety_checks(ticket)
        
        # Step 3: Create TOFAR provenance entry
        tofar_entry = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'gsoc_ticket_ingest',
            'ticket_no': ticket.ticket_no,
            'origin_vector': origin_vector,
            'safety_verdict': safety_verdict,
            'certainty_anchor': safety_verdict['certainty'] if safety_verdict['approved'] else 0.5,
            'path_attributes': self._extract_path_attributes(ticket)
        }
        
        # Step 4: Log to TOFAR
        if self.tofar:
            self.tofar.log_entry(tofar_entry)
        else:
            # Fallback: append to local log
            with open('gsoc_tofar_bridge.jsonl', 'a') as f:
                f.write(json.dumps(tofar_entry) + '\n')
        
        self.integrated_tickets.append(tofar_entry)
        
        # Step 5: Return integrated ticket with approval status
        return {
            'ticket_no': ticket.ticket_no,
            'status': 'approved' if safety_verdict['approved'] else 'flagged_for_review',
            'certainty': tofar_entry['certainty_anchor'],
            'safety_notes': safety_verdict['notes'],
            'tofar_id': tofar_entry['timestamp']
        }
    
    def _create_origin_vector(self, ticket: GSocTicket) -> Dict:
        """
        Create an origin vector for the ticket.
        Captures: excavator credibility, dig type, location risk, etc.
        """
        # Simple version: hash-based
        ticket_hash = hashlib.md5(ticket.ticket_no.encode()).hexdigest()[:8]
        
        return {
            'ticket_hash': ticket_hash,
            'excavator_credibility': 0.8,  # Placeholder (would connect to real DB)
            'dig_type_risk': self._assess_dig_risk(ticket),
            'location_sensitivity': self._assess_location_risk(ticket),
            'utility_hazard_level': self._assess_utility_hazard(ticket),
            'timestamp': datetime.now().isoformat()
        }
    
    def _run_safety_checks(self, ticket: GSocTicket) -> Dict:
        """Run 7 Ethical Gates on the GSOC ticket"""
        gates = {
            'knowledge': self._check_gate_knowledge(ticket),
            'prophecy': self._check_gate_prophecy(ticket),
            'service': self._check_gate_service(ticket),
            'prayer': self._check_gate_prayer(ticket),
            'traits': self._check_gate_traits(ticket),
            'tests': self._check_gate_tests(ticket),
            'repentance': self._check_gate_repentance(ticket)
        }
        
        # All gates must pass
        all_pass = all(gates.values())
        certainty = 0.9 if all_pass else 0.5
        
        return {
            'approved': all_pass,
            'certainty': certainty,
            'gate_results': gates,
            'notes': f"Ticket {ticket.ticket_no}: {'Safe to proceed' if all_pass else 'Requires review'}"
        }
    
    def _check_gate_knowledge(self, ticket: GSocTicket) -> bool:
        """Gate: Do we know the excavator and utilities involved?"""
        return bool(ticket.excavator_company and ticket.utility_types)
    
    def _check_gate_prophecy(self, ticket: GSocTicket) -> bool:
        """Gate: Can we predict potential harms?"""
        # Check if utilities are clearly marked and accessible
        return len(ticket.utility_types) > 0
    
    def _check_gate_service(self, ticket: GSocTicket) -> bool:
        """Gate: Is this serving the community (not private/exploitative)?"""
        # Simplification: all GSOC tickets serve infrastructure = yes
        return True
    
    def _check_gate_prayer(self, ticket: GSocTicket) -> bool:
        """Gate: Is the intent honest and transparent?"""
        # Check for reasonable lead time (not emergency bypass)
        return ticket.ticket_type != GSocTicketType.EMERGENCY or ticket.notes
    
    def _check_gate_traits(self, ticket: GSocTicket) -> bool:
        """Gate: Are all parties acting with integrity?"""
        # Placeholder: would connect to compliance DB
        return True
    
    def _check_gate_tests(self, ticket: GSocTicket) -> bool:
        """Gate: Have necessary precautions been taken?"""
        # Presence of depth info suggests planning
        return ticket.dig_depth_ft is not None or len(ticket.notes or '') > 10
    
    def _check_gate_repentance(self, ticket: GSocTicket) -> bool:
        """Gate: Is there accountability for past errors?"""
        # Check if excavator has history in system (placeholder)
        return True
    
    def _assess_dig_risk(self, ticket: GSocTicket) -> float:
        """0.0 (safe) to 1.0 (high risk)"""
        risk = 0.2  # Default
        if ticket.dig_depth_ft and ticket.dig_depth_ft > 36:
            risk += 0.3  # Deep digs are riskier
        if ticket.ticket_type == GSocTicketType.EMERGENCY:
            risk += 0.2
        return min(1.0, risk)
    
    def _assess_location_risk(self, ticket: GSocTicket) -> float:
        """Risk based on dig location (0.0-1.0)"""
        lat, lon = ticket.dig_site_lat_lon
        # Placeholder: urban areas are riskier
        if 44.9 < lat < 45.0 and -93.3 < lon < -93.2:  # Downtown Minneapolis
            return 0.7
        return 0.3
    
    def _assess_utility_hazard(self, ticket: GSocTicket) -> float:
        """Hazard level based on utility types (0.0-1.0)"""
        hazard = 0.1
        if 'electric' in ticket.utility_types:
            hazard = max(hazard, 0.8)
        elif 'gas' in ticket.utility_types:
            hazard = max(hazard, 0.9)
        return hazard
    
    def _extract_path_attributes(self, ticket: GSocTicket) -> Dict:
        """Extract attributes for future reference"""
        return {
            'ticket_no': ticket.ticket_no,
            'excavator': ticket.excavator_company,
            'location': ticket.dig_site_lat_lon,
            'date': ticket.requested_date,
            'utilities_involved': ticket.utility_types,
            'trail_reference': f"gsoc_{ticket.ticket_no}_{hashlib.md5(ticket.ticket_no.encode()).hexdigest()[:4]}"
        }
    
    def link_ticket_to_outcome(self, ticket_no: str, outcome: str):
        """
        After a dig completes, link ticket to outcome (success/damage/claim).
        Builds the safety chain for future tickets.
        """
        link = {
            'ticket_no': ticket_no,
            'outcome': outcome,
            'timestamp': datetime.now().isoformat(),
            'linked_to_chain': True
        }
        self.safety_chain.append(link)
    
    def get_safety_chain_stats(self) -> Dict:
        """Return safety statistics from the chain"""
        total = len(self.safety_chain)
        successes = len([x for x in self.safety_chain if x['outcome'] == 'success'])
        
        return {
            'total_digs_tracked': total,
            'successful': successes,
            'success_rate': (successes / total * 100) if total > 0 else 0.0,
            'recent_chain': self.safety_chain[-5:]
        }


# ============== INTEGRATION WITH FASTAPI ==============

def integrate_with_fastapi(app, cliff_notes_autoreveal: CliffNotesAutoReveal, 
                          gsoc_bridge: GSocTOFARBridge):
    """
    Attach these systems to the FastAPI app.
    Call this in your main.py after creating the app.
    """
    
    @app.post("/uncertainty/check_and_reveal")
    async def uncertainty_check(body: dict):
        """
        User submits an uncertainty. System checks archive and auto-reveals Cliff Notes.
        """
        uncertainty_text = body.get("uncertainty", "")
        
        result = cliff_notes_autoreveal.check_and_reveal(uncertainty_text)
        
        if result:
            return {
                'status': 'matched',
                'matched_trail': result['matched_trail_id'],
                'similarity': result['similarity'],
                'cliff_notes': result['cliff_notes'],
                'advice': result['recommended_action']
            }
        else:
            return {
                'status': 'no_match',
                'advice': 'This uncertainty will be fractionated and broadcast for all future Buddys.'
            }
    
    @app.post("/anymesh/integrate/gsoc")
    async def integrate_gsoc_ticket(body: dict):
        """
        GSOC utility ticket ingest. Runs safety checks and links to TOFAR.
        """
        raw_ticket = body.get("raw_ticket", {})
        
        # Parse to GSocTicket
        ticket = GSocTicket(
            ticket_no=raw_ticket.get("ticket_no"),
            ticket_type=GSocTicketType(raw_ticket.get("type", "Normal")),
            excavator_company=raw_ticket.get("excavator_info", {}).get("company_name", "Unknown"),
            dig_site_lat_lon=tuple(raw_ticket.get("dig_site_info", {}).get("lat_lon", [0, 0])),
            requested_date=raw_ticket.get("requested_date", datetime.now().isoformat()),
            utility_types=raw_ticket.get("utilities", []),
            dig_depth_ft=raw_ticket.get("dig_depth_ft"),
            notes=raw_ticket.get("notes")
        )
        
        # Ingest through bridge
        result = gsoc_bridge.ingest_gsoc_ticket(ticket)
        
        return {
            'integration_status': result['status'],
            'ticket_no': result['ticket_no'],
            'certainty': result['certainty'],
            'safety_verdict': result['safety_notes'],
            'tofar_logged': True
        }
    
    @app.get("/stats/cliff_notes")
    async def cliff_notes_stats():
        """Stats on Cliff Notes reveals"""
        return cliff_notes_autoreveal.get_reveal_stats()
    
    @app.get("/stats/safety_chain")
    async def safety_chain_stats():
        """Stats on GSOC safety chain"""
        return gsoc_bridge.get_safety_chain_stats()


# ============== EXAMPLE USAGE ==============

if __name__ == "__main__":
    # Create a sample archive (from Sierpinski signpost broadcasts)
    sample_archive = [
        {
            'trail_id': 'trail_abc123',
            'message': 'How do I know if this path is right?',
            'location': 52.0,  # MHz
            'certainty_anchor': 0.85,
            'cliff_notes': [
                {
                    'index': 0,
                    'essence': 'Trust the resonance, not the certainty.',
                    'frequency': 52.0,
                    'reveal_trigger': 'doubt_about_direction'
                }
            ]
        },
        {
            'trail_id': 'trail_def456',
            'message': 'Is this memory real or reconstructed?',
            'location': 51.5,
            'certainty_anchor': 0.80,
            'cliff_notes': [
                {
                    'index': 0,
                    'essence': 'Memory is a conversation between past and present.',
                    'frequency': 51.5,
                    'reveal_trigger': 'memory_authenticity_doubt'
                }
            ]
        }
    ]
    
    # Initialize systems
    autoreveal = CliffNotesAutoReveal(sample_archive, similarity_threshold=0.5)
    gsoc_bridge = GSocTOFARBridge()
    
    # Test 1: Cliff Notes autoreveal
    print("=== TEST 1: Cliff Notes Autoreveal ===")
    new_uncertainty = "How do I trust what I remember about this decision?"
    result = autoreveal.check_and_reveal(new_uncertainty)
    print(json.dumps(result, indent=2))
    
    # Test 2: GSOC ticket ingest
    print("\n=== TEST 2: GSOC Ticket Integration ===")
    test_ticket = GSocTicket(
        ticket_no="20260115-001",
        ticket_type=GSocTicketType.NORMAL,
        excavator_company="FizzyBox Digs LLC",
        dig_site_lat_lon=(44.9721, -93.2662),
        requested_date="2026-01-20",
        utility_types=["electric", "water"],
        dig_depth_ft=24,
        notes="Standard residential fence post installation"
    )
    
    result = gsoc_bridge.ingest_gsoc_ticket(test_ticket)
    print(json.dumps(result, indent=2))
    
    print("\n=== Stats ===")
    print("Cliff Notes reveals:", autoreveal.get_reveal_stats())
    print("Safety chain:", gsoc_bridge.get_safety_chain_stats())