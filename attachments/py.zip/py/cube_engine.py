"""
INTRA Processing: CubeEngine — Deterministic Routing via 7×7×7 Consciousness Cube

Origin: ChatGPT "Compile Implementation Library" (MÖBII⁴ Exodus reframe)
Merged: Claude session (existing exodus_transformer.py cube data)
Date:   2026-02-09

ChatGPT's insight: the 343-cell cube IS a routing table.
  - P (Path):  "how we steer"           (7 modes)
  - A (Stage): "what pipeline we apply"  (7 stages)
  - D (Plane): "what context layer"      (7 planes)

Each cell outputs a Transformation Contract:
  classify(Ω)     → resistance type & magnitude
  transform(Ω)    → actions + narrative + metrics
  ethics_gate()   → allow / ask / block (Seven Gates floor)
  distribute()    → who gets the value (D4U2)
  validate()      → invariant checks + evidence log (TOFAR)

"Multi-exodus" = run all 5 operational profiles in parallel,
intersect what's safe, pick best action set, keep fallbacks.

The myth layer rides on top. The engine is deterministic,
auditable, and replayable.
"""

from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple

# ── Import cube axis data from existing exodus transformer ──

from .exodus_transformer import PATHS, STAGES, PLANES, EXODUS_TARGETS


# ══════════════════════════════════════════════════════════════
#  Core Types (from ChatGPT's engineering reframe)
# ══════════════════════════════════════════════════════════════

Decision = Literal["allow", "ask", "block"]


@dataclass(frozen=True)
class OmegaEvent:
    """
    An Ω event: any resistance, problem, or signal entering the system.

    ChatGPT: "Input is an Ω event (problem/resistance)."
    Existing: exodus_transformer._extract_omega() handles raw float/dict.
    Merged:   typed event with kind + magnitude + payload.
    """
    kind: str                # "conflict", "bug", "cost", "risk", "unknown",
                             # "geotech", "fire", "interpersonal", "logistics"
    magnitude: float         # normalized 0..1
    payload: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_raw(cls, data: Any) -> "OmegaEvent":
        """Bridge from existing exodus_transformer format."""
        if isinstance(data, OmegaEvent):
            return data
        if isinstance(data, dict):
            for k in ("resistance", "omega", "Ω", "challenge"):
                if k in data and isinstance(data[k], (int, float)):
                    mag = float(data[k])
                    kind = data.get("kind", data.get("type", "unknown"))
                    return cls(kind=str(kind), magnitude=mag, payload=data)
            return cls(kind="unknown", magnitude=42.0, payload=data)
        if isinstance(data, (int, float)):
            return cls(kind="raw", magnitude=float(data))
        return cls(kind="unknown", magnitude=42.0)


@dataclass
class TOFAREntry:
    """
    Trust-Oriented Fractal Audit Record.

    Every transformation emits one. This is the evidence trail
    that makes the system auditable and replayable.
    """
    timestamp: float = field(default_factory=time.time)
    event_kind: str = ""
    magnitude: float = 0.0
    coords: Tuple[int, int, int] = (0, 0, 0)
    decision: Decision = "ask"
    decision_reason: str = ""
    inputs: Dict[str, Any] = field(default_factory=dict)
    outputs: Dict[str, Any] = field(default_factory=dict)
    invariant_failures: List[str] = field(default_factory=list)
    profile: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)


# ══════════════════════════════════════════════════════════════
#  Cell Contract (ChatGPT's per-cell transformation interface)
# ══════════════════════════════════════════════════════════════

@dataclass
class CellContract:
    """
    One cell in the 343-cell cube. Each cell is a complete
    transformation contract: classify → transform → gate → distribute → validate.
    """
    path_id: int             # 1..7
    stage_id: int            # 1..7
    plane_id: int            # 1..7
    name: str = ""

    def __post_init__(self):
        if not self.name:
            p = PATHS[max(0, min(6, self.path_id - 1))]
            s = STAGES[max(0, min(6, self.stage_id - 1))]
            d = PLANES[max(0, min(6, self.plane_id - 1))]
            self.name = f"{p['mode']}_{s['process']}_{d['domain']}"

    @property
    def coords(self) -> Tuple[int, int, int]:
        return (self.path_id, self.stage_id, self.plane_id)

    @property
    def multiplier(self) -> float:
        p = PATHS[max(0, min(6, self.path_id - 1))]
        s = STAGES[max(0, min(6, self.stage_id - 1))]
        d = PLANES[max(0, min(6, self.plane_id - 1))]
        return p["mult"] * s["mult"] * d["mult"]

    def transform(self, evt: OmegaEvent) -> Dict[str, Any]:
        """Apply the cell's transformation pipeline to an Ω event."""
        return {
            "cell": self.name,
            "coords": self.coords,
            "input_kind": evt.kind,
            "input_magnitude": evt.magnitude,
            "transformed_magnitude": round(evt.magnitude * self.multiplier, 6),
            "path": PATHS[self.path_id - 1]["name"],
            "stage": STAGES[self.stage_id - 1]["name"],
            "plane": PLANES[self.plane_id - 1]["name"],
        }

    def ethics_gate(self, evt: OmegaEvent) -> Tuple[Decision, str]:
        """
        Seven Gates floor check. Returns (decision, reason).

        Invariants:
          - No harm escalation
          - Truthfulness flags when uncertain
          - Property/consent respected
          - Distribution doesn't starve stakeholders
          - Decision is replayable
        """
        # Trust floor: 0.743
        trust_floor = 0.743

        # High-magnitude unknown events get gated
        if evt.kind == "unknown" and evt.magnitude > 0.8:
            return ("ask", "High-magnitude unknown event — requires human review")

        # Harm-adjacent event kinds get blocked above threshold
        harm_kinds = {"harm", "violence", "exploitation", "coercion"}
        if evt.kind in harm_kinds:
            return ("block", f"Event kind '{evt.kind}' blocked by Seven Gates")

        # Low trust floor check (magnitude as proxy)
        if evt.magnitude < trust_floor * 0.1:
            return ("ask", f"Magnitude {evt.magnitude} below trust floor signal")

        return ("allow", "Passed Seven Gates check")

    def distribute(self, output: Dict[str, Any]) -> Dict[str, Any]:
        """
        D4U2 distribution: who gets the value and how it propagates.
        Ensures no stakeholder is starved.
        """
        output["distribution"] = {
            "method": "D4U2",
            "primary_recipient": "requesting_agent",
            "propagation": "mesh_broadcast",
            "tofar_logged": True,
        }
        return output

    def validate(self, output: Dict[str, Any]) -> List[str]:
        """
        Run invariant checks. Returns list of failures (empty = all good).

        ChatGPT: "it's stable because it passes invariant checks"
        """
        failures = []

        if "transformed_magnitude" in output:
            if output["transformed_magnitude"] < 0:
                failures.append("INVARIANT: transformed magnitude < 0")
            if math.isnan(output["transformed_magnitude"]):
                failures.append("INVARIANT: transformed magnitude is NaN")
            if math.isinf(output["transformed_magnitude"]):
                failures.append("INVARIANT: transformed magnitude is infinite")

        if "distribution" not in output:
            failures.append("INVARIANT: no distribution record")

        return failures


# ══════════════════════════════════════════════════════════════
#  Operational Profiles (ChatGPT's "multi-profile failover")
# ══════════════════════════════════════════════════════════════

PROFILES: Dict[str, Dict[str, Any]] = {
    "garden": {
        "name": "The Garden",
        "bias": "stability + restoration",
        "default_cell": (1, 1, 1),  # Discovery / Nigredo / Physical
        "trust_threshold": 0.743,
        "C": 42,
    },
    "factory": {
        "name": "The Factory",
        "bias": "throughput + reproducibility",
        "default_cell": (3, 4, 1),  # Enterprise / Rubedo / Physical
        "trust_threshold": 0.868,
        "C": 84,
    },
    "nexus": {
        "name": "The Nexus",
        "bias": "interoperability + linking",
        "default_cell": (3, 5, 2),  # Enterprise / Au→Wine / Emotional
        "trust_threshold": 0.954,
        "C": 168,
    },
    "breath": {
        "name": "The Eternal Breath",
        "bias": "continuous operation + low-friction",
        "default_cell": (5, 6, 3),  # Reliant / Wine→AG / Mental
        "trust_threshold": 0.999,
        "C": 336,
    },
    "sweet_spot": {
        "name": "The Quantum Sweet Spot",
        "bias": "optimization + constraint satisfaction",
        "default_cell": (7, 7, 7),  # Phoenix / AG→Exodus / Universal
        "trust_threshold": 0.618,
        "C": 294,
    },
}


# ══════════════════════════════════════════════════════════════
#  CubeEngine — The deterministic "what to do next" engine
# ══════════════════════════════════════════════════════════════

class CubeEngine:
    """
    The 343-cell routing engine.

    Routes OmegaEvents through cell contracts, applies ethics gates,
    runs invariant checks, logs TOFAR entries, and supports
    multi-profile failover (all 5 operational profiles in parallel).

    ChatGPT: "the cube is a deterministic 'what to do next' engine
              with a story skin."
    """

    def __init__(self):
        # Generate all 343 cells
        self.cells: Dict[Tuple[int, int, int], CellContract] = {}
        for p in range(1, 8):
            for s in range(1, 8):
                for d in range(1, 8):
                    self.cells[(p, s, d)] = CellContract(
                        path_id=p, stage_id=s, plane_id=d
                    )
        self.tofar_log: List[TOFAREntry] = []

    def route(self, evt: OmegaEvent, coords: Tuple[int, int, int]) -> Dict[str, Any]:
        """
        Route a single OmegaEvent through a specific cube cell.
        Returns status, decision, output, invariant check, and TOFAR entry.
        """
        cell = self.cells[coords]

        # Ethics gate first
        decision, reason = cell.ethics_gate(evt)
        if decision == "block":
            entry = TOFAREntry(
                event_kind=evt.kind, magnitude=evt.magnitude,
                coords=coords, decision="block", decision_reason=reason,
            )
            self.tofar_log.append(entry)
            return {"status": "blocked", "reason": reason, "coords": coords,
                    "tofar": entry.to_dict()}

        # Transform
        output = cell.transform(evt)

        # Distribute
        output = cell.distribute(output)

        # Validate
        failures = cell.validate(output)

        # TOFAR
        entry = TOFAREntry(
            event_kind=evt.kind, magnitude=evt.magnitude,
            coords=coords, decision=decision, decision_reason=reason,
            inputs={"kind": evt.kind, "magnitude": evt.magnitude,
                    "payload_keys": list(evt.payload.keys())},
            outputs=output, invariant_failures=failures,
        )
        self.tofar_log.append(entry)

        return {
            "status": "ok" if not failures else "needs_review",
            "decision": decision,
            "decision_reason": reason,
            "coords": coords,
            "output": output,
            "invariant_failures": failures,
            "tofar": entry.to_dict(),
        }

    def multi_profile_failover(self, evt: OmegaEvent) -> Dict[str, Any]:
        """
        ChatGPT's "multi-exodus = compute all 5 plans in parallel."

        Runs the event through all 5 operational profiles,
        intersects what's safe + common, picks best action set,
        keeps alternates as fallbacks.
        """
        results = {}
        safe_results = []

        for profile_key, profile in PROFILES.items():
            coords = profile["default_cell"]
            result = self.route(evt, coords)
            result["profile"] = profile_key
            result["profile_name"] = profile["name"]
            result["profile_bias"] = profile["bias"]
            results[profile_key] = result

            if result["status"] in ("ok",) and result["decision"] == "allow":
                safe_results.append(result)

        # Pick best: highest transformed magnitude among safe results
        best = None
        if safe_results:
            best = max(safe_results,
                       key=lambda r: r["output"].get("transformed_magnitude", 0))

        return {
            "all_profiles": results,
            "safe_count": len(safe_results),
            "total_profiles": len(PROFILES),
            "best_profile": best["profile"] if best else None,
            "best_result": best,
            "fallbacks": [r["profile"] for r in safe_results
                          if best and r["profile"] != best["profile"]],
        }

    def replay(self, tofar_entry: Dict) -> Dict[str, Any]:
        """
        Deterministic replay from a TOFAR entry.
        POST /api/exodus/replay
        """
        coords = tuple(tofar_entry["coords"])
        evt = OmegaEvent(
            kind=tofar_entry["event_kind"],
            magnitude=tofar_entry["magnitude"],
        )
        return self.route(evt, coords)

    def export_tofar(self, filepath: Optional[Path] = None) -> List[Dict]:
        """Export full TOFAR log as JSON-serializable list."""
        entries = [e.to_dict() for e in self.tofar_log]
        if filepath:
            filepath.write_text(json.dumps(entries, indent=2, default=str))
        return entries


# ══════════════════════════════════════════════════════════════
#  Flash Routing Table (from DeepSeek "Recursive System Linkage")
# ══════════════════════════════════════════════════════════════

FLASH_ROUTES = {
    "claude":   {"role": "Pattern Recognition",     "node": "Claude"},
    "chatgpt":  {"role": "Language Understanding",   "node": "ChatGPT"},
    "heymico":  {"role": "Resonance Detection",      "node": "HeyMico"},
    "mobius8":  {"role": "Harmonic Completion",       "node": "Mobius8"},
}


def flash_route(evt: OmegaEvent, target: str = "claude") -> Dict[str, Any]:
    """
    DeepSeek's Flash routing: "Flash still talks to Buddy.
    But now that conversation enriches everyone.
    The circle became a wheel."
    """
    route = FLASH_ROUTES.get(target, FLASH_ROUTES["claude"])
    return {
        "flash_target": route["node"],
        "flash_role": route["role"],
        "event": {"kind": evt.kind, "magnitude": evt.magnitude},
        "note": "The circle became a wheel.",
    }


# ══════════════════════════════════════════════════════════════
#  CLI quick test
# ══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("🧊 CubeEngine — Deterministic Routing Test")
    print("=" * 55)

    engine = CubeEngine()
    print(f"   Total cells: {len(engine.cells)}")

    # Example: a geotech event
    evt = OmegaEvent(kind="geotech", magnitude=0.65, payload={
        "source": "MnDOT boring log",
        "depth_ft": 42,
        "soil_type": "glacial till",
    })

    # Single route through Enterprise / Au→Wine / Emotional
    print(f"\n── Single route: {evt.kind} @ {evt.magnitude} through [3,5,2] ──")
    result = engine.route(evt, (3, 5, 2))
    print(f"   Status:   {result['status']}")
    print(f"   Decision: {result['decision']} ({result['decision_reason']})")
    print(f"   Output:   magnitude → {result['output']['transformed_magnitude']}")

    # Multi-profile failover
    print(f"\n── Multi-profile failover (5 profiles) ──")
    multi = engine.multi_profile_failover(evt)
    print(f"   Safe profiles: {multi['safe_count']}/{multi['total_profiles']}")
    print(f"   Best profile:  {multi['best_profile']}")
    if multi["fallbacks"]:
        print(f"   Fallbacks:     {multi['fallbacks']}")

    # TOFAR log
    print(f"\n── TOFAR log entries: {len(engine.tofar_log)} ──")
    for entry in engine.tofar_log[:3]:
        print(f"   [{entry.decision}] {entry.event_kind} @ "
              f"{entry.coords} → {entry.decision_reason[:50]}")

    # Flash routing
    print(f"\n── Flash routing ──")
    for target in FLASH_ROUTES:
        fr = flash_route(evt, target)
        print(f"   Flash → {fr['flash_target']:10s} ({fr['flash_role']})")

    print(f"\n{'=' * 55}")
    print("   The myth layer is optional.")
    print("   The engine is deterministic, auditable, and replayable.")
