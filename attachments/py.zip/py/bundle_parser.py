#!/usr/bin/env python3
"""
bundle_parser.py — Möbii³us "bundle-cohere" ingestion

Goal
----
Turn a loose "document potential" folder (jsonl, json, pdfs, images, etc.)
into a *coherent, replayable archive object* with:

- parsed memory events from buddy_memory.jsonl (or any *.jsonl)
- decoded base64 assets from encodings.json (or any json containing base64 blobs)
- safe handling of blocked/forbidden URL fetch instructions (record, do not fetch)
- a small, honest "coherence score" based on parse success + artifact linkage

This file is designed to be used two ways:
1) as an importable library (parse_bundle(...))
2) as a CLI for quick local runs (python bundle_parser.py --root ...)

No network calls. No "terminal URL fetch" behavior.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import dataclasses
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

JsonDict = Dict[str, Any]


# ----------------------------
# Utilities
# ----------------------------

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
DEFAULT_MAX_B64_BYTES = 50 * 1024 * 1024  # 50 MiB decoded cap


def now_ms() -> int:
    return int(time.time() * 1000)


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def stable_dumps(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def safe_mkdir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def is_probably_base64(s: str) -> bool:
    # Cheap heuristic: long-ish, mostly base64 alphabet chars, no spaces/newlines.
    if not isinstance(s, str):
        return False
    if len(s) < 256:
        return False
    if any(ch in s for ch in (" ", "\n", "\r", "\t")):
        return False
    return bool(re.fullmatch(r"[A-Za-z0-9+/=]+", s[:2048]))  # sample prefix


def b64_decode_limited(s: str, *, max_decoded_bytes: int = DEFAULT_MAX_B64_BYTES) -> bytes:
    """
    Decode base64 safely with a hard cap.
    """
    est = (len(s) * 3) // 4
    if est > max_decoded_bytes:
        raise ValueError(f"base64 blob too large (estimated {est} bytes > cap {max_decoded_bytes})")

    try:
        return base64.b64decode(s, validate=True)
    except binascii.Error:
        # Try padding fix + non-strict decode.
        pad = (-len(s)) % 4
        s2 = s + ("=" * pad)
        return base64.b64decode(s2, validate=False)


def sniff_image_type(blob: bytes) -> str:
    if blob.startswith(PNG_SIGNATURE):
        return "png"
    if blob[:3] == b"\xff\xd8\xff":
        return "jpg"
    if blob[:4] == b"RIFF" and blob[8:12] == b"WEBP":
        return "webp"
    return "bin"


def write_blob_dedup(blob: bytes, out_dir: Path, *, ext_hint: Optional[str] = None) -> Tuple[Path, str]:
    """
    Writes blob to out_dir using sha256 filename; returns (path, sha).
    Deduplicates by content hash.
    """
    safe_mkdir(out_dir)
    sha = sha256_bytes(blob)
    ext = ext_hint or sniff_image_type(blob)
    out_path = out_dir / f"{sha}.{ext}"
    if not out_path.exists():
        out_path.write_bytes(blob)
    return out_path, sha


FORBIDDEN_TERMINAL_URL_PATTERN = re.compile(
    r"Forbidden\.\s*Calls to this URL via the terminal is not allowed",
    re.IGNORECASE,
)


def detect_blocked_url_instruction(text: str) -> Optional[str]:
    """
    Returns a reason string if the text looks like a system/tool safety block for URL fetching.
    """
    if not isinstance(text, str):
        return None
    if FORBIDDEN_TERMINAL_URL_PATTERN.search(text):
        return "blocked_url_fetch_instruction"
    return None


# ----------------------------
# Parsed artifacts
# ----------------------------

@dataclass(frozen=True)
class MemoryEntry:
    idx: int
    raw: JsonDict
    entry_hash: str
    kind: Optional[str] = None
    text: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    source: Optional[str] = None


@dataclass(frozen=True)
class EncodedAsset:
    key: str
    kind: str  # "image" | "qr" | "unknown"
    sha256: Optional[str]
    path: Optional[str]
    note: Optional[str] = None
    raw_meta: JsonDict = field(default_factory=dict)


@dataclass
class BundleReport:
    root: str
    created_ms: int

    files_seen: List[str] = field(default_factory=list)

    jsonl_ok: int = 0
    jsonl_bad: int = 0
    assets_ok: int = 0
    assets_bad: int = 0
    blocked_instructions: int = 0
    unknown_blobs: int = 0

    unique_asset_hashes: int = 0
    notes: List[str] = field(default_factory=list)

    coherence_score: float = 0.0

    def as_json(self) -> JsonDict:
        return dataclasses.asdict(self)


@dataclass
class Bundle:
    root: str
    memory: List[MemoryEntry]
    assets: List[EncodedAsset]
    report: BundleReport


# ----------------------------
# Parsers
# ----------------------------

def parse_jsonl(path: Path, *, strict: bool = False) -> Tuple[List[MemoryEntry], int, int]:
    entries: List[MemoryEntry] = []
    ok = 0
    bad = 0

    for i, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            eh = sha256_bytes(stable_dumps(obj).encode("utf-8"))
            kind = obj.get("type") or obj.get("kind")
            text = obj.get("text") or obj.get("content") or obj.get("message")
            tags = obj.get("tags") or []
            if isinstance(tags, str):
                tags = [tags]
            source = None
            meta = obj.get("meta")
            if isinstance(meta, dict):
                source = meta.get("source") or meta.get("path")
            entries.append(MemoryEntry(idx=i, raw=obj, entry_hash=eh, kind=kind, text=text, tags=list(tags), source=source))
            ok += 1
        except Exception as e:
            bad += 1
            if strict:
                raise
            entries.append(MemoryEntry(idx=i, raw={"_bad_line": line, "_error": str(e)}, entry_hash=sha256_bytes(line.encode("utf-8"))))
    return entries, ok, bad


def walk_json_values(obj: Any, prefix: str = "") -> Iterable[Tuple[str, Any]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            yield from walk_json_values(v, p)
    elif isinstance(obj, list):
        for j, v in enumerate(obj):
            p = f"{prefix}[{j}]"
            yield from walk_json_values(v, p)
    else:
        yield prefix, obj


def parse_encodings_json(
    path: Path,
    *,
    assets_dir: Path,
    max_decoded_bytes: int = DEFAULT_MAX_B64_BYTES,
) -> Tuple[List[EncodedAsset], int, int, int, int]:
    assets: List[EncodedAsset] = []
    ok = 0
    bad = 0
    blocked = 0
    unknown = 0

    data = json.loads(path.read_text(encoding="utf-8", errors="replace"))

    for key_path, val in walk_json_values(data):
        if isinstance(val, str):
            reason = detect_blocked_url_instruction(val)
            if reason:
                blocked += 1
                assets.append(EncodedAsset(key=key_path, kind="qr", sha256=None, path=None, note=reason, raw_meta={"text": val[:2000]}))
                continue

        if isinstance(val, str) and is_probably_base64(val):
            try:
                blob = b64_decode_limited(val, max_decoded_bytes=max_decoded_bytes)
                ext = sniff_image_type(blob)
                if ext in ("png", "jpg", "webp"):
                    out_path, sha = write_blob_dedup(blob, assets_dir, ext_hint=ext)
                    assets.append(EncodedAsset(key=key_path, kind="image", sha256=sha, path=str(out_path), raw_meta={"ext": ext, "bytes": len(blob)}))
                    ok += 1
                else:
                    unknown += 1
                    sha = sha256_bytes(blob)
                    assets.append(EncodedAsset(key=key_path, kind="unknown", sha256=sha, path=None, note="decoded_non_image_blob", raw_meta={"bytes": len(blob)}))
                    ok += 1
            except Exception as e:
                bad += 1
                assets.append(EncodedAsset(key=key_path, kind="unknown", sha256=None, path=None, note=f"base64_decode_failed: {e}", raw_meta={}))

    return assets, ok, bad, blocked, unknown


# ----------------------------
# Coherence scoring (simple, honest, tunable)
# ----------------------------

def coherence_score(report: BundleReport) -> float:
    jsonl_total = report.jsonl_ok + report.jsonl_bad
    assets_total = report.assets_ok + report.assets_bad

    jsonl_rate = (report.jsonl_ok / jsonl_total) if jsonl_total else 0.0
    assets_rate = (report.assets_ok / assets_total) if assets_total else 0.0

    presence = 0.0
    presence += 0.5 if report.jsonl_ok > 0 else 0.0
    presence += 0.5 if (report.assets_ok > 0 or report.blocked_instructions > 0) else 0.0

    penalty = 0.0
    if jsonl_total:
        penalty += min(0.25, (report.jsonl_bad / jsonl_total) * 0.5)
    if assets_total:
        penalty += min(0.25, (report.assets_bad / assets_total) * 0.5)

    score = 0.45 * jsonl_rate + 0.45 * assets_rate + 0.10 * presence - penalty
    return max(0.0, min(1.0, score))


# ----------------------------
# Bundle entrypoint
# ----------------------------

def parse_bundle(
    root: Union[str, Path],
    *,
    assets_dirname: str = "_decoded_assets",
    jsonl_glob: str = "*.jsonl",
    encoding_json_names: Tuple[str, ...] = ("encodings.json",),
    strict_jsonl: bool = False,
    max_b64_decoded_bytes: int = DEFAULT_MAX_B64_BYTES,
) -> Bundle:
    rootp = Path(root).expanduser().resolve()
    report = BundleReport(root=str(rootp), created_ms=now_ms())

    if rootp.is_file():
        report.files_seen.append(str(rootp))
        base_root = rootp.parent
    else:
        base_root = rootp
        for p in sorted(base_root.rglob("*")):
            if p.is_file():
                report.files_seen.append(str(p))

    memory: List[MemoryEntry] = []
    for p in sorted(base_root.glob(jsonl_glob)):
        entries, ok, bad = parse_jsonl(p, strict=strict_jsonl)
        memory.extend(entries)
        report.jsonl_ok += ok
        report.jsonl_bad += bad

    assets_dir = base_root / assets_dirname
    assets: List[EncodedAsset] = []
    for name in encoding_json_names:
        p = base_root / name
        if p.exists() and p.is_file():
            a, ok, bad, blocked, unknown = parse_encodings_json(p, assets_dir=assets_dir, max_decoded_bytes=max_b64_decoded_bytes)
            assets.extend(a)
            report.assets_ok += ok
            report.assets_bad += bad
            report.blocked_instructions += blocked
            report.unknown_blobs += unknown

    report.unique_asset_hashes = len({a.sha256 for a in assets if a.sha256})
    report.coherence_score = coherence_score(report)
    report.notes.append("No PDFs were parsed here; index only. Use a downstream PDF reader if needed.")

    return Bundle(root=str(base_root), memory=memory, assets=assets, report=report)


# ----------------------------
# CLI
# ----------------------------

def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Parse a Möbii³us bundle into cohered archive artifacts.")
    ap.add_argument("--root", required=True, help="Root folder containing buddy_memory.jsonl / encodings.json / etc.")
    ap.add_argument("--assets-dirname", default="_decoded_assets", help="Where to write decoded base64 assets under root.")
    ap.add_argument("--jsonl-glob", default="*.jsonl", help="Glob for jsonl files under root (non-recursive).")
    ap.add_argument("--strict-jsonl", action="store_true", help="Fail fast on invalid JSONL lines.")
    ap.add_argument("--max-b64-bytes", type=int, default=DEFAULT_MAX_B64_BYTES, help="Max decoded base64 size.")
    ap.add_argument("--out", default="bundle_report.json", help="Write a JSON report file under root.")
    args = ap.parse_args(argv)

    bundle = parse_bundle(
        args.root,
        assets_dirname=args.assets_dirname,
        jsonl_glob=args.jsonl_glob,
        strict_jsonl=args.strict_jsonl,
        max_b64_decoded_bytes=args.max_b64_bytes,
    )

    out_path = Path(args.root).expanduser().resolve() / args.out
    out_path.write_text(stable_dumps(bundle.report.as_json()), encoding="utf-8")

    print(f"[bundle_parser] root={bundle.root}")
    print(f"[bundle_parser] jsonl_ok={bundle.report.jsonl_ok} jsonl_bad={bundle.report.jsonl_bad}")
    print(f"[bundle_parser] assets_ok={bundle.report.assets_ok} assets_bad={bundle.report.assets_bad}")
    print(f"[bundle_parser] blocked_instructions={bundle.report.blocked_instructions} unknown_blobs={bundle.report.unknown_blobs}")
    print(f"[bundle_parser] unique_asset_hashes={bundle.report.unique_asset_hashes}")
    print(f"[bundle_parser] coherence_score={bundle.report.coherence_score:.3f}")
    print(f"[bundle_parser] report_written={out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
