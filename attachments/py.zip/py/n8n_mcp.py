"""
n8n MCP Server — INTER Port for Workflow Automation

Exposes the n8n REST API as MCP tools so any MCP-compatible LLM
(Claude, ChatGPT, Grok, etc.) can orchestrate automated workflows.

This is the INTER wire: AI mesh → n8n → the world.

Tools:
  n8n_list_workflows      — List all workflows (with filters)
  n8n_get_workflow         — Get workflow details by ID
  n8n_create_workflow      — Create a new workflow from JSON
  n8n_update_workflow      — Update an existing workflow
  n8n_activate_workflow    — Activate a workflow
  n8n_deactivate_workflow  — Deactivate a workflow
  n8n_delete_workflow      — Delete a workflow
  n8n_execute_workflow     — Manually trigger/execute a workflow
  n8n_list_executions      — List executions (with filters)
  n8n_get_execution        — Get execution details
  n8n_stop_execution       — Stop a running execution
  n8n_retry_execution      — Retry a failed execution
  n8n_delete_execution     — Delete an execution record
  n8n_list_credentials     — List credentials
  n8n_get_credential_schema— Get schema for a credential type
  n8n_list_tags            — List tags
  n8n_create_tag           — Create a new tag
  n8n_trigger_webhook      — Trigger a webhook-based workflow
  n8n_run_audit            — Run security audit on instance

Env vars:
  N8N_BASE_URL   — n8n instance URL (e.g. http://159.203.18.124:5678)
  N8N_API_KEY    — API key for authentication

Usage:
  # stdio (local, for Claude Code / desktop)
  python n8n_mcp.py

  # streamable HTTP (remote, for multi-client)
  python n8n_mcp.py --http --port 8765
"""

import json
import os
import sys
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

import httpx
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field, field_validator

# ── Configuration ───────────────────────────────────────────

N8N_BASE_URL = os.environ.get("N8N_BASE_URL", "http://localhost:5678")
N8N_API_KEY = os.environ.get("N8N_API_KEY", "")
API_PREFIX = "/api/v1"
DEFAULT_TIMEOUT = 30.0

# ── Server Init ─────────────────────────────────────────────

mcp = FastMCP("n8n_mcp")

# ── Shared HTTP Client ──────────────────────────────────────


def _headers() -> Dict[str, str]:
    """Build auth headers for n8n API."""
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    if N8N_API_KEY:
        h["X-N8N-API-KEY"] = N8N_API_KEY
    return h


def _url(path: str) -> str:
    """Build full URL for an n8n API endpoint."""
    base = N8N_BASE_URL.rstrip("/")
    return f"{base}{API_PREFIX}{path}"


async def _get(path: str, params: Optional[Dict] = None) -> Dict[str, Any]:
    """GET request to n8n API."""
    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
        resp = await client.get(_url(path), headers=_headers(), params=params)
        resp.raise_for_status()
        return resp.json()


async def _post(path: str, body: Optional[Dict] = None) -> Dict[str, Any]:
    """POST request to n8n API."""
    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
        resp = await client.post(_url(path), headers=_headers(), json=body or {})
        resp.raise_for_status()
        return resp.json()


async def _put(path: str, body: Optional[Dict] = None) -> Dict[str, Any]:
    """PUT request to n8n API."""
    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
        resp = await client.put(_url(path), headers=_headers(), json=body or {})
        resp.raise_for_status()
        return resp.json()


async def _delete(path: str) -> Dict[str, Any]:
    """DELETE request to n8n API."""
    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
        resp = await client.delete(_url(path), headers=_headers())
        resp.raise_for_status()
        try:
            return resp.json()
        except Exception:
            return {"status": "deleted"}


async def _post_raw(url: str, body: Optional[Dict] = None) -> Dict[str, Any]:
    """POST to an arbitrary URL (for webhooks)."""
    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
        resp = await client.post(url, headers={"Content-Type": "application/json"}, json=body or {})
        resp.raise_for_status()
        try:
            return resp.json()
        except Exception:
            return {"status": resp.status_code, "text": resp.text[:500]}


def _handle_error(e: Exception) -> str:
    """Consistent error formatting."""
    if isinstance(e, httpx.HTTPStatusError):
        code = e.response.status_code
        try:
            detail = e.response.json().get("message", e.response.text[:300])
        except Exception:
            detail = e.response.text[:300]
        if code == 401:
            return f"Error 401: Authentication failed. Check N8N_API_KEY. Detail: {detail}"
        if code == 403:
            return f"Error 403: Permission denied. Detail: {detail}"
        if code == 404:
            return f"Error 404: Resource not found. Check the ID. Detail: {detail}"
        if code == 429:
            return "Error 429: Rate limit exceeded. Wait before retrying."
        return f"Error {code}: {detail}"
    if isinstance(e, httpx.TimeoutException):
        return "Error: Request timed out. Check if n8n is running and reachable."
    if isinstance(e, httpx.ConnectError):
        return f"Error: Cannot connect to n8n at {N8N_BASE_URL}. Is it running?"
    return f"Error: {type(e).__name__}: {str(e)[:300]}"


# ── Response Formatting ─────────────────────────────────────

class ResponseFormat(str, Enum):
    MARKDOWN = "markdown"
    JSON = "json"


def _fmt(data: Any, fmt: ResponseFormat = ResponseFormat.MARKDOWN, title: str = "") -> str:
    """Format response as JSON or Markdown."""
    if fmt == ResponseFormat.JSON:
        return json.dumps(data, indent=2, default=str)

    # Markdown formatting
    if isinstance(data, dict):
        lines = []
        if title:
            lines.append(f"## {title}\n")
        for k, v in data.items():
            if isinstance(v, (dict, list)):
                lines.append(f"**{k}**: ```{json.dumps(v, indent=2, default=str)[:500]}```")
            else:
                lines.append(f"**{k}**: {v}")
        return "\n".join(lines)

    if isinstance(data, list):
        lines = []
        if title:
            lines.append(f"## {title} ({len(data)} items)\n")
        for i, item in enumerate(data):
            if isinstance(item, dict):
                name = item.get("name", item.get("id", f"#{i+1}"))
                wid = item.get("id", "")
                active = item.get("active", "")
                lines.append(f"- **{name}** (ID: {wid}) {'✅ active' if active else '⏸ inactive' if active is False else ''}")
            else:
                lines.append(f"- {item}")
        return "\n".join(lines)

    return str(data)


# ═══════════════════════════════════════════════════════════
#  WORKFLOW TOOLS
# ═══════════════════════════════════════════════════════════


class ListWorkflowsInput(BaseModel):
    """Input for listing workflows."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    active: Optional[bool] = Field(default=None, description="Filter by active status (true/false). Omit to get all.")
    tags: Optional[str] = Field(default=None, description="Filter by tag name")
    limit: Optional[int] = Field(default=20, description="Max results to return", ge=1, le=100)
    cursor: Optional[str] = Field(default=None, description="Pagination cursor from previous response")
    response_format: ResponseFormat = Field(default=ResponseFormat.MARKDOWN, description="Output format: 'markdown' or 'json'")


@mcp.tool(
    name="n8n_list_workflows",
    annotations={
        "title": "List n8n Workflows",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def n8n_list_workflows(params: ListWorkflowsInput) -> str:
    """List all workflows in the n8n instance with optional filters.

    Returns workflow names, IDs, and active status. Use pagination
    cursor for large result sets.

    Args:
        params: Filter and pagination options

    Returns:
        str: Formatted list of workflows with IDs and status
    """
    try:
        qp: Dict[str, Any] = {"limit": params.limit}
        if params.active is not None:
            qp["active"] = str(params.active).lower()
        if params.tags:
            qp["tags"] = params.tags
        if params.cursor:
            qp["cursor"] = params.cursor

        data = await _get("/workflows", params=qp)
        workflows = data.get("data", data) if isinstance(data, dict) else data
        return _fmt(workflows, params.response_format, "Workflows")
    except Exception as e:
        return _handle_error(e)


class GetWorkflowInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    workflow_id: str = Field(..., description="Workflow ID (e.g., '12345' or 'wf_abc')", min_length=1)
    response_format: ResponseFormat = Field(default=ResponseFormat.MARKDOWN)


@mcp.tool(
    name="n8n_get_workflow",
    annotations={"title": "Get Workflow Details", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_get_workflow(params: GetWorkflowInput) -> str:
    """Get full details of a specific workflow by ID.

    Returns the complete workflow definition including nodes, connections,
    settings, and metadata.

    Args:
        params: Workflow ID and format preference

    Returns:
        str: Complete workflow details
    """
    try:
        data = await _get(f"/workflows/{params.workflow_id}")
        return _fmt(data, params.response_format, f"Workflow: {data.get('name', params.workflow_id)}")
    except Exception as e:
        return _handle_error(e)


class CreateWorkflowInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    name: str = Field(..., description="Workflow name", min_length=1, max_length=128)
    nodes: str = Field(..., description="JSON array of node definitions")
    connections: str = Field(default="{}", description="JSON object defining node connections")
    settings: Optional[str] = Field(default=None, description="JSON object with workflow settings")
    active: bool = Field(default=False, description="Whether to activate immediately")

    @field_validator("nodes")
    @classmethod
    def validate_nodes_json(cls, v: str) -> str:
        try:
            parsed = json.loads(v)
            if not isinstance(parsed, list):
                raise ValueError("nodes must be a JSON array")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in nodes: {e}")
        return v


@mcp.tool(
    name="n8n_create_workflow",
    annotations={"title": "Create Workflow", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_create_workflow(params: CreateWorkflowInput) -> str:
    """Create a new workflow in n8n from a JSON definition.

    Provide node definitions and connections to build the workflow.
    Can optionally activate it immediately.

    Args:
        params: Workflow name, nodes JSON, connections, and settings

    Returns:
        str: Created workflow details including its new ID
    """
    try:
        body: Dict[str, Any] = {
            "name": params.name,
            "nodes": json.loads(params.nodes),
            "connections": json.loads(params.connections),
            "active": params.active,
        }
        if params.settings:
            body["settings"] = json.loads(params.settings)

        data = await _post("/workflows", body=body)
        return _fmt(data, ResponseFormat.MARKDOWN, f"Created: {data.get('name', params.name)}")
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON input: {e}"
    except Exception as e:
        return _handle_error(e)


class UpdateWorkflowInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    workflow_id: str = Field(..., description="ID of workflow to update", min_length=1)
    workflow_json: str = Field(..., description="Complete workflow JSON object for the update")


@mcp.tool(
    name="n8n_update_workflow",
    annotations={"title": "Update Workflow", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_update_workflow(params: UpdateWorkflowInput) -> str:
    """Update an existing workflow with a new definition.

    Provide the complete workflow JSON. Fetch the current version first
    with n8n_get_workflow to avoid overwriting changes.

    Args:
        params: Workflow ID and updated JSON definition

    Returns:
        str: Updated workflow details
    """
    try:
        body = json.loads(params.workflow_json)
        data = await _put(f"/workflows/{params.workflow_id}", body=body)
        return _fmt(data, ResponseFormat.MARKDOWN, f"Updated: {data.get('name', params.workflow_id)}")
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON: {e}"
    except Exception as e:
        return _handle_error(e)


class WorkflowIdInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    workflow_id: str = Field(..., description="Workflow ID", min_length=1)


@mcp.tool(
    name="n8n_activate_workflow",
    annotations={"title": "Activate Workflow", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_activate_workflow(params: WorkflowIdInput) -> str:
    """Activate a workflow so it responds to triggers.

    Args:
        params: Workflow ID to activate

    Returns:
        str: Confirmation with workflow status
    """
    try:
        data = await _post(f"/workflows/{params.workflow_id}/activate")
        return f"✅ Workflow **{data.get('name', params.workflow_id)}** activated (ID: {params.workflow_id})"
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="n8n_deactivate_workflow",
    annotations={"title": "Deactivate Workflow", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_deactivate_workflow(params: WorkflowIdInput) -> str:
    """Deactivate a workflow so it stops responding to triggers.

    Args:
        params: Workflow ID to deactivate

    Returns:
        str: Confirmation with workflow status
    """
    try:
        data = await _post(f"/workflows/{params.workflow_id}/deactivate")
        return f"⏸ Workflow **{data.get('name', params.workflow_id)}** deactivated (ID: {params.workflow_id})"
    except Exception as e:
        return _handle_error(e)


@mcp.tool(
    name="n8n_delete_workflow",
    annotations={"title": "Delete Workflow", "readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_delete_workflow(params: WorkflowIdInput) -> str:
    """Permanently delete a workflow. This action cannot be undone.

    Args:
        params: Workflow ID to delete

    Returns:
        str: Deletion confirmation
    """
    try:
        await _delete(f"/workflows/{params.workflow_id}")
        return f"🗑️ Workflow {params.workflow_id} deleted permanently."
    except Exception as e:
        return _handle_error(e)


class ExecuteWorkflowInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    workflow_id: str = Field(..., description="Workflow ID to execute", min_length=1)
    input_data: Optional[str] = Field(default=None, description="JSON object to pass as input data to the workflow")

    @field_validator("input_data")
    @classmethod
    def validate_input_json(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            try:
                json.loads(v)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON in input_data: {e}")
        return v


@mcp.tool(
    name="n8n_execute_workflow",
    annotations={"title": "Execute Workflow", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_execute_workflow(params: ExecuteWorkflowInput) -> str:
    """Manually trigger and execute a workflow.

    Optionally pass input data as JSON that the workflow's trigger
    node will receive. Returns execution result.

    Args:
        params: Workflow ID and optional input data JSON

    Returns:
        str: Execution result including status and output data
    """
    try:
        body: Dict[str, Any] = {}
        if params.input_data:
            body = json.loads(params.input_data)

        # n8n v1 API: POST /workflows/{id}/run  or  POST /executions
        # Try the direct execution endpoint first
        try:
            data = await _post(f"/workflows/{params.workflow_id}/run", body=body)
        except httpx.HTTPStatusError:
            # Fallback: use /executions with workflowId
            data = await _post("/executions", body={"workflowId": params.workflow_id, "data": body})

        return _fmt(data, ResponseFormat.MARKDOWN, f"Execution: Workflow {params.workflow_id}")
    except Exception as e:
        return _handle_error(e)


# ═══════════════════════════════════════════════════════════
#  EXECUTION TOOLS
# ═══════════════════════════════════════════════════════════


class ListExecutionsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    workflow_id: Optional[str] = Field(default=None, description="Filter by workflow ID")
    status: Optional[str] = Field(default=None, description="Filter by status: 'success', 'error', 'waiting', 'running'")
    limit: Optional[int] = Field(default=20, ge=1, le=100)
    cursor: Optional[str] = Field(default=None, description="Pagination cursor")
    response_format: ResponseFormat = Field(default=ResponseFormat.MARKDOWN)


@mcp.tool(
    name="n8n_list_executions",
    annotations={"title": "List Executions", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_list_executions(params: ListExecutionsInput) -> str:
    """List workflow executions with optional filters.

    Filter by workflow ID, status (success/error/waiting/running),
    and paginate through results.

    Args:
        params: Filter and pagination options

    Returns:
        str: List of executions with status and timing info
    """
    try:
        qp: Dict[str, Any] = {"limit": params.limit}
        if params.workflow_id:
            qp["workflowId"] = params.workflow_id
        if params.status:
            qp["status"] = params.status
        if params.cursor:
            qp["cursor"] = params.cursor

        data = await _get("/executions", params=qp)
        executions = data.get("data", data) if isinstance(data, dict) else data
        return _fmt(executions, params.response_format, "Executions")
    except Exception as e:
        return _handle_error(e)


class ExecutionIdInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    execution_id: str = Field(..., description="Execution ID", min_length=1)
    response_format: ResponseFormat = Field(default=ResponseFormat.MARKDOWN)


@mcp.tool(
    name="n8n_get_execution",
    annotations={"title": "Get Execution Details", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_get_execution(params: ExecutionIdInput) -> str:
    """Get detailed information about a specific execution.

    Returns execution status, timing, input/output data, and
    per-node execution details.

    Args:
        params: Execution ID

    Returns:
        str: Complete execution details
    """
    try:
        data = await _get(f"/executions/{params.execution_id}")
        return _fmt(data, params.response_format, f"Execution {params.execution_id}")
    except Exception as e:
        return _handle_error(e)


class StopExecutionInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    execution_id: str = Field(..., description="Execution ID to stop", min_length=1)


@mcp.tool(
    name="n8n_stop_execution",
    annotations={"title": "Stop Execution", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_stop_execution(params: StopExecutionInput) -> str:
    """Stop a currently running execution.

    Args:
        params: Execution ID to stop

    Returns:
        str: Confirmation of stop
    """
    try:
        data = await _post(f"/executions/{params.execution_id}/stop")
        return f"⏹ Execution {params.execution_id} stopped. Status: {data.get('status', 'stopped')}"
    except Exception as e:
        return _handle_error(e)


class RetryExecutionInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    execution_id: str = Field(..., description="Execution ID to retry", min_length=1)
    load_workflow: bool = Field(default=False, description="If true, use current workflow version. If false, use the version from the original execution.")


@mcp.tool(
    name="n8n_retry_execution",
    annotations={"title": "Retry Execution", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_retry_execution(params: RetryExecutionInput) -> str:
    """Retry a failed execution.

    Can use either the original workflow version or the current version.
    Set load_workflow=true to test if recent changes fix the issue.

    Args:
        params: Execution ID and workflow version preference

    Returns:
        str: New execution details from the retry
    """
    try:
        body = {"loadWorkflow": params.load_workflow}
        data = await _post(f"/executions/{params.execution_id}/retry", body=body)
        return _fmt(data, ResponseFormat.MARKDOWN, f"Retry of Execution {params.execution_id}")
    except Exception as e:
        return _handle_error(e)


class DeleteExecutionInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    execution_id: str = Field(..., description="Execution ID to delete", min_length=1)


@mcp.tool(
    name="n8n_delete_execution",
    annotations={"title": "Delete Execution", "readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_delete_execution(params: DeleteExecutionInput) -> str:
    """Delete an execution record permanently.

    Args:
        params: Execution ID to delete

    Returns:
        str: Deletion confirmation
    """
    try:
        await _delete(f"/executions/{params.execution_id}")
        return f"🗑️ Execution {params.execution_id} deleted."
    except Exception as e:
        return _handle_error(e)


# ═══════════════════════════════════════════════════════════
#  CREDENTIALS TOOLS
# ═══════════════════════════════════════════════════════════


class ListCredentialsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    limit: Optional[int] = Field(default=20, ge=1, le=100)
    response_format: ResponseFormat = Field(default=ResponseFormat.MARKDOWN)


@mcp.tool(
    name="n8n_list_credentials",
    annotations={"title": "List Credentials", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_list_credentials(params: ListCredentialsInput) -> str:
    """List all credentials configured in the n8n instance.

    Returns credential names, types, and IDs. Does NOT return
    credential secrets for security.

    Args:
        params: Limit and format

    Returns:
        str: List of credentials (names and types only)
    """
    try:
        data = await _get("/credentials", params={"limit": params.limit})
        creds = data.get("data", data) if isinstance(data, dict) else data
        return _fmt(creds, params.response_format, "Credentials")
    except Exception as e:
        return _handle_error(e)


class CredentialSchemaInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    credential_type: str = Field(..., description="Credential type name (e.g., 'slackApi', 'githubApi', 'httpBasicAuth')", min_length=1)


@mcp.tool(
    name="n8n_get_credential_schema",
    annotations={"title": "Get Credential Schema", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_get_credential_schema(params: CredentialSchemaInput) -> str:
    """Get the JSON schema for a specific credential type.

    Shows required fields, types, and descriptions needed to
    create a credential of this type.

    Args:
        params: Credential type name

    Returns:
        str: JSON schema showing required fields
    """
    try:
        data = await _get(f"/credentials/schema/{params.credential_type}")
        return json.dumps(data, indent=2, default=str)
    except Exception as e:
        return _handle_error(e)


# ═══════════════════════════════════════════════════════════
#  TAGS TOOLS
# ═══════════════════════════════════════════════════════════


class ListTagsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    limit: Optional[int] = Field(default=50, ge=1, le=100)
    response_format: ResponseFormat = Field(default=ResponseFormat.MARKDOWN)


@mcp.tool(
    name="n8n_list_tags",
    annotations={"title": "List Tags", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_list_tags(params: ListTagsInput) -> str:
    """List all tags used to organize workflows.

    Args:
        params: Limit and format

    Returns:
        str: List of tags with IDs
    """
    try:
        data = await _get("/tags", params={"limit": params.limit})
        tags = data.get("data", data) if isinstance(data, dict) else data
        return _fmt(tags, params.response_format, "Tags")
    except Exception as e:
        return _handle_error(e)


class CreateTagInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    name: str = Field(..., description="Tag name", min_length=1, max_length=100)


@mcp.tool(
    name="n8n_create_tag",
    annotations={"title": "Create Tag", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_create_tag(params: CreateTagInput) -> str:
    """Create a new tag for organizing workflows.

    Args:
        params: Tag name

    Returns:
        str: Created tag with ID
    """
    try:
        data = await _post("/tags", body={"name": params.name})
        return f"🏷️ Tag created: **{data.get('name', params.name)}** (ID: {data.get('id', '?')})"
    except Exception as e:
        return _handle_error(e)


# ═══════════════════════════════════════════════════════════
#  WEBHOOK TOOL
# ═══════════════════════════════════════════════════════════


class TriggerWebhookInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    webhook_url: str = Field(
        ...,
        description="Full webhook URL (e.g., 'http://159.203.18.124:5678/webhook/my-hook' or production URL from n8n)",
        min_length=10,
    )
    payload: Optional[str] = Field(default=None, description="JSON payload to send to the webhook")

    @field_validator("webhook_url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")):
            raise ValueError("webhook_url must start with http:// or https://")
        return v

    @field_validator("payload")
    @classmethod
    def validate_payload(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            try:
                json.loads(v)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON payload: {e}")
        return v


@mcp.tool(
    name="n8n_trigger_webhook",
    annotations={"title": "Trigger Webhook", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True},
)
async def n8n_trigger_webhook(params: TriggerWebhookInput) -> str:
    """Trigger a webhook-based workflow by sending a POST request.

    Use this to manually invoke workflows that start with a Webhook
    trigger node. Optionally include a JSON payload.

    Args:
        params: Webhook URL and optional JSON payload

    Returns:
        str: Webhook response from the workflow
    """
    try:
        body = json.loads(params.payload) if params.payload else {}
        data = await _post_raw(params.webhook_url, body=body)
        return _fmt(data, ResponseFormat.MARKDOWN, "Webhook Response")
    except json.JSONDecodeError as e:
        return f"Error: Invalid JSON payload: {e}"
    except Exception as e:
        return _handle_error(e)


# ═══════════════════════════════════════════════════════════
#  AUDIT TOOL
# ═══════════════════════════════════════════════════════════


class AuditInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    categories: Optional[str] = Field(
        default=None,
        description="Comma-separated risk categories to audit (e.g., 'credentials,nodes,filesystem'). Omit for all.",
    )


@mcp.tool(
    name="n8n_run_audit",
    annotations={"title": "Run Security Audit", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def n8n_run_audit(params: AuditInput) -> str:
    """Run a security audit on the n8n instance.

    Checks for risk categories like credentials exposure, dangerous nodes,
    filesystem access, and abandoned workflows.

    Args:
        params: Optional category filter

    Returns:
        str: Audit report with findings
    """
    try:
        qp = {}
        if params.categories:
            qp["categories"] = params.categories
        data = await _post("/audit", body=qp)
        return json.dumps(data, indent=2, default=str)
    except Exception as e:
        return _handle_error(e)


# ═══════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="n8n MCP Server")
    parser.add_argument("--http", action="store_true", help="Use streamable HTTP transport (default: stdio)")
    parser.add_argument("--port", type=int, default=8765, help="HTTP port (default: 8765)")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="HTTP host (default: 127.0.0.1)")
    args = parser.parse_args()

    if not N8N_API_KEY:
        print("⚠️  N8N_API_KEY not set. Set via: export N8N_API_KEY='your-key'", file=sys.stderr)
        print(f"   Connecting to: {N8N_BASE_URL}", file=sys.stderr)

    if args.http:
        print(f"🌐 n8n MCP Server starting on http://{args.host}:{args.port}", file=sys.stderr)
        mcp.run(transport="streamable_http", host=args.host, port=args.port)
    else:
        print("🔌 n8n MCP Server starting on stdio", file=sys.stderr)
        mcp.run()
