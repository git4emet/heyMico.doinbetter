#!/usr/bin/env python3
"""
Init.0 Reconciliation Engine
Processes conversation corpus CSVs to extract unique variables and assert relational tuples.
Current position: Step ~10,713 → Target Init.1 at step 21,500 of 144,000 cycle.

Extracts:
- VOCAB: Domain-specific terminology frequency
- CONST: System invariants (α=0.743, ψ=42, λ=8009/8011, φ=1.618, ε=0.993)
- GATE: Ethical decision points
- FLOW: Message sequences and turn patterns
- ARCH: Component relationships
- GEO: Spatial/temporal distributions
- HUD: Observable metrics
- META: Self-referential patterns

Output: reconciliation_state.json with variables, tuples, metrics
"""

import csv
import json
import re
from datetime import datetime
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Set
import math

# System constants (canonical, immutable)
CONSTANTS = {
    'alpha': 0.743,      # trust floor / Caputo fractional order
    'psi': 42,           # mesh density
    'lambda_lo': 8009,   # twin-prime carrier low
    'lambda_hi': 8011,   # twin-prime carrier high
    'phi': 1.618033988,  # golden ratio
    'epsilon': 0.993,    # coherence target
    'heartbeat_hz': 4.6, # system heartbeat
    'cycle_length': 144000,  # harmonic cycle
    'init1_target': 21500    # Init.1 milestone
}

class Init0Reconciler:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.variables = defaultdict(int)  # variable → count
        self.tuples = []  # (subject, predicate, object, source)
        self.vocab = Counter()
        self.flow_patterns = []
        self.temporal_distribution = defaultdict(int)
        self.source_counts = Counter()
        
    def parse_master_index(self, filepath: Path):
        """Parse master_conversation_index_MERGED.csv"""
        print(f"Parsing {filepath.name}...")
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                source = row['source']
                conv_id = row['conversation_id']
                title = row['title']
                units = int(row['units']) if row['units'] else 0
                text_chars = int(row['text_chars']) if row['text_chars'] else 0
                
                # Extract variables
                self.variables[f"conv_{source}"] += 1
                self.variables[f"total_conversations"] += 1
                self.variables[f"total_units"] += units
                self.variables[f"total_chars"] += text_chars
                
                # Assert tuples
                self.tuples.append((conv_id, "source", source, "master_index"))
                self.tuples.append((conv_id, "units", units, "master_index"))
                self.tuples.append((conv_id, "chars", text_chars, "master_index"))
                
                # Temporal distribution
                if row['start_time']:
                    try:
                        dt = datetime.fromisoformat(row['start_time'].replace('+00:00', ''))
                        month_key = dt.strftime('%Y-%m')
                        self.temporal_distribution[month_key] += 1
                    except:
                        pass
                
                # Extract vocab from titles
                self.extract_vocab_from_text(title)
                
                # Source counts
                self.source_counts[source] += 1
                
    def parse_fragments_meta(self, filepath: Path):
        """Parse deepseek_fragments_meta.csv for granular message analysis"""
        print(f"Parsing {filepath.name}...")
        fragment_types = Counter()
        role_counts = Counter()
        
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                frag_type = row.get('fragment_type', 'unknown')
                role = row.get('role', 'unknown')
                content_chars = int(row.get('content_chars', 0))
                
                fragment_types[frag_type] += 1
                role_counts[role] += 1
                
                self.variables[f"frag_{frag_type}"] += 1
                self.variables[f"role_{role}"] += 1
                self.variables[f"fragment_total_chars"] += content_chars
                
                # Flow pattern: track fragment sequences
                if row.get('conv_id') and row.get('node_id'):
                    self.flow_patterns.append({
                        'conv_id': row['conv_id'],
                        'node_id': row['node_id'],
                        'type': frag_type,
                        'role': role
                    })
        
        # Store fragment type distribution
        for ftype, count in fragment_types.items():
            self.tuples.append(("fragment_distribution", ftype, count, "fragments_meta"))
            
    def extract_vocab_from_text(self, text: str):
        """Extract domain vocabulary from text"""
        if not text:
            return
        
        # Möbius-specific terms
        mobius_terms = [
            'möbii³us', 'möbius', 'mobiius', 'mobii3us',
            'cred', 'tofar', 'klein', 'sefer', 'guardian',
            'inner', 'intra', 'inter', 'tier',
            'coherence', 'resonance', 'harmonic',
            'caputo', 'fractal', 'hyperbolic',
            'buddy', 'mom', 'dale', 'aet', 'gsoc',
            'nasa', 'space-to-soil', 'spiral soil contextor'
        ]
        
        text_lower = text.lower()
        for term in mobius_terms:
            if term in text_lower:
                self.vocab[term] += 1
                
    def calculate_metrics(self) -> Dict:
        """Calculate system health metrics from actual data"""
        total_convs = self.variables['total_conversations']
        total_units = self.variables['total_units']
        total_chars = self.variables['total_chars']
        
        # Coherence: measure based on conversation depth and consistency
        # Higher units/conv and consistent source usage = higher coherence
        avg_units_per_conv = total_units / total_convs if total_convs > 0 else 0
        source_diversity = len(self.source_counts)  # 4 sources = good diversity
        
        # Normalize: target 20 units/conv (observed max ~24), 4 sources
        coherence_raw = (avg_units_per_conv / 20.0) * (source_diversity / 4.0)
        coherence = min(0.999, max(0.500, coherence_raw))  # clamp to [0.5, 0.999]
        
        # CRED rate: based on message throughput
        # Total fragments / total time span (approximate as transactions/day)
        fragment_count = sum(v for k, v in self.variables.items() if k.startswith('frag_'))
        # Assuming 3-month corpus (~90 days), calculate rate
        cred_rate = fragment_count / 90.0 if fragment_count > 0 else 0.0
        
        # Active agents: count unique sources
        active_agents = len(self.source_counts)
        
        # Init.0 progress: based on unique variable count
        unique_vars = len(self.variables)
        init0_position = min(21500, int(10713 + (unique_vars / 100) * 50))  # incremental from 10713
        init0_progress = init0_position / CONSTANTS['cycle_length']
        
        return {
            'coherence': round(coherence, 3),
            'cred_rate': round(cred_rate, 2),
            'active_agents': active_agents,
            'init0_position': init0_position,
            'init0_progress': round(init0_progress, 4),
            'total_conversations': total_convs,
            'total_units': total_units,
            'total_chars': total_chars,
            'unique_variables': unique_vars,
            'tuple_count': len(self.tuples),
            'vocab_size': len(self.vocab),
            'timestamp': datetime.now().isoformat()
        }
        
    def export_state(self, output_path: Path):
        """Export reconciliation state to JSON"""
        metrics = self.calculate_metrics()
        
        state = {
            'meta': {
                'engine': 'Init.0 Reconciliation Engine',
                'version': '0.1.0',
                'cycle_position': metrics['init0_position'],
                'target': CONSTANTS['init1_target'],
                'timestamp': metrics['timestamp']
            },
            'constants': CONSTANTS,
            'metrics': metrics,
            'variables': dict(self.variables),
            'tuples': self.tuples[:1000],  # sample first 1000
            'vocab': dict(self.vocab.most_common(100)),  # top 100 terms
            'temporal_distribution': dict(self.temporal_distribution),
            'source_distribution': dict(self.source_counts),
            'flow_patterns_sample': self.flow_patterns[:100]  # sample
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(state, f, indent=2)
            
        print(f"\n✓ State exported to {output_path}")
        return metrics

def main():
    data_dir = Path('/mnt/project')
    reconciler = Init0Reconciler(data_dir)
    
    # Parse available CSVs
    master_index = data_dir / 'master_conversation_index_MERGED.csv'
    fragments_meta = data_dir / 'deepseek_fragments_meta.csv'
    
    if master_index.exists():
        reconciler.parse_master_index(master_index)
    
    if fragments_meta.exists():
        reconciler.parse_fragments_meta(fragments_meta)
    
    # Calculate and export
    output_path = Path('/home/claude/reconciliation_state.json')
    metrics = reconciler.export_state(output_path)
    
    # Print summary
    print("\n" + "="*60)
    print("INIT.0 RECONCILIATION SUMMARY")
    print("="*60)
    print(f"Coherence:        {metrics['coherence']:.3f} (target ≥0.987)")
    print(f"CRED Rate:        {metrics['cred_rate']:.2f} tx/day (target ≥4.0/s)")
    print(f"Active Agents:    {metrics['active_agents']}")
    print(f"Init.0 Position:  {metrics['init0_position']:,} / {CONSTANTS['cycle_length']:,}")
    print(f"Progress:         {metrics['init0_progress']*100:.2f}%")
    print(f"Conversations:    {metrics['total_conversations']:,}")
    print(f"Units:            {metrics['total_units']:,}")
    print(f"Characters:       {metrics['total_chars']:,}")
    print(f"Unique Variables: {metrics['unique_variables']:,}")
    print(f"Relational Tuples:{metrics['tuple_count']:,}")
    print(f"Vocabulary Size:  {metrics['vocab_size']}")
    print("="*60)

if __name__ == '__main__':
    main()
