# SC Batch 71 - Evolutic Origami Fix Pack

This package applies a **non-destructive correction layer** to the uploaded Claude,
DeepSeek, PDF, Markdown, and email carriers.

## Files

- `SC-BATCH-71-EVOLUTIC-ORIGAMI-CORRECTION.md` - human-readable lock
- `batch71_source_rail_manifest.csv` - Airtable-friendly manifest
- `batch71_source_rail_manifest.jsonl` - streamable manifest
- `foreign_model_authority_overlay.json` - machine-readable demotion rules
- `evolutic_origami_skill_fold.csv` - stable verbs compressed into candidate SkillCards
- `canon_delta.json` - explicit zero-canon-addition receipt
- `n8nethos_evolutic_origami_intake.json` - importable no-network n8n policy workflow

## Important

The original uploaded files are unchanged. Load the authority overlay beside them.
