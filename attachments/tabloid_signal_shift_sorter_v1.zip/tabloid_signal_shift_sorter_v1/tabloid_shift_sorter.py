#!/usr/bin/env python3
"""
Tabloid Signal Shift Sorter v1

Purpose
-------
Sort user-provided conversation fragments into attention shifts and practical
project lanes without profiling outsiders or searching private data.

Research-inspired attention shifts:
  ODDITY   - unexpected, strange, surprising
  FRICTION - conflict, contradiction, collision
  STAKES   - consequence, gain/loss, urgency
  FACE     - a person/character makes the idea legible
  FRAME    - strong image, scene, prop, interface, or visual proof
  NOW      - timeliness, change, launch, "just happened"
  RECEIPT  - evidence, source, log, test, artifact, citation

The sorter keeps publicity and truth separate:
  publicity_score answers: "Would this catch attention?"
  evidence_score answers:  "How well supported is it?"
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional, Sequence
import argparse
import json
import math
import re
import sys
from pathlib import Path


SHIFT_ORDER = (
    "ODDITY",
    "FRICTION",
    "STAKES",
    "FACE",
    "FRAME",
    "NOW",
    "RECEIPT",
)

KEYWORDS: Dict[str, set[str]] = {
    "ODDITY": {
        "weird", "strange", "cryptic", "wonka", "spud", "dojo", "graffiti",
        "starport", "freejazz", "moire", "julia", "fibonacci", "fibb", "madlib",
        "surprise", "unexpected", "absurd", "glitch", "symbol", "riddle",
    },
    "FRICTION": {
        "versus", "vs", "conflict", "swap", "collision", "contradiction",
        "misread", "wrong", "fails", "failure", "bug", "break", "argument",
        "blocked", "paparazzo", "pi", "stalker", "guard", "risk",
    },
    "STAKES": {
        "help", "rescue", "casualty", "fund", "crowdfund", "money", "safe",
        "privacy", "secret", "protect", "loss", "gain", "urgent", "critical",
        "launch", "public", "company", "account", "credential",
    },
    "FACE": {
        "buddy", "mom", "dale", "peter", "paul", "robin", "pi", "paparazzo",
        "creator", "founder", "funder", "builder", "worker", "character",
    },
    "FRAME": {
        "image", "picture", "poster", "svg", "smil", "screen", "interface",
        "button", "hover", "dojo", "graffiti", "rose", "compass", "stage",
        "starport", "dashboard", "prop", "visual", "map",
    },
    "NOW": {
        "now", "today", "tonight", "nightly", "latest", "new", "launch",
        "just", "current", "update", "breaking", "live", "next", "ready",
    },
    "RECEIPT": {
        "source", "log", "loader", "manifest", "hash", "sha", "receipt",
        "tofar", "cred", "citation", "test", "verified", "evidence", "artifact",
        "file", "repo", "git", "commit", "schema", "json", "ijson",
    },
}

UTILITY_WORDS = {
    "code", "api", "module", "function", "class", "loader", "parser", "schema",
    "json", "ijson", "svg", "smil", "html", "css", "python", "repo", "git",
    "indexer", "sorter", "pipeline", "interface", "runtime", "service",
}

CLAIM_WORDS = {
    "proven", "guaranteed", "perfect", "complete", "fully", "live", "deployed",
    "production-ready", "verified", "works", "accurate", "accuracy", "100%",
}

EVIDENCE_WORDS = {
    "log", "receipt", "test", "tested", "source", "citation", "artifact",
    "manifest", "hash", "sha256", "commit", "screenshot", "measurement",
    "verified", "result", "output",
}

# Conservative detectors; these are for guarding user-provided text, not
# identifying people.
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)\d{3}[\s.-]?\d{4}(?!\d)")
TOKEN_RE = re.compile(
    r"\b(?:sk-[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9]{20,}|"
    r"AIza[A-Za-z0-9_-]{20,}|Bearer\s+[A-Za-z0-9._~-]{16,})\b",
    re.I,
)


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _tokens(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9_+%-]+", text.lower())


def _density(tokens: Sequence[str], vocabulary: set[str], scale: float = 3.0) -> float:
    if not tokens:
        return 0.0
    hits = sum(1 for token in tokens if token in vocabulary)
    return _clamp(hits / scale)


def _punctuation_novelty(text: str) -> float:
    # Symbol-heavy coined language often signals a motif or interface token.
    symbols = sum(1 for ch in text if ch in ":;!?()[]{}&*/\\|<>~^")
    mixed_case_tokens = len(re.findall(r"\b(?=\w*[A-Z])(?=\w*[a-z])\w+\b", text))
    digit_letter_tokens = len(re.findall(r"\b(?=\w*[A-Za-z])(?=\w*\d)\w+\b", text))
    return _clamp((symbols / 18.0) + (mixed_case_tokens / 5.0) + (digit_letter_tokens / 4.0))


@dataclass
class GuardResult:
    privacy_risk: float
    consent_gap: float
    unsupported_claim_risk: float
    attribution_gap: float
    reasons: List[str]


@dataclass
class SortResult:
    id: str
    excerpt: str
    shifts: Dict[str, float]
    primary_shift: str
    publicity_score: float
    evidence_score: float
    guard: GuardResult
    lane: str
    headline_seed: str
    rationale: List[str]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        return data


def score_shifts(text: str, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
    metadata = metadata or {}
    tokens = _tokens(text)
    scores = {shift: _density(tokens, KEYWORDS[shift]) for shift in SHIFT_ORDER}

    scores["ODDITY"] = _clamp(scores["ODDITY"] + 0.45 * _punctuation_novelty(text))
    scores["FRAME"] = _clamp(scores["FRAME"] + (0.25 if any(
        ext in text.lower() for ext in (".svg", ".png", ".jpg", ".html", ".webp")
    ) else 0.0))
    scores["RECEIPT"] = _clamp(scores["RECEIPT"] + (0.2 if any(
        ext in text.lower() for ext in (".json", ".ijson", ".log", ".md", ".txt")
    ) else 0.0))
    scores["NOW"] = _clamp(scores["NOW"] + (0.25 if metadata.get("recent") else 0.0))
    scores["FACE"] = _clamp(scores["FACE"] + (0.25 if metadata.get("named_character") else 0.0))
    scores["STAKES"] = _clamp(scores["STAKES"] + (0.25 if metadata.get("real_world_effect") else 0.0))
    return scores


def score_guard(text: str, metadata: Optional[Dict[str, Any]] = None) -> GuardResult:
    metadata = metadata or {}
    tokens = set(_tokens(text))
    reasons: List[str] = []

    privacy = 0.0
    if EMAIL_RE.search(text):
        privacy += 0.35
        reasons.append("email_address_present")
    if PHONE_RE.search(text):
        privacy += 0.45
        reasons.append("phone_number_present")
    if TOKEN_RE.search(text):
        privacy = 1.0
        reasons.append("credential_or_token_pattern_present")
    if metadata.get("private"):
        privacy = max(privacy, 0.6)
        reasons.append("marked_private")

    consent_gap = 0.0
    if metadata.get("about_nonconsenting_person"):
        consent_gap = 0.8
        reasons.append("third_party_consent_unconfirmed")
    elif metadata.get("publicity_permission") is False:
        consent_gap = 1.0
        reasons.append("publicity_permission_denied")

    claim_hits = sum(1 for token in tokens if token in CLAIM_WORDS)
    evidence_hits = sum(1 for token in tokens if token in EVIDENCE_WORDS)
    unsupported = _clamp((claim_hits - evidence_hits) / 3.0)
    if unsupported > 0.0:
        reasons.append("strong_claims_outpace_visible_evidence")

    attribution_gap = 0.0
    if metadata.get("derived") and not metadata.get("source_id"):
        attribution_gap = 0.8
        reasons.append("derivative_missing_source_id")
    elif metadata.get("source_id") is None and metadata.get("requires_attribution"):
        attribution_gap = 0.6
        reasons.append("attribution_required_but_missing")

    return GuardResult(
        privacy_risk=_clamp(privacy),
        consent_gap=_clamp(consent_gap),
        unsupported_claim_risk=_clamp(unsupported),
        attribution_gap=_clamp(attribution_gap),
        reasons=reasons,
    )


def evidence_score(text: str, metadata: Optional[Dict[str, Any]] = None) -> float:
    metadata = metadata or {}
    tokens = _tokens(text)
    base = _density(tokens, EVIDENCE_WORDS, scale=4.0)
    if metadata.get("source_id"):
        base += 0.2
    if metadata.get("artifact_exists"):
        base += 0.2
    if metadata.get("tested"):
        base += 0.25
    return _clamp(base)


def publicity_score(shifts: Dict[str, float]) -> float:
    weights = {
        "ODDITY": 0.18,
        "FRICTION": 0.14,
        "STAKES": 0.18,
        "FACE": 0.10,
        "FRAME": 0.16,
        "NOW": 0.10,
        "RECEIPT": 0.14,
    }
    weighted = sum(shifts[key] * weights[key] for key in SHIFT_ORDER)

    # Combination bonus: several simultaneous news values matter more than one.
    active = sum(1 for value in shifts.values() if value >= 0.45)
    bonus = min(0.18, active * 0.03)
    return _clamp(weighted + bonus)


def choose_lane(
    text: str,
    shifts: Dict[str, float],
    publicity: float,
    evidence: float,
    guard: GuardResult,
) -> str:
    max_guard = max(
        guard.privacy_risk,
        guard.consent_gap,
        guard.unsupported_claim_risk,
        guard.attribution_gap,
    )
    if max_guard >= 0.70:
        return "HOLD_FOR_GUARD_REVIEW"

    tokens = set(_tokens(text))
    utility = len(tokens.intersection(UTILITY_WORDS)) >= 2

    if publicity >= 0.68 and evidence >= 0.55:
        return "PRESS_CANDIDATE"
    if publicity >= 0.50 and shifts["FRAME"] >= 0.45:
        return "STORY_CARD"
    if shifts["ODDITY"] >= 0.58 and publicity >= 0.38:
        return "MOTIF_AND_COPY"
    if utility:
        return "BUILD_SPEC"
    if evidence >= 0.60:
        return "EVIDENCE_LEDGER"
    return "BACKGROUND_ARCHIVE"


def make_headline_seed(text: str, shifts: Dict[str, float]) -> str:
    clean = re.sub(r"\s+", " ", text).strip()
    clean = EMAIL_RE.sub("[email removed]", clean)
    clean = PHONE_RE.sub("[phone removed]", clean)
    clean = TOKEN_RE.sub("[credential removed]", clean)
    if len(clean) > 92:
        clean = clean[:89].rstrip() + "..."
    primary = max(shifts, key=shifts.get)
    return f"{primary.title()}: {clean}" if clean else f"{primary.title()}: untitled fragment"


def sort_fragment(
    fragment_id: str,
    text: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> SortResult:
    metadata = metadata or {}
    shifts = score_shifts(text, metadata)
    primary = max(shifts, key=shifts.get)
    evidence = evidence_score(text, metadata)
    guard = score_guard(text, metadata)
    publicity = publicity_score(shifts)
    lane = choose_lane(text, shifts, publicity, evidence, guard)

    rationale = [
        f"primary attention shift: {primary}",
        f"publicity score: {publicity:.2f}",
        f"evidence score: {evidence:.2f}",
        f"lane: {lane}",
    ]
    if guard.reasons:
        rationale.append("guard flags: " + ", ".join(guard.reasons))

    return SortResult(
        id=fragment_id,
        excerpt=re.sub(r"\s+", " ", text).strip()[:240],
        shifts={key: round(value, 4) for key, value in shifts.items()},
        primary_shift=primary,
        publicity_score=round(publicity, 4),
        evidence_score=round(evidence, 4),
        guard=guard,
        lane=lane,
        headline_seed=make_headline_seed(text, shifts),
        rationale=rationale,
    )


def sort_records(records: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    for index, record in enumerate(records, start=1):
        text = str(record.get("text", "")).strip()
        if not text:
            continue
        fragment_id = str(record.get("id", f"fragment-{index:04d}"))
        metadata = record.get("metadata") or {}
        results.append(sort_fragment(fragment_id, text, metadata).to_dict())
    return results


def load_json_or_ijson(path: Path) -> List[Dict[str, Any]]:
    text = path.read_text(encoding="utf-8")
    stripped = text.lstrip()
    if stripped.startswith("["):
        data = json.loads(text)
        if not isinstance(data, list):
            raise ValueError("JSON input must be an array of records.")
        return data

    records = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        item = json.loads(line)
        if not isinstance(item, dict):
            raise ValueError(f"Line {line_number} is not a JSON object.")
        records.append(item)
    return records


def main() -> int:
    parser = argparse.ArgumentParser(description="Sort conversation fragments into story shifts.")
    parser.add_argument("input", type=Path, help="JSON array or IJSON/JSONL file")
    parser.add_argument("-o", "--output", type=Path, help="Output JSON file; stdout when omitted")
    args = parser.parse_args()

    try:
        records = load_json_or_ijson(args.input)
        output = sort_records(records)
        rendered = json.dumps(output, indent=2, ensure_ascii=False)
        if args.output:
            args.output.write_text(rendered + "\n", encoding="utf-8")
        else:
            print(rendered)
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
