# Tabloid Signal Shift Sorter v1

A local, rule-based sorter for **user-provided conversation fragments**.

It converts broad news-selection signals into seven project-friendly shifts:

1. `ODDITY` — the strange or unexpected element
2. `FRICTION` — conflict, contradiction, or collision
3. `STAKES` — practical consequence, urgency, gain, or loss
4. `FACE` — the person or character carrying the idea
5. `FRAME` — the visual scene, prop, screenshot, or interface
6. `NOW` — recency, change, launch, or update
7. `RECEIPT` — source, evidence, test, log, artifact, or citation

The four guards are:

- privacy risk
- consent gap
- unsupported-claim risk
- attribution gap

## Lanes

- `PRESS_CANDIDATE`
- `STORY_CARD`
- `MOTIF_AND_COPY`
- `BUILD_SPEC`
- `EVIDENCE_LEDGER`
- `BACKGROUND_ARCHIVE`
- `HOLD_FOR_GUARD_REVIEW`

**Publicity is never treated as truth.** The sorter calculates separate
`publicity_score` and `evidence_score` values.

## Run

```bash
python tabloid_shift_sorter.py sample_input.json -o sample_output.json
```

Input may be a JSON array or newline-delimited JSON/IJSON.

## Scope

The module does not search the web, identify strangers, or build personal
dossiers. It only sorts text explicitly supplied to it.
