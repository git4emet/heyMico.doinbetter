
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open('mobiiius-018').then(c => c.addAll([
    '/', '/index.html', '/assets/site.css', '/assets/site.js', '/manifest.webmanifest'
  ])));
});
self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).then(resp => {
      const copy = resp.clone();
      caches.open('mobiiius-018').then(c => c.put(e.request, copy));
      return resp;
    }).catch(()=>caches.match('/index.html')))
  );
});
