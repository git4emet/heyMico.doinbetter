
// Global manifest + buddy panel bootstrap (v0.18.018)
window.MOBIIIUS = {
  version: "0.18.018",
  build_ts: "2025-08-13T20:07:26.021033Z",
  modules: {}, // populated from /site_assets/version.json
};

// Buddy panel stub (with Whisper++ hook via TIMMY_LOCAL if present)
window.MICO = {
  ingestText(txt){ console.log("MICO heard:", txt); addLog('heard', txt); },
  say(txt){ console.log("MICO says:", txt); addLog('say', txt);}
}

function addLog(type, txt){
  const el = document.querySelector('#buddy-log'); if(!el) return;
  const row = document.createElement('div'); row.textContent = `[${type}] ${txt}`;
  el.prepend(row);
}

window.addEventListener('message', (ev)=>{
  if(ev.data && ev.data.type==='flush-queue'){ if(window.TIMMY_LOCAL?.queue?.flush) window.TIMMY_LOCAL.queue.flush(); }
});

